import { LightningElement,api} from 'lwc';
import lang from '@salesforce/i18n/lang';
import CCEP_OrderedDateList from '@salesforce/label/c.CCEP_OrderedDateList';
import CCEP_OrderStatus from '@salesforce/label/c.CCEP_OrderStatus';

export default class CcepOrderSummaryListItem extends LightningElement {

    static renderMode = 'light';
    _order;

    labels = {
        CCEP_OrderedDateList,
        CCEP_OrderStatus
    }

    @api
    get order() {
        return this._order;
    }
    set order(value) {
        console.log('item', JSON.parse(JSON.stringify(value)));
        this._order = value;
    }

    get formattedDate() {
        let options = {
            day: '2-digit',
            month: 'long',
            year: 'numeric'
        }
        let date = new Date(this.order.OrderedDate);
        return new Intl.DateTimeFormat(lang, options).format(date);
    }

    handleclick() {
        this.dispatchEvent(
            new CustomEvent('gotoorder', {
                detail: {id: this.order.Id}
            })
        );
    }
    
}