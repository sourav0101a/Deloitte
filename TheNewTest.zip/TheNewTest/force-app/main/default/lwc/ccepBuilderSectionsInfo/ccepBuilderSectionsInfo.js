import { LightningElement, api } from 'lwc';
import { getCMSCollection } from 'c/ccepCommerceUtils';

export default class CcepBuilderSectionsInfo extends LightningElement {

    static renderMode = 'light';

    _mediaData = [];

    @api 
    cmsCollection;

    get mediaData() {
        return this._mediaData;
    }
    set mediaData(value) {
        this._mediaData = value;
    }

    connectedCallback() {
        this.getImagesData();
    }

    async getImagesData () {
        let result = await getCMSCollection(this.cmsCollection);
        if(result.success && result.data.items){
            this.mediaData = result.data.items.map(item => ({
                id: item.id,
                contentKey: item.body.contentKey,
                sectionName: item.body.contentBody.name,
                title: item.name,
                url: window.location.origin + item.body.contentBody.source.url
            }));
        }
    }

}