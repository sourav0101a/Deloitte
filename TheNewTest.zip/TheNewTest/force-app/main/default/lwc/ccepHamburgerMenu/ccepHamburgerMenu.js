/**
 * @description       : Create Hamburger Navigation Menu
 * @author            : vanm@deloitte.com
 * @group             :
 * @last modified on  : 09-26-2023
 * @last modified by  : vanm@deloitte.com
 * Modifications Log
 * Ver   Date         Author                               Modification
 * 1.0   09-26-2023   vanm@deloitte.com                    Initial Version
 * 
 **/

import { LightningElement,wire } from 'lwc';
//For Navigation 
import {NavigationMixin} from 'lightning/navigation';
//Import Custom Labels
import myUserAccount from '@salesforce/label/c.CCEP_My_User_Account';
import myEstablishment from '@salesforce/label/c.CCEP_My_Establishment';
import orderHistory from '@salesforce/label/c.CCEP_Order_History';
import notifications from '@salesforce/label/c.CCEP_Notifications';
import contactDetails from '@salesforce/label/c.CCEP_Contact_Details_Navigation';
//Get account record id
import { getRecord } from 'lightning/uiRecordApi';
const FIELDS = ['Account.Name'];
export default class ccepHamburgerMenu extends NavigationMixin(LightningElement) {

    label = {
        myUserAccount,
        myEstablishment,
        orderHistory,
        notifications,
        contactDetails
    }

    data;
    error;
    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');


    handleMenuItemSelect(event){
        const selectedMenuItemValue = event.detail.value;
    }

    @wire(getRecord, { recordId: '$effectiveAccountId', fields: FIELDS})
    wiredRecord({ error, data }) {
        if (data) {
            console.log('effective account data ' , data);
            this.data = data;
        } else if (error) {
            console.log(error);
            this.error = error;
        }
    }
    
    connectedCallback(){
        console.log('@@##Menu effectiveAccountId ' + this.effectiveAccountId);
    }

    navigateToChooseAnOutlet(){
    //Navigate to choose an outlet page
    this[NavigationMixin.Navigate]({
        type: 'standard__webPage',
        attributes: {
           url:'/choose-an-outlet'
      }
       });
    }

    navigateToUserAccount(){
        //Navigate to Establishment Page
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
               url: '/my-user-account'
          }
           });
        }

    navigateToEstablishment(){
    //Navigate to Establishment Page
    this[NavigationMixin.Navigate]({
        type: 'standard__webPage',
        attributes: {
           url: '/my-establishment'
      }
       });
    }

    navigateToOrderHistory(){
    //Navigate to Order History
    this[NavigationMixin.Navigate]({
        type: 'standard__webPage',
        attributes: {
           url: '/choose-an-outlet'
      }
       });
    }

    navigateToNotifications(){
    //Navigate to Notifications
    this[NavigationMixin.Navigate]({
        type: 'standard__webPage',
        attributes: {
           url:'/choose-an-outlet'
      }
       });
}

    navigateToContactDetails(){
    //Navigate to Contact Details
    this[NavigationMixin.Navigate]({
        type: 'standard__webPage',
        attributes: {
           url:'/contact-details'
      }
       });

}

}