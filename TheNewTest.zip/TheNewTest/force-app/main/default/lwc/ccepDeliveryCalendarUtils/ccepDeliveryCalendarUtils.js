import lang from '@salesforce/i18n/lang';
import { labelWithParams } from 'c/ccepCommerceUtils';
import CCEP_DeliveryDateDisclaimer from '@salesforce/label/c.CCEP_DeliveryDateDisclaimer';
import CCEP_ChooseDeliveryDate from '@salesforce/label/c.CCEP_ChooseDeliveryDate';

const maxDatesToShow = 14;
export const DAY_OF_WEEK = {
    Monday: 1,
    Tuesday: 2,
    Wednesday: 3,
    Thursday: 4,
    Friday: 5,
    Saturday: 6,
    Sunday: 7 
}

export function getDisclaimerDate(holidays, outletVisit, deliveryDelay, nonWorkinDays, workingDays){
    let disclaimerDate = null;
    let availableDates = generateAvailableDates(holidays, outletVisit, deliveryDelay, nonWorkinDays, workingDays);
    if(availableDates){
        disclaimerDate =  new Date(availableDates[0]);
    }
    return disclaimerDate;
}

export function getMonthsAndDisclaimerDate(holidays, outletVisit, deliveryDelay, nonWorkinDays, workingDays){
    let disclaimerDate = null;
    let availableDates = generateAvailableDates(holidays, outletVisit, deliveryDelay, nonWorkinDays, workingDays);
    if(availableDates){
        let availableDatesByMonth = availableDates.reduce( (ac,date) => ({...ac, [`${date.getFullYear()}${('0' + (date.getMonth()+1)).slice(-2)}`]:[ ...(ac[`${date.getFullYear()}${('0' + (date.getMonth()+1)).slice(-2)}`] || []),date]}),{});
        let monthsRefactored = Object.values(availableDatesByMonth).map( (dates) => (generateMonthData(dates)));
            disclaimerDate = {
                disclaimerDate: new Date(availableDates[0]),
                months: monthsRefactored
            } ;
    }
    return disclaimerDate;
}

export function getDeliveryDisclaimer(disclaimerDate, deliveryDelay){
    let format =  {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        timeZone: 'Europe/Madrid',
    };
    if(disclaimerDate === undefined || disclaimerDate == null){
        return null;
    }
    let limitCheckoutDate = new Date(new Date(disclaimerDate).setDate(disclaimerDate.getDate() - deliveryDelay / 24));
    return labelWithParams(CCEP_DeliveryDateDisclaimer, formatDate(limitCheckoutDate, format),formatDate(disclaimerDate, format));
}

export function getSelectedDateText(dateSelected){
    let format =  {
        weekday: 'long',
        month: 'long',
        day: 'numeric',
        timeZone: 'Europe/Madrid',
    };
    if(dateSelected === undefined || dateSelected == null){
        return null;
    }
    let dateFormatted = (dateSelected) ? formatDate(new Date(dateSelected),format) : '';
    return (dateFormatted) ? dateFormatted[0].toUpperCase() + dateFormatted.slice(1) : CCEP_ChooseDeliveryDate;
}

function formatDate (date,format) {
    return new Intl.DateTimeFormat(lang, format).format(date);
}

function generateAvailableDates (holidays, outletVisit, deliveryDelay, nonWorkinDays, workingDays) {
    let availableDates = null;
    if (holidays && outletVisit && deliveryDelay) {
        let currentDate = new Date();
        let millisecondsVisitPeriodicity = Number(outletVisit.CCEP_Periodicity__c) * 86400000;
        // Convert first visit to js Date
        let firstVisit = new Date(new Date(outletVisit.CCEP_FirstVisit__c).setHours(15));
        // Calculate the number of visits done until today
        let numberOfVisits = Math.floor((currentDate.getTime() - firstVisit.getTime()) / millisecondsVisitPeriodicity);
        numberOfVisits = (numberOfVisits < 0) ? 0 : numberOfVisits;
        // Convert deliveryDelay in days to calculate available dates adding the dates of delivery
        let deliveryDelayInDays = deliveryDelay / 24;
        // Generate potencial delivery date before apply constrains
        let availablePotentialDates = generatePotentialDates(maxDatesToShow,outletVisit.CCEP_Periodicity__c,firstVisit,numberOfVisits,deliveryDelayInDays);
        let rescheduleSchema = nonWorkinDays.reduce( (ac,day) => {
            // Search for next working day, if it is undefined pick the first one.
            let nextWorkingDate = workingDays.find(dayOfWeek => dayOfWeek > day);
            let firstAvailableDate = (nextWorkingDate) ? nextWorkingDate : workingDays[0];
            // Difference of days to pospose the delivery date
            let daysToAdd = (firstAvailableDate < day) ? firstAvailableDate - day + 7 : firstAvailableDate - day;
            // Sunday is 0 in js day of week so we have to convert then to 0.
            return {...ac, [(day === 7) ? 0 : day]: daysToAdd}
        },{});
        let firstPotentialDate = new Date(new Date(availablePotentialDates[0]).setHours(15));
        let firstPotentialDateWorkingDays = (Object.keys(rescheduleSchema).includes(String(firstPotentialDate.getDay()))) ? new Date(new Date(firstPotentialDate).setDate(firstPotentialDate.getDate() + rescheduleSchema[firstPotentialDate.getDay()])) : firstPotentialDate;
        // Check if there is a schedule delivery for tomorrow and the user is doing the order after 15:00. In that case, generate a new potential delivery dates avoiding the date of the next day.
        if (firstPotentialDateWorkingDays.getTime() - currentDate.getTime() < deliveryDelay * 3600000) {
            availablePotentialDates = generatePotentialDates(maxDatesToShow,outletVisit.CCEP_Periodicity__c,firstVisit,numberOfVisits+1,deliveryDelayInDays);
        }
        let today = new Date();
        let tomorrow = new Date(`${today.getFullYear()}/${today.getMonth()+1}/${today.getDate() + 1}`);
        // Check and format available dates avoiding bank holidays and weekends.
        availableDates = availablePotentialDates.map(date => {
            let potentialDate = (Object.keys(rescheduleSchema).includes(String(date.getDay()))) ? new Date(new Date(date).setDate(date.getDate() + rescheduleSchema[date.getDay()])) : date;
            // In this case, we have to use hyphen (-) to compare with the format received by salesforce (YYYY-MM-DD)
            let stringDateToCheckHoliday = `${potentialDate.getFullYear()}-${("0" + (potentialDate.getMonth() + 1)).slice(-2)}-${("0" + potentialDate.getDate()).slice(-2)}`;
            return (!holidays.includes(stringDateToCheckHoliday) && potentialDate.getTime() > tomorrow.getTime()) ? potentialDate : undefined;
        }).filter(date => date !== undefined);
        let twoWeeksMax = new Date(new Date(availableDates[0]).setDate(availableDates[0].getDate() + 14));
        availableDates = availableDates.filter(date => date.getTime() < twoWeeksMax.getTime());

    }
    return availableDates;
}

function generatePotentialDates(maxDates, perodicity, startDate, numberOfVisits, deliveryDelayDays){
    return Array.from({length: Math.ceil(maxDates / perodicity) + 1}).map( (_,i) => new Date(new Date(startDate).setDate(startDate.getDate() + (numberOfVisits+i) * perodicity + deliveryDelayDays)));
}

function generateMonthData(availableDates){
    let currentDate = new Date();
    let datesOfCurrentMonth = new Date(availableDates[0].getFullYear(),availableDates[0].getMonth() + 1,0).getDate();
    let currentDateDate = (availableDates[0].getMonth() === currentDate.getMonth()) ? currentDate.getDate() : '';
    let currentMonth = {dates: generateDateOfMonth(datesOfCurrentMonth,availableDates.map(date => date.getDate()),availableDates[0].getFullYear(),availableDates[0].getMonth(),currentDateDate)};
    currentMonth.dates[0] = {...currentMonth.dates[0], style: `grid-column: ${getFirstDayOfWeek(new Date(availableDates[0].getFullYear(),availableDates[0].getMonth(),1))}`}
    return currentMonth;
}

function generateDateOfMonth(lastDate, availableDates, year, month, currentDate) {
    month = ("0" + (month + 1)).slice(-2);
    // We use slash (/) to separate date in order to be compatible with all browsers.
    return Array.from({length: lastDate}).map( (_,date) => ({stringDate: `${year}/${month}/${date+1}`,date: date + 1, disabled: !availableDates.includes(date + 1), class: (currentDate === date + 1) ? 'today' : ''}));
}

function getFirstDayOfWeek(date){
    let day = date.getDay();
    return (day > 0 ) ? day : 7;
}