import { LightningElement, wire, api } from "lwc";
import getPromotionsOffset from "@salesforce/apex/CCEP_PromotionsController.getPromotionsOffset";
import getPromotionsCount from "@salesforce/apex/CCEP_PromotionsController.getPromotionsCount";
import { getCMSContent, getLanguage } from "c/ccepCommerceUtils";
import { getFormFactor } from "experience/clientApi";

const sessionStorage_MANUAL_PAGINATION = "CcepPromotions_ManualPagination";

export default class CcepBuilderPromotions extends LightningElement {
  static renderMode = "light";

  _manualPagination =
    sessionStorage.getItem(sessionStorage_MANUAL_PAGINATION) != null
      ? sessionStorage.getItem(sessionStorage_MANUAL_PAGINATION) === "true"
      : null;

  _currentPage;    
  _promotions;
  _totalPages;
  _totalItemCount;
  _offsetCurrentPage;
  _currentPageSize;
  _responsivePageSize;

  @api pageSize;
  @api
  get currentPage() {
      return this._currentPage;
  }
  set currentPage(value) {
      this._currentPage = value;
  }
  get totalPages() {
      return this._totalPages;
  }
  set totalPages(value) {
      this._totalPages = value;
  }
  get totalItemCount() {
    return this._totalItemCount;
  }
  set totalItemCount(value) {
    this._totalItemCount = value;
  }
  get promotions() {
    return this._promotions;
  }
  set promotions(value){
    this._promotions = value;
  }
  get offsetCurrentPage() {
    return this._offsetCurrentPage;
  }
  set offsetCurrentPage(value) {
    this._offsetCurrentPage = value;
  }
  get currentPageSize() {
    return this._currentPageSize;
  }
  set currentPageSize(value) {
    this._currentPageSize = value;
  }
  get responsivePageSize() {
    return this._responsivePageSize;
  }
  set responsivePageSize(value) {
    this._responsivePageSize = value;
  }
  get manualPagination() {
    if (this._manualPagination != null) {
      return this._manualPagination;
    }
    return this.formFactor === "Large";
  }
  set manualPagination(value) {
    this._manualPagination = value;
  }
  get noMoreResultsToDisplay(){
    return this.currentPageSize >= this.totalPages * this._responsivePageSize;
  }

  @wire(getFormFactor)
  onFormFactor(result) {
    if(result !== 'Large'){
      this._currentPageSize = 4;
      this._responsivePageSize = 4;
    }
    else{
      this._currentPageSize = this.pageSize;
      this._responsivePageSize = this.pageSize;
    }
    this._totalPages = Math.ceil(this.totalItemCount/this.responsivePageSize);
    this._offsetCurrentPage = 0;
    this._currentPage = 1;
  }

  @wire(getPromotionsCount, {effectiveAccountId: sessionStorage.getItem("EFFECTIVE_ACCOUNT_ID")})
  onGetPromotionsCount(result) {
    if (result.data) {
      this._totalItemCount = result.data;
      this._totalPages = Math.ceil(result.data/this._responsivePageSize);
      this._currentPageSize = this._responsivePageSize;
      const urlParams = new URLSearchParams(window.location.search);
      const urlCurrentPage = urlParams.get('currentPage');
      //Check if url param is in range of number of pages
      if(urlCurrentPage && urlCurrentPage <= this.totalPages){
        this._currentPage = urlCurrentPage;
        this._offsetCurrentPage = urlCurrentPage;
      }
      else{
        this._currentPage = 1;
        this._offsetCurrentPage = 0;
      }
    }
  }

  @wire(getPromotionsOffset, { effectiveAccountId: sessionStorage.getItem("EFFECTIVE_ACCOUNT_ID"), currentPage: "$offsetCurrentPage", pageSize: "$currentPageSize"})
  async onGetPromotionsOffset(result) {
    if (result.data) {
      //Get cms content
      let cmsContentResponse =  await getCMSContent(result.data.map((promotion) => promotion.CCEP_Promotion__r.CCEP_CMSContentKey__c));
      if (cmsContentResponse.success && cmsContentResponse.data.contents) {
        //Match cms content to its promotion
        let promotionWithAllInfo = this.associateCmsToPromotion(result, cmsContentResponse);
        //Format data as expected
        this._promotions = this.formatPromotionsData(promotionWithAllInfo);
      }
    } 
  }

  associateCmsToPromotion(result, cmsContentResponse){
    let promotionWithAllInfo = [];
    result.data.forEach((promotion) => { let cmsContent = cmsContentResponse.data.contents.find((content) => content.contentKey === promotion.CCEP_Promotion__r.CCEP_CMSContentKey__c);
      let promotionWithCms = JSON.parse(JSON.stringify(promotion));
      promotionWithCms.cmsContent = cmsContent;
      promotionWithCms.endDate = new Intl.DateTimeFormat(getLanguage()).format(new Date(promotion.CCEP_Promotion__r.CCEP_EndDate__c));
      promotionWithAllInfo.push(promotionWithCms);
    });
    return promotionWithAllInfo;
  }

  formatPromotionsData(promotionsNotFormated){
    return promotionsNotFormated.map((promotion) => ({
      id: promotion.CCEP_Promotion__r.Id,
      title: promotion.cmsContent.contentBody.title,
      description: promotion.cmsContent.contentBody.description,
      image: {
        alternateText: promotion.cmsContent.urlName,
        url: promotion.cmsContent.contentBody.image.url
      },
      endDate: promotion.endDate,
      discount: promotion.cmsContent.contentBody.discount
    }));
  }

  // Selector changes automatic pagination
  handleSelectorChange(event) {
    this.manualPagination = event.detail.checked;
    if (!this.manualPagination) {
      this.cleanAllResults();
    }
    sessionStorage.setItem(
      sessionStorage_MANUAL_PAGINATION,
      event.detail.checked
    );
  }

  // Update current page
  handleUpdateCurrentPage(event) {
    if (event.detail.cleanResults && Number(event.detail.newPageNumber) === 1) {
      this.cleanAllResults();
    }
    event.stopPropagation();
    this._currentPage = Number(event.detail.newPageNumber);
    this._offsetCurrentPage = Number(event.detail.newPageNumber) - 1;
  }

  // Clean results for changing automatic to manual pagination
  cleanAllResults() {
    this._currentPage = 1;
    this._offsetCurrentPage = 0;
    this._currentPageSize = this._responsivePageSize;
  }
  
  handleSeeMoreItems(){
    this._currentPageSize += this._responsivePageSize;
  }
}