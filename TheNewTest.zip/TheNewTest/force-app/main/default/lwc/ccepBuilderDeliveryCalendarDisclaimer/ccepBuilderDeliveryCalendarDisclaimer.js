import { LightningElement, wire } from 'lwc';
import getHolidaysByDistributor from '@salesforce/apex/CCEP_DeliveryCalendarController.getHolidaysByDistributor';
import getOutletVisit from '@salesforce/apex/CCEP_DeliveryCalendarController.getOutletVisit';
import getDeliveryDelay from '@salesforce/apex/CCEP_DeliveryCalendarController.getDeliveryDelay';
import { getDisclaimerDate, getDeliveryDisclaimer, DAY_OF_WEEK } from 'c/ccepDeliveryCalendarUtils';

export default class CcepBuilderDeliveryCalendarDisclaimer extends LightningElement {
    static renderMode = 'light';

    effectiveAccountId = sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');
    holidays;
    outletVisit;
    deliveryDelay;
    disclaimerDate;
    workingDays;
    nonWorkinDays;


    @wire(getHolidaysByDistributor,{effectiveAccountId:'$effectiveAccountId'})
    onHolidays({data,error}) {
        if (error) {
            console.error('Error getting holidays',error)
        } else if (data) {
            this.holidays = data.map(date => date.CCEP_Date__c);
            this.generateAvailableDates();          
        }
    }

    @wire(getOutletVisit,{outletId: '$effectiveAccountId'})
    onOutletVisit({data,error}) {
        if (error) {
            console.log('error getting outletVisits',error)
        } else if (data) {
            this.outletVisit = data;
            this.generateAvailableDates();
        }
    }

    @wire(getDeliveryDelay,{effectiveAccountId:'$effectiveAccountId'})
    onDeliveryDate( {data,error}) {
        if (error) {
            console.log('error getting delivery dates',error)
        } else if (data) {
            this.deliveryDelay = data.CCEP_DeliveryDelay__c;
            let days = data.CCEP_DistributorWorkingDays__c.split(';');
            let workingDays = [];
            let nonWorkingDays = [];
            Object.entries(DAY_OF_WEEK).forEach( ([day,dayJs]) => {
                if (days.includes(day)) {
                    workingDays.push(dayJs)
                } else {
                    nonWorkingDays.push(dayJs);
                }
            });
            this.workingDays = workingDays;
            this.nonWorkinDays = nonWorkingDays;
            this.generateAvailableDates();
        }
    }

    generateAvailableDates () {
        this.disclaimerDate = getDisclaimerDate(this.holidays, this.outletVisit, this.deliveryDelay, this.nonWorkinDays, this.workingDays);
    } 

    get deliveryDisclaimer(){
        return getDeliveryDisclaimer(this.disclaimerDate, this.deliveryDelay);
    }
}