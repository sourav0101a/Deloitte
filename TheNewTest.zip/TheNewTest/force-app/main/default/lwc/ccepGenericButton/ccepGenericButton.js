import { LightningElement, api } from 'lwc';

export default class CcepGenericButton extends LightningElement {

    static renderMode = 'light';

    styleProperties = {
        "primary": "primary-btn", // Primary button with black background color
        "primary-full": "primary-btn full-width", // Primary button with full width
        "secondary": "secondary-btn", // Secondary button with white background color and 1px black border
        "secondary-full": "secondary-btn full-width", // Secondary button with full width
        "tertiary": "tertiary-btn", // Tertiary button with white background color, no borders and underlined text
        "tertiary-full": "tertiary-btn full-width", // Tertiary button with full width
        "single": "single-btn", // Single button with white background color and gray border
        "login": "login-btn", // Login button in the Commerce header has special styles
        "round": "round-btn", // Round button with high percentage of border-radius and white background
        "chevron": "slds-m-horizontal_small slds-button slds-button_neutral", // Chevron class
        "carrousel": "ccep-button-carrousel slds-m-horizontal_xxx-small slds-button", // Carrousel class
        "back-to-top": "btn-top", // Specific class for the "Back to top" button
        "search": "btn-search", // Specific class for the search button
    };

    // Button parameters
    @api
    text; // Button text
    @api
    type; // Button type
    @api
    hoverText; // Hover text of the button
    @api
    disabled; // If true, disables the button

    // Icon parameters
    @api
    icon; // For example: chevronright
    @api
    iconFirst; // Boolean to place icon before (on the left, value = true) or after (on the right, value = false) the text
    @api
    size; // For example: medium
    @api
    iconColor;
    @api
    alternativeText; // For example: Next
    
    // Type parameter defines the css class for the button
    get styles(){
        let genericClass = 'ccep-button';
        if(this.iconFirst && this.iconFirst == 'true'){
            genericClass = 'ccep-button-reverse';
        }
        return `${genericClass} ${this.styleProperties[this.type]}`;
    }

    // Icon name - e.g. chevronright
    get iconName(){
        return `utility:${this.icon}`;
    }

    // Icon class styles
    get iconStyles(){
        if(this.iconColor){
            return `icon-${this.iconColor}`;
        }
    }

    // Either the icon will be disabled or not
    get disabledButton(){
        return this.disabled == true;
    }

    // Click to action
    clickToAction(){
        this.dispatchEvent(new CustomEvent('buttonclick'));
    }

}