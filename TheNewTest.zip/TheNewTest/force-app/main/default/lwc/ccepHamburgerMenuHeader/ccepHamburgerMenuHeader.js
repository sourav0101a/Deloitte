import { LightningElement, api, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { getFormFactor } from 'experience/clientApi';
import { refreshApex } from "@salesforce/apex";
import isguest from '@salesforce/user/isGuest';
import Id from "@salesforce/user/Id";
import communityPath from '@salesforce/community/basePath';
import getNotificationCount from '@salesforce/apex/CCEP_NotificationController.getNotificationCount';

export default class CcepHamburgerMenuHeader extends NavigationMixin(LightningElement) {

    static renderMode = 'light';

    _menuIsOpen = false;
    _showLanguagesModal;
    _showOutletInfo;

    //For Notification Count
    userId = Id;
    intervalSet;
    wiredCount;
    notificationInterval;
    notificationCount;
    unreadNotification = false;

    @api
    storeLogoUrl;

    @api
    storeInfo;

    @api
    navigation;

    @api
    userMenu;

    @api
    languages;

    @wire(getFormFactor)
    formFactor;

    //For Notification Count
    @wire(getNotificationCount, { userId: "$userId" })
    wiredResult(result) {
        this.wiredCount = result;
        if (result.data) {
            this.notificationCount = result.data;
            this.unreadNotification = true;
            if (!this.intervalSet && !isguest) {
                this.intervalSet = true;
                this.notificationInterval = setInterval(
                () => refreshApex(this.wiredCount),
                5e3
                );
            }
            console.log("COUNT---" + this.notificationCount);
            console.log("UserId---" + this.userId);
        }
        if (result.error) {
            console.error(result.error);
        }
    }

    get showNotification(){
        return !isguest && this.unreadNotification;
    }

    get isMobile(){
        return this.formFactor === 'Small';
    }

    get isGuest(){
        return isguest;
    }

    get menuIsOpen() {
        return this._menuIsOpen;
    }

    set menuIsOpen(value) {
        this._menuIsOpen = value;
    }

    get showLanguagesModal(){
        this._showLanguagesModal;
    }

    set showLanguagesModal(value){
        this._showLanguagesModal = value
    }

    //For Count besides Notifiation Menu Item.
    renderedCallback() {
        let id = "/store/notifications";
        const notificationSpan = document.querySelector(`[data-value="${id}"]`);
        if (notificationSpan) {
            notificationSpan.classList.remove("menu-notification-count");
            notificationSpan.classList.add("notification-count");
        }
    }

    //Clear Interval
    disconnectedCallback() {
        clearInterval(this.notificationInterval);
    }

    // Open/Close burger menu
    burgerMenuAction(){
        this._menuIsOpen = !this._menuIsOpen;
    }

    // Language selected
    handleSelectedLanguage(event){
        this.dispatchEvent(
            new CustomEvent('selectedlanguage', {
                detail: {
                    language: event.detail.language
                }
            })
        );
        this._menuIsOpen = false;
    }

    // Choose outlet page
    chooseOutlet(){
        this._menuIsOpen = false;
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
               url:'/choose-an-outlet'
          }
           });
    }

    // Go to navigation target
    goToTarget(event){
        console.log("TargetID"+event.currentTarget.dataset.id);
        this._menuIsOpen = false;
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
               url: event.currentTarget.dataset.id
          }
           });
    }

    // Go to Home page
    goHome(event){
        this._menuIsOpen = false;
        event.preventDefault();
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'Home',
            },
        });
    }

    // Go to Login page
    goToLoginPage(event){
        this._menuIsOpen = false;
        event.preventDefault();
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: communityPath
            }
        });
    }

    // Go to Registration page
    goToRegistrationPage(event){
        this._menuIsOpen = false;
        event.preventDefault();
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: communityPath
            }
        });
    }

    // Logout
    handleLogout(){
        this._menuIsOpen = false;
        sessionStorage.clear();
        window.location.href = '/secur/logout.jsp';
    }

}