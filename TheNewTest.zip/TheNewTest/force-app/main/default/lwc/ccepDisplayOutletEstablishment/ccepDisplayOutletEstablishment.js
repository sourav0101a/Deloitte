import { LightningElement,wire,api } from 'lwc';
import { RefreshEvent } from 'lightning/refresh';
import { getRecord } from 'lightning/uiRecordApi';
import { refreshApex } from '@salesforce/apex';
import userId from '@salesforce/user/Id';
import userEmployeeType from '@salesforce/schema/User.Contact.EmployeeType__c';
import getOutletDetails from '@salesforce/apex/CCEP_OutletController.getOutletEstablishmentDetails';
import getUserDetails from '@salesforce/apex/CCEP_OutletController.getUserDetails';
import establishmentDetail from '@salesforce/label/c.CCEP_Establishment_Detail';
import establishmentName from '@salesforce/label/c.CCEP_Establishment_Name';
import establishmentBillingAddress from '@salesforce/label/c.CCEP_Establishment_Billing_Address';
import establishmentDeliveryAddress from '@salesforce/label/c.CCEP_Establishment_Delivery_Address';

//import { getRecord } from 'lightning/uiRecordApi';
//const FIELDS = ['ContactPointAddress.Name','ContactPointAddress.AddressType','ContactPointAddress.Parent.Name'];

export default class CcepDisplayOutletEstablishment extends LightningElement {

    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');
    outletName;
    billingAddress;
    shippingAddress;
    outletInformation;
    flagIndicatingDataReadyForChild = false;
    isOutletOwner = false;
    userType;

    label = {
        establishmentDetail,
        establishmentName,
        establishmentBillingAddress,
        establishmentDeliveryAddress
    };

    isShowModal = false;

    //get account id of logged in user
    @wire(getRecord, {
        recordId: userId,
        fields: [userEmployeeType]
    }) currentUserType({
        error,
        data
    }) {
        if (error) {
        this.error = error ; 
        } else if (data) {
            console.log('User dets'+data);
            this.userType = data.fields.Contact.value.fields.EmployeeType__c.value;
            if(this.userType != 'Outlet Manager' && this.userType != 'Outlet Staff'){
                this.isOutletOwner = true;
            }
        }
    }

    @wire(getOutletDetails, { 
        effectiveAccountId: '$effectiveAccountId'
    })
    wiredRecord({ error, data }) {
        if (data) {
            console.log('effective account data ' , data);
           // this.data = data;
           this.outletInformation = data;
            this.flagIndicatingDataReadyForChild = true;
           if(data){
             console.log('@@##this.outletName  ' + this.outletName );
             this.outletName = data.Name;
             console.log('@@##ContactPointAddresses ', data.ContactPointAddresses);
             if(data.ContactPointAddresses){
                for(let addresses in data.ContactPointAddresses){
                    console.log('addresses ' , addresses);
                    console.log('addresses ' , data.ContactPointAddresses[addresses].AddressType);

                    if(data.ContactPointAddresses[addresses].AddressType === 'Billing'){
                        this.billingAddress = data.ContactPointAddresses[addresses].CCEP_Type_of_Road__c +' '+ 
                                              data.ContactPointAddresses[addresses].CCEP_Name_of_Road__c + ' ' + 
                                              data.ContactPointAddresses[addresses].CCEP_Number__c + ' '+ 
                                              data.ContactPointAddresses[addresses].City + ' ' +
                                              data.ContactPointAddresses[addresses].State + ' ' +
                                              data.ContactPointAddresses[addresses].PostalCode;
                    }
                    if(data.ContactPointAddresses[addresses].AddressType === 'Shipping'){
                        this.shippingAddress =  data.ContactPointAddresses[addresses].CCEP_Type_of_Road__c +' '+ 
                                                data.ContactPointAddresses[addresses].CCEP_Name_of_Road__c + ' ' + 
                                                data.ContactPointAddresses[addresses].CCEP_Number__c + ' '+ 
                                                data.ContactPointAddresses[addresses].City + ' ' +
                                                data.ContactPointAddresses[addresses].State + ' ' +
                                                data.ContactPointAddresses[addresses].PostalCode;
                    }
                    console.log('@@Billing add ' + this.billingAddress);
                    console.log('@@Shipping add ' + this.shippingAddress);

                }
             }
           }

        } else if (error) {
            console.log(error);
            this.error = error;
        }
    }

    connectedCallback(){
        console.log('@@##effectiveAccountId ' + this.effectiveAccountId);
        console.log('employee type : '+ this.userType);
    }

    showModalBox() {  
        this.isShowModal = true;
    }

    closeModalBox(){
        console.log('Close Modal');
        //const detailValue = event.detail;

        console.log('detailValue', detailValue);
        //this.outletName = data.Name;

        window.location.reload()
        // this.dispatchEvent(new RefreshEvent());  
      
        // refreshApex(this.outletInformation);
        this.isShowModal = false; 
        
    }

    handleCancel(){
        this.isShowModal = false;
    }

}