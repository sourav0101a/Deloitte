import { getPathPrefix } from 'lightning/configProvider';
import siteId from '@salesforce/site/Id';
import communityId from "@salesforce/community/Id";
import lang from '@salesforce/i18n/lang';
import { getAppContext } from 'commerce/contextApi';

const version = 'v59.0';
export const callPrefix = `${getPathPrefix()}/webruntime/api/services/data/${version}`;
const languageCookieName = 'PreferredLanguage' + siteId;

const effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

export async function getWebstoreId(){
    return getAppContext().then(result => result.webstoreId);
}

export function labelWithParams(stringToFormat, ...formattingArguments) {
    if (typeof stringToFormat !== 'string') throw new Error('\'stringToFormat\' must be a String');
        return stringToFormat.replace(/{(\d+)}/gm, (match, index) =>
            (formattingArguments[index] === undefined ? '' : `${formattingArguments[index]}`));
}

export async function getCMSCollection (cmsCollection) {
    try {
        let url = `${callPrefix}/connect/sites/${siteId}/cms/delivery/collections/${cmsCollection}?language=${lang}`;
        let response = await fetch(url);
        let data = await response.json();
        return {success: true, data};
    }
    catch (error) {
        console.log('ERROR getCMSCollection', error);
        return {success: false, error}
    }
}

export async function getProductsInPromotion (productIds) {
    try {
        let webstoreId = await getWebstoreId();
        let url = `${callPrefix}/commerce/webstores/${webstoreId}/products`;
        if(effectiveAccountId != null && effectiveAccountId != undefined && effectiveAccountId != ''){
            url += `?effectiveAccountId=${effectiveAccountId}&ids=${productIds}`;
        } else {
            url += `?ids=${productIds}`;
        }
        let response = await fetch(url);
        let data = await response.json();
        return {success: true, data};
    }
    catch (error) {
        console.log('ERROR getPromotionProducts', error);
        return {success: false, error}
    }
}

export async function getPricingProductsInPromotion (productIds) {
    try {
        let webstoreId = await getWebstoreId();
        let url = `${callPrefix}/commerce/webstores/${webstoreId}/pricing/products`;
        if(effectiveAccountId != null && effectiveAccountId != undefined && effectiveAccountId != ''){
            url += `?effectiveAccountId=${effectiveAccountId}&productIds=${productIds}`;
        } else {
            url += `?productIds=${productIds}`;
        }
        let response = await fetch(url);
        let data = await response.json();
        return {success: true, data};
    }
    catch (error) {
        console.log('ERROR getPricingProductsByPromotion', error);
        return {success: false, error}
    }
}

export async function getNavigationMenuItems(navigationLinkSetDeveloperName) {
    try {
        let url = `${callPrefix}/connect/communities/${communityId}/navigation-menu/navigation-menu-items?language=${getLanguage()}`;
        if(navigationLinkSetDeveloperName){
            url += `&navigationLinkSetDeveloperName=${navigationLinkSetDeveloperName}`; 
        }  
        if(effectiveAccountId){
            url += `&effectiveAccountId=${effectiveAccountId}`;  
        }            
        let response = await fetch(url);
        let data = await response.json();
        return {success: true, data};
    }
    catch (error) {
        console.error(error);
        return {success: false, error}
    }
}

export async function getCMSContent(contentKeys) {
    try {
        let url = `${callPrefix}/connect/sites/${siteId}/cms/delivery/contents?contentKeys=${contentKeys}&language=${lang}&includeContentBody=true`;
        let response = await fetch(url);
        let data = await response.json();
        return {success: true, data};
    }
    catch (error) {
        console.log('ERROR getCMSContent', error);
        return {success: false, error}
    }
}

export async function setDeliveryDateAndAddressForCart(checkoutId, bodyParsed) {
    try {
        let webstoreId = await getWebstoreId();
        let url = `${callPrefix}/commerce/webstores/${webstoreId}/checkouts/${checkoutId}`;
        if(effectiveAccountId != null && effectiveAccountId !== undefined && effectiveAccountId !== ''){
            url += `?effectiveAccountId=${effectiveAccountId}&language=${lang}&asGuest=false&htmlEncode=false`;
        } else {
            url += `?language=${lang}&asGuest=false&htmlEncode=false`;
        }
        let response = await fetch(url, {
            method: 'PATCH',
            body: bodyParsed,
            headers: {
              'Content-type': 'application/json; charset=UTF-8',
            },
          });
        let data = await response.json();
        return {success: true, data};
    }
    catch (error) {
        console.log('ERROR setDeliveryDateAndAddressForCart', error);
        return {success: false, error}
    }
}

export function getCookie(cName) {
    const name = cName + "=";
    const cDecoded = decodeURIComponent(document.cookie);
    const cArr = cDecoded.split('; ');
    let res;
    cArr.forEach(val => {
        if (val.indexOf(name) === 0) res = val.substring(name.length);
    })
    return res;
}

export function setCookie(cookiename, cookievalue) {
    document.cookie = `${cookiename}=${cookievalue}; path=/`;
}

export function getLanguage() {
    return getCookie(languageCookieName);
}

export function setLanguage(newValue) {
    return setCookie(languageCookieName, newValue);
}

export function formatDate(date, format) {
    let formatedDate;
    if(date){
        formatedDate = new Intl.DateTimeFormat(getLanguage(), format).format(new Date(date));
    }
    return formatedDate;
}