import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

export default class CcepCartBadge extends NavigationMixin(LightningElement) {

    static renderMode = 'light';

    _showItems = false;
    _items;

    @api
    get items() {
        return this._items;
    }
    set items(value) {
        if(value && value > 0){
            this._items = value;
            this.showItems = true;
        } else {
            this.showItems = false;
        }
    }

    get showItems() {
        return this._showItems;
    }
    set showItems(value) {
        this._showItems = value;
    }

    handleCartClick(event){
        event.stopPropagation();
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: '/cart'
            }
        });
    }

}