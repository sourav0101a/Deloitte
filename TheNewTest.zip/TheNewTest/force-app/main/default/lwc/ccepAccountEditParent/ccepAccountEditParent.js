import { LightningElement, track, api, wire } from 'lwc';
import communityId from '@salesforce/community/Id';
//importing custom labels for spanish literals - User Detail Section
import email from '@salesforce/label/c.CCEP_Email';
import firstName from '@salesforce/label/c.CCEP_First_name';
import lastName from '@salesforce/label/c.CCEP_Surname';
import mobileNumber from '@salesforce/label/c.CCEP_Mobile_number';
import contactInformationFieldRequired from '@salesforce/label/c.CCEP_Contact_Information_Field_Required';
import editUserHeader from '@salesforce/label/c.CCEP_Edit_User_Header';
import associatedOutletsHeader from '@salesforce/label/c.CCEP_Associated_Outlets';
import addOutlet from '@salesforce/label/c.CCEP_Add_Outlet';
import role from '@salesforce/label/c.CCEP_Role';
import cancelButton from '@salesforce/label/c.CCEP_Cancel';
import saveButton from '@salesforce/label/c.CCEP_Save_Button';
import acceptButton from '@salesforce/label/c.CCEP_Accept';
import chooseOutlets from '@salesforce/label/c.CCEP_Choose_Outlets';
import OutletSelMsg from '@salesforce/label/c.CCEP_Outlet_Selection_Msg';
import continueButton from '@salesforce/label/c.CCEP_Continue_Button';
import removeButton from '@salesforce/label/c.CCEP_Remove_Button';
import userSuccess from '@salesforce/label/c.CCEP_User_Creation_Success';
//import apex functionality
import getListOfOutlet from '@salesforce/apex/CCEP_OutletRegistrationController.getListOfOutlet';
import getOutletAssociation from '@salesforce/apex/CCEP_UpdateRoleController.getDelegateAccountData';
import updateEmployeeContact from '@salesforce/apex/CCEP_UpdateRoleController.updateEmployeeContact';
import getUserInfo from '@salesforce/apex/CCEP_UpdateRoleController.getUserInfo';
export default class ccepAccountEditParent extends LightningElement {
    @api userId;
    @api mydata;
    @api contactId;
    userModal = true;
    outletModal = false;
    showSpinner = false;
    isSubmitted = false;
    buttonDisabled = false;
    userType;
    loggedInManager = false;
    invalidEmail = false;
    duplicateEmail = false;
    role ='';
    requiredFieldError = false;
    @track listOfOutletsResult;
    isManager = false;
    isStaff = false;
    isCheckboxSelected = false;
    isCheckboxSelectedNEW = false;
    isRadioButtonSelected = false;
    noOutletsSelected = false;

    //in case of manager, multiple outlets can be selected
    @track selectedOutletIds = new Set(); //to be sent as associated outlet ids to apex
    @track selectedOutlets = []; //used to display the outlet names after selection

    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

    @track outletEmployeeDetail = {
        firstName : '',
        lastName : '',
        employeeType : '',
        email : '',
        phone : '',
        effectiveAccountId : '',
        contactIdvalue : ''
    };

    label = {
        firstName,
        email,
        lastName,
        role,
        mobileNumber,
        contactInformationFieldRequired,
        associatedOutletsHeader,
        addOutlet,
        chooseOutlets,
        editUserHeader,
        cancelButton,
        saveButton,
        acceptButton,
        continueButton,
        removeButton,
        userSuccess,
        OutletSelMsg
    };

    get roleOptions() {
        return [
            { label: 'Gerente', value: 'Outlet Manager' },
            { label: 'Personal', value: 'Outlet Staff' }
        ];
    }

    //roles to display if manager is logged-in user
    get managerRoleOptions() {
        return [
            { label: 'Personal', value: 'Outlet Staff' }
        ];
    }

    //get list of outlets details with address
    connectedCallback() {
        this.showSpinner = true;
        
        getUserInfo({ userId: this.contactId })
        .then((result) => {
            if(result){
                this.outletEmployeeDetail.firstName = result.firstName;
                this.outletEmployeeDetail.lastName = result.lastName;
                this.outletEmployeeDetail.email = result.email;
                this.outletEmployeeDetail.employeeType = result.EmployeeType__c;
                this.outletEmployeeDetail.effectiveAccountId = this.effectiveAccountId;
                if(result.EmployeeType__c == 'Outlet Manager'){
                    this.isManager = true;
                    this.isStaff = false;
                }
                else if(result.EmployeeType__c == 'Outlet Staff'){
                    this.isManager = false;
                    this.isStaff = true;
                } 
                if(result.phone){
                    const phoneNumber =  result.phone;
                    this.outletEmployeeDetail.phone = phoneNumber.replace(/^\+34/, '');
                }
                
                this.callConnectApi();
                
            }
        } 
        )
        .catch((error) => {
            this.error = error;
        });  
    }

    callConnectApi(){
        getListOfOutlet({communityId: communityId})
        .then((result) => {
            if(result){
                this.listOfOutletsResult = result;
                this.getOutletMapping();
            }  
        })
        .catch((error) => {
            this.error = error;
        });
    }

    getOutletMapping(){
        getOutletAssociation({manageByID: this.contactId})
        .then((result) => {
            if(result){
                var outletData = result;
                this.showSpinner = false;
                for(let account in outletData){
                        for(let outlet in this.listOfOutletsResult){
                            if(outletData[account].TargetId === this.listOfOutletsResult[outlet].accountId){
                                this.selectedOutlets.push(this.listOfOutletsResult[outlet]);
                                this.selectedOutletIds.add(this.listOfOutletsResult[outlet].accountId);
                                this.listOfOutletsResult[outlet]['isCheckboxSelected'] = true;
                            }
                        }
                }
                
            }  
        })
        .catch((error) => {
            this.error = error;
        });
    }

    handleRoleSelection(event){
        var val = event.target.value;
        this.employeeType = val;
        this.outletEmployeeDetail.employeeType = val;
        if(val == 'Outlet Manager'){
            this.isStaff = false;
            this.isManager = true;
        }
        if(val == 'Outlet Staff'){
            this.isManager = false;
            this.isStaff = true;
        }   
    }

    handleMobileNumberChange(event){

        this.buttonDisabled = true;
        const inputValue = event.target.value;
        const isValidPhoneNumber = /^\d{10,13}$/.test(inputValue);
        if (isValidPhoneNumber || (inputValue === "")) {
            this.buttonDisabled = false;
            this.phone = inputValue;
        } else {
            this.phone = '';
            this.buttonDisabled = true;
        }
    }

    handleEmpFirstName(event){
        this.firstName = event.target.value;
    }

    handleEmpLastName(event){
        this.lastName = event.target.value;
    }

    openOutletModal(){
        this.userModal = false;
        this.outletModal = true;
    }

    handleCheckboxChange(event){
        const outletId = event.target.dataset.id;
        const selectedAccount = this.listOfOutletsResult.find(acc => acc.accountId === outletId);

        if(event.target.checked){
            for(let acc in this.listOfOutletsResult){
                if(this.listOfOutletsResult[acc].accountId === outletId){
                    this.listOfOutletsResult[acc]['isCheckboxSelected'] = true;
                }
            }
            this.selectedOutletIds.add(outletId);
            this.selectedOutlets.push(selectedAccount);
        }
        else{
            for(let acc in this.listOfOutletsResult){
                if(this.listOfOutletsResult[acc].accountId === outletId){
                    this.listOfOutletsResult[acc]['isCheckboxSelected'] = false;
                }
            }
            this.selectedOutletIds.delete(outletId);
            this.selectedOutlets = this.selectedOutlets.filter(acc => acc.accountId !== outletId);
        }
    }

    removeOutlet(event){
        const outletId = event.target.dataset.id;
        for(let acc in this.listOfOutletsResult){
            if(this.listOfOutletsResult[acc].accountId === outletId){
                this.listOfOutletsResult[acc]['isCheckboxSelected'] = false;
            }
        }
        this.selectedOutletIds.delete(outletId);
        this.selectedOutlets = this.selectedOutlets.filter(acc => acc.accountId !== outletId);

    }

    handleOutletModalClose(){
        this.outletModal = false;
        this.userModal = true;
    }

    handleOutletModalAccept(){
        this.outletModal = false;
        this.userModal = true;
    }

    handleModalCancel(){
    //reset the modal
        this.dispatchEvent(new CustomEvent('modalcancel'));
    }

    //submit handler
    handleModalContinue(){
        if (!this.firstName) {
            // Handle missing firstName
            
            this.firstName=this.outletEmployeeDetail.firstName;
        }
        if (!this.lastName) {
            // Handle missing lastName
            
            this.lastName=this.outletEmployeeDetail.lastName;
        }
        if (!this.employeeType) {
            // Handle missing employeeType
            
            this.employeeType=this.outletEmployeeDetail.employeeType;
            //val=this.employeeType;
            if(this.employeeType == 'Outlet Manager'){
                this.isStaff = false;
                this.isManager = true;
            }
            if(this.employeeType == 'Outlet Staff'){
                this.isManager = false;
                this.isStaff = true;
            }  
        }
        if (!this.email) {
            // Handle missing email
            
            this.email=this.outletEmployeeDetail.email;
        }
        if(this.isManager && this.selectedOutletIds.size == 0){
            this.noOutletsSelected = true;
        } 
        else{
            if(this.isStaff){
                this.selectedOutletIds.clear();
                this.selectedOutletIds.add(this.effectiveAccountId);
            }
            this.requiredFieldError = false;
             this.showSpinner = true;
            this.outletEmployeeDetail.firstName = this.firstName;
            this.outletEmployeeDetail.lastName = this.lastName;
            this.outletEmployeeDetail.email = this.email;
            this.outletEmployeeDetail.employeeType = this.employeeType;
            this.outletEmployeeDetail.contactIdvalue = this.contactId;
            if(this.phone){
                this.outletEmployeeDetail.phone = this.phone;
            }

            const outletIdSetAsArray = Array.from(this.selectedOutletIds);
            updateEmployeeContact({
                employeeDetail : JSON.stringify(this.outletEmployeeDetail),
                outletIdList : JSON.stringify(outletIdSetAsArray),
                selectedContact : JSON.stringify(this.contactId)
            })
            .then((result) => {
                console.log('result is console data:', result)
                this.showSpinner = false;
                console.log('this.outletEmployeeDetail',this.outletEmployeeDetail);
                const event = new CustomEvent('modalclose', {
                 detail: this.outletEmployeeDetail
                 });
                 this.dispatchEvent(event);
              
            })
            .catch((error) => {
                console.error(error);
            })
        }   
    }
}