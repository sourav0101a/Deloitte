import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { restartCheckout } from 'commerce/checkoutApi';
import continueLabel from '@salesforce/label/c.CCEP_Continue_Button';
import or from '@salesforce/label/c.CCEP_Or';
import addMoreItems from '@salesforce/label/c.CCEP_Add_More_Items_To_Basket';


export default class CcepBuilderGoToCheckout extends NavigationMixin(LightningElement) {

    static renderMode = 'light';

    labels = {
        continueLabel,
        or,
        addMoreItems
    }

    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

    _cartStatus;
    _checkoutDisabled = true;

    @api
    get cartStatus(){
        return this._cartStatus;
    }
    set cartStatus(value){
        console.log('@@## Cart Status', value);
        if(value && (value === 'Active' || value === 'Checkout')){
            this._cartStatus = value;
            this.checkoutDisabled = false;
        }
    }

    get checkoutDisabled(){
        return this._checkoutDisabled;
    }
    set checkoutDisabled(value){
        this._checkoutDisabled = value;
    }

    async continueToCheckout(event){
        event.stopPropagation();
        await restartCheckout();
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: '/checkout'
            }
        });
    }

    goHome(event){
        event.stopPropagation();
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'Home',
            },
        });
    }

}