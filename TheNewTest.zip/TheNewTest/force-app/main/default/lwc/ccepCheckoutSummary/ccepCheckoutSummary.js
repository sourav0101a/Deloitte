import { LightningElement,api } from 'lwc';
import subtotal from '@salesforce/label/c.CCEP_Subtotal';
import cartDisclaimer1 from '@salesforce/label/c.CCEP_Cart_Disclaimer';
import cartDisclaimer2 from '@salesforce/label/c.CCEP_Cart_Disclaimer_2';
import total from '@salesforce/label/c.CCEP_Total';
import CCEP_SelectedDate from '@salesforce/label/c.CCEP_SelectedDate';
import CCEP_DeliveryAddress from '@salesforce/label/c.CCEP_DeliveryAddress';
import CCEP_OrderSummary from '@salesforce/label/c.CCEP_OrderSummary';
import CCEP_Summary from '@salesforce/label/c.CCEP_Summary';
import CCEP_Your_Order from '@salesforce/label/c.CCEP_Your_Order';
import CCEP_OrderSummaryDisclaimer from '@salesforce/label/c.CCEP_OrderSummaryDisclaimer';
import CCEP_DeliveryDate from '@salesforce/label/c.CCEP_DeliveryDate';
import CCEP_Taxes from '@salesforce/label/c.CCEP_Taxes';
import CCEP_Discounts from '@salesforce/label/c.CCEP_Discounts';

export default class CcepCheckoutSummary extends LightningElement {
    // Pending currency iso code

    static renderMode = 'light';
    _cart;
    _shippingAddress;
    _selectedDate;
    _totalTax;
    _discounts;
    _cartItems;
    _promotionsApplied;
    _deliveryDisclaimer;

    labels = {
        subtotal,
        cartDisclaimer1,
        cartDisclaimer2,
        total,
        CCEP_SelectedDate,
        CCEP_DeliveryAddress,
        CCEP_OrderSummary,
        CCEP_Summary,
        CCEP_Your_Order,
        CCEP_OrderSummaryDisclaimer,
        CCEP_DeliveryDate,
        CCEP_Taxes,
        CCEP_Discounts
    }


    @api
    get cart() {
        return this._cart;
    }
    set cart(value) {
        console.log('Summary Items', JSON.parse(JSON.stringify(value)));
        this._cart = value;
    }

    @api
    get shippingAddress() {
        return this._shippingAddress;
    }
    set shippingAddress(value) {
        this._shippingAddress = value;
    }

    @api
    get selectedDate() {
        return this._selectedDate;
    }
    set selectedDate(value) {
        this._selectedDate = value;
    }

    @api
    get promotionsApplied() {
        return this._promotionsApplied;
    }
    set promotionsApplied(value) {
        console.log('Promos Applied', JSON.parse(JSON.stringify(value)));
        this._promotionsApplied = value;
    }

    @api
    get deliveryDisclaimer() {
        return this._deliveryDisclaimer;
    }
    set deliveryDisclaimer(value) {
        this._deliveryDisclaimer = value;
    }


    get showDiscounts() {
        return this.cart.cartSummary.CCEP_TotalAdjustment__c < 0;
    }



    


}