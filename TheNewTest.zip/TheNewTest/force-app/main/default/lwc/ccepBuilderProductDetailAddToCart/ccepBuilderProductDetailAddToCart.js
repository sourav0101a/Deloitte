import { LightningElement,api } from 'lwc';
import { createCartItemAddAction, dispatchAction } from 'commerce/actionApi';
import isProductAvailable from '@salesforce/apex/CCEP_ProductDetailsController.isProductAvailable';
import CCEP_Products_Added_Title from '@salesforce/label/c.CCEP_Products_Added_Title';

export default class CcepBuilderProductDetailAddToCart extends LightningElement {

    static renderMode = 'light';

    labels = {
        CCEP_Products_Added_Title
    }

    _showModal = false;
    _productDetail;
    _productPricing;
    _units = 1;

    productNameAddedToCart;
    unitsAddedToCart;
    pricesAddedToCart;

    @api
    get productDetail() {
        return this._productDetail;
    }

    set productDetail(value) {
        if(value){
            this.composeProductStock(value);
        }
    }

    get showModal() {
        return this._showModal;
    }
    set showModal(value) {
        this._showModal = value;
    }

    @api
    get productPricing() {
        return this._productPricing;
    }
    set productPricing(value) {
        this._productPricing = value;
    }

    get units() {
        return this._units;
    }

    async isProductAvailable(productId){
        const productAvailable = await isProductAvailable({effectiveAccountId: sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID'), productId: productId});
        return productAvailable;
    }

    async composeProductStock(value){
        let productAvailability = await this.isProductAvailable(value.id);
        let productInfo = JSON.parse(JSON.stringify(value));
        productInfo.outOfStock = !productAvailability;
        this._productDetail = productInfo;
    }

    handleChangeUnits(e) {
        this._units = e.detail.units;
    }

    handleAddToCart() {
        this.productIdAddedToCart = this.productDetail.id;
        this.productNameAddedToCart = this.productDetail.fields.Name;
        this.unitsAddedToCart = this.units;
        this.pricesAddedToCart = this.productPricing;
        dispatchAction(this, createCartItemAddAction(this.productDetail.id, this.units), {
            onSuccess: () => {
               this.showModal = true;
            },
        });
    }

    modalClosed(){
        this.showModal = false;
    }

}