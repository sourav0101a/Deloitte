import { LightningElement, track, api, wire } from 'lwc';
import communityId from '@salesforce/community/Id';
import { getRecord } from 'lightning/uiRecordApi';
import userId from '@salesforce/user/Id';
import userEmployeeType from '@salesforce/schema/User.Contact.EmployeeType__c';
//importing custom labels for spanish literals - User Detail Section
import email from '@salesforce/label/c.CCEP_Email';
import firstName from '@salesforce/label/c.CCEP_First_name';
import lastName from '@salesforce/label/c.CCEP_Surname';
import duplicateEmailError from '@salesforce/label/c.CCEP_Duplicate_Email_Error';
import landlineNumber from '@salesforce/label/c.CCEP_Landline_number';
import mobileNumber from '@salesforce/label/c.CCEP_Mobile_number';
import contactInformationFieldRequired from '@salesforce/label/c.CCEP_Contact_Information_Field_Required';
import createUserHeader from '@salesforce/label/c.CCEP_Create_employee_header';
import associatedOutletsHeader from '@salesforce/label/c.CCEP_Associated_Outlets';
import addOutlet from '@salesforce/label/c.CCEP_Add_Outlet';
import invalidEmailError from '@salesforce/label/c.CCEP_Email_Validation';
import role from '@salesforce/label/c.CCEP_Role';
import staff from '@salesforce/label/c.CCEP_Staff';
import manager from '@salesforce/label/c.CCEP_Manager';
import cancelButton from '@salesforce/label/c.CCEP_Cancel';
import createButton from '@salesforce/label/c.CCEP_Create_Button';
import acceptButton from '@salesforce/label/c.CCEP_Accept';
import chooseOutlets from '@salesforce/label/c.CCEP_Choose_Outlets';
import continueButton from '@salesforce/label/c.CCEP_Continue_Button';
import removeButton from '@salesforce/label/c.CCEP_Remove_Button';
import userSuccess from '@salesforce/label/c.CCEP_User_Creation_Success';
//import apex functionality
import getListOfOutlets from '@salesforce/apex/CCEP_OutletRegistrationController.getListOfOutlets';
import getEmailValidity from '@salesforce/apex/CCEP_OutletEmployeeController.getEmailValidity';
// import createOutletEmployee from '@salesforce/apex/CCEP_OutletEmployeeController.createEmployeeAccount';
import createOutletEmployee from '@salesforce/apex/CCEP_OutletEmployeeController.createEmployeeContact';


export default class CcepCreateEmployeeForm extends LightningElement {

    userModal = true;
    outletModal = false;
    showSpinner = false;
    isSubmitted = false;
    userType;

    loggedInManager = false;

    invalidEmail = false;
    duplicateEmail = false;
    role ='';
    requiredFieldError = false;
    @track listOfOutletsResult = [];
    isManager = false;
    isStaff = false;
    isCheckboxSelected = false;
    isRadioButtonSelected = false;
    noOutletsSelected = false;

    //in case of manager, multiple outlets can be selected
    @track selectedOutletIds = new Set(); //to be sent as associated outlet ids to apex
    @track selectedOutlets = []; //used to display the outlet names after selection

    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

    @track outletEmployeeDetail = {
        firstName : '',
        lastName : '',
        employeeType : '',
        email : '',
        phone : ''
    };

    label = {
        firstName,
        email,
        duplicateEmailError,
        lastName,
        role,
        landlineNumber,
        mobileNumber,
        contactInformationFieldRequired,
        associatedOutletsHeader,
        addOutlet,
        chooseOutlets,
        invalidEmailError,
        createUserHeader,
        cancelButton,
        createButton,
        acceptButton,
        continueButton,
        removeButton,
        userSuccess,
        staff,
        manager
    };

    get roleOptions() {
        return [
            { label: this.label.manager, value: 'Outlet Manager' },
            { label: this.label.staff, value: 'Outlet Staff' }
        ];
    }

    //roles to display if manager is logged-in user
    get managerRoleOptions() {
        return [
            { label: this.label.staff, value: 'Outlet Staff' }
        ];
    }

    //get account id of logged in user
    @wire(getRecord, {
        recordId: userId,
        fields: [userEmployeeType]
    }) currentUserType({
        error,
        data
    }) {
        if (error) {
        this.error = error ; 
        } else if (data) {
            console.log('User dets'+data);
            this.userType = data.fields.Contact.value.fields.EmployeeType__c.value;
            if(this.userType == 'Outlet Manager'){
                this.loggedInManager = true;
            }
        }
    }

    //get list of outlets details with address
    connectedCallback() {      
        console.log('@@##communityId ' + communityId);  
        getListOfOutlets({communityId: communityId})
        .then((result) => {
            if(result){
                this.listOfOutletsResult = result.externalManagedAccounts;

                for(let acc in this.listOfOutletsResult){
                    if(this.effectiveAccountId === this.listOfOutletsResult[acc].accountId){
                        this.selectedOutlet = this.listOfOutletsResult[acc].accountName;
                    }
                }
            }  
        })
        .catch((error) => {
            this.error = error;
            console.log('Error in connected callback is', this.error); 
        });
    }

    handleEmailChange(event){
        const emailRegex = /^[a-zA-Z0-9._-]+(\+[a-z0-9-]+)?@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        this.email = event.detail.value;
        if(!emailRegex.test(this.email)){
            this.invalidEmail = true;
            this.duplicateEmail = false;
        }
        else
            this.invalidEmail = false;
            this.requiredFieldError = false;
    }

    handleRoleSelection(event){
        var val = event.target.value;
        this.employeeType = val;
        if(val == 'Outlet Manager'){
            this.isStaff = false;
            this.isManager = true;
        }
        if(val == 'Outlet Staff'){
            this.isManager = false;
            this.isStaff = true;
        }   
    }

    handleMobileNumberChange(event){
        this.phone = event.target.value;

    }

    handleEmpFirstName(event){
        this.firstName = event.target.value;
    }

    handleEmpLastName(event){
        this.lastName = event.target.value;
    }

    openOutletModal(){
        this.userModal = false;
        this.outletModal = true;
    }

    handleCheckboxChange(event){
        const outletId = event.target.dataset.id;
        const selectedAccount = this.listOfOutletsResult.find(acc => acc.accountId === outletId);

        if(event.target.checked){
            for(let acc in this.listOfOutletsResult){
                if(this.listOfOutletsResult[acc].accountId === outletId){
                    this.listOfOutletsResult[acc]['isCheckboxSelected'] = true;
                }
            }
            this.selectedOutletIds.add(outletId);
            this.selectedOutlets.push(selectedAccount);
        }
        else{
            for(let acc in this.listOfOutletsResult){
                if(this.listOfOutletsResult[acc].accountId === outletId){
                    this.listOfOutletsResult[acc]['isCheckboxSelected'] = false;
                }
            }
            this.selectedOutletIds.delete(outletId);
            this.selectedOutlets = this.selectedOutlets.filter(acc => acc.accountId !== outletId);
        }
    }

    removeOutlet(event){
        const outletId = event.target.dataset.id;
        for(let acc in this.listOfOutletsResult){
            if(this.listOfOutletsResult[acc].accountId === outletId){
                this.listOfOutletsResult[acc]['isCheckboxSelected'] = false;
            }
        }
        this.selectedOutletIds.delete(outletId);
        this.selectedOutlets = this.selectedOutlets.filter(acc => acc.accountId !== outletId);

    }

    handleOutletModalClose(){
        this.outletModal = false;
        this.userModal = true;
    }

    handleOutletModalAccept(){
        this.outletModal = false;
        this.userModal = true;
    }

    handleModalCancel(){
        //reset the modal
        this.firstName = '';
        this.lastName = '';
        this.email = '';
        this.phone = '';
        this.employeeType = '';
        for(let acc in this.listOfOutletsResult){
            this.listOfOutletsResult[acc]['isCheckboxSelected'] = false;
        }
        this.selectedOutlets = [];
        this.selectedOutletIds.clear();

        this.dispatchEvent(new CustomEvent('modalcancel'));
    }

    validateEmail(){
        console.log('inside validate Emmai : ' + this.email);
        if(!this.invalidEmail){
            getEmailValidity({
                email : this.email
            })
            .then((result) =>{
                if(result == false){
                    console.log('invalid email id : ' +result);
                    this.duplicateEmail = true;
                }
                else{
                    this.handleModalContinue();
                }
            })
            .catch((error) =>{
                console.log('Error is', error);
            })
        }  
    }

    //submit handler
    handleModalContinue(){
        console.log('insisde handle continue');
        
        if(!this.firstName || !this.lastName || !this.employeeType || !this.email){
            this.requiredFieldError = true;
        }
        else if(this.isManager && this.selectedOutletIds.size == 0){
            this.noOutletsSelected = true;
        } 
        else{
            if(this.isStaff && this.selectedOutletIds.size == 0){
                this.selectedOutletIds.clear();
                this.selectedOutletIds.add(this.effectiveAccountId);
            }
            this.requiredFieldError = false;
            // this.showSpinner = true;
            this.outletEmployeeDetail.firstName = this.firstName;
            this.outletEmployeeDetail.lastName = this.lastName;
            this.outletEmployeeDetail.email = this.email;
            this.outletEmployeeDetail.employeeType = this.employeeType;
            var countryCode = '+34';
            if(this.phone){
                this.outletEmployeeDetail.phone = countryCode + this.phone;
            }
            else{
                this.outletEmployeeDetail.phone = '';
            }
            
            console.log('selectedOutletIds : ' + JSON.stringify(this.selectedOutletIds));

            const outletIdSetAsArray = Array.from(this.selectedOutletIds);

            console.log('outlet employee details : ' + JSON.stringify(this.outletEmployeeDetail));
            console.log('outlet ids : ' + JSON.stringify(outletIdSetAsArray));

            createOutletEmployee({
                employeeDetail : JSON.stringify(this.outletEmployeeDetail),
                outletIdList : JSON.stringify(outletIdSetAsArray),
                isPortalUser : true
            })
            .then((result) => {
                console.log('inside result of create employee');
                console.log(result);
                this.isSubmitted = true;

            })
            .catch((error) => {
                console.log('inside error of create employee');
                console.error(error);
            })
        }   
    }

    handleFinalContinue(event){
        this.dispatchEvent(new CustomEvent('modalclose'));
    }
}