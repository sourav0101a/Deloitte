import { LightningElement, api } from 'lwc';

export default class CcepCartDetail extends LightningElement {

    static renderMode = 'light';

    @api
    cartItems;

    @api
    currencyIsoCode;

    get itemIdToDelete() {
        return this._itemIdToDelete;
    }
    set itemIdToDelete(value) {
        this._itemIdToDelete = value;
    }

    updateCartItem(event){
        this.dispatchEvent(
            new CustomEvent('updatecartitem', {
                detail: {
                    itemId: event.detail.itemId,
                    units: event.detail.units
                }
            })
        );
    }

    deleteCartItem(event){
        this.dispatchEvent(
            new CustomEvent('deletecartitem', {
                detail: {
                    itemId: event.detail.itemId
                }
            })
        );
    }

}