import { LightningElement, wire } from 'lwc';
import { CartSummaryAdapter } from 'commerce/cartApi';

export default class CcepBuilderCartBadge extends LightningElement {

    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

    _items;

    get items() {
        return this._items;
    }
    set items(value) {
        this._items = value;
    }

    @wire(CartSummaryAdapter, { effectiveAccountId: '$effectiveAccountId'})
    onCartSummaryAdapter(result) {
        if(result && result.data){
            console.log('@@## Number of Cart Items', Number(result.data.totalProductCount));
            this.items = Number(result.data.totalProductCount);
        }
    }

}