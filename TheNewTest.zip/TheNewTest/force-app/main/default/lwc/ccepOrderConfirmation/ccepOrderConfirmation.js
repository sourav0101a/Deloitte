import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

import CCEP_Order_Succesfully_Created from '@salesforce/label/c.CCEP_Order_Succesfully_Created';
import CCEP_Your_Order from '@salesforce/label/c.CCEP_Your_Order';
import CCEP_Delivery_Date from '@salesforce/label/c.CCEP_Delivery_Date';
import CCEP_Delivery_Address from '@salesforce/label/c.CCEP_Delivery_Address';
import CCEP_Date_Selected from '@salesforce/label/c.CCEP_Date_Selected';
import CCEP_Deliver_To from '@salesforce/label/c.CCEP_Deliver_To';
import CCEP_Realized from '@salesforce/label/c.CCEP_Realized';
import CCEP_Order_Status from '@salesforce/label/c.CCEP_Order_Status';
import CCEP_Go_To_Homepage from '@salesforce/label/c.CCEP_Go_To_Homepage';

export default class CcepOrderConfirmation extends NavigationMixin(LightningElement) {

    static renderMode = 'light';

    labels = {
        CCEP_Order_Succesfully_Created,
        CCEP_Your_Order,
        CCEP_Delivery_Date,
        CCEP_Delivery_Address,
        CCEP_Date_Selected,
        CCEP_Deliver_To,
        CCEP_Realized,
        CCEP_Order_Status,
        CCEP_Go_To_Homepage
    }

    _orderNumber;
    _orderedDate;
    _status;
    _address;
    _orderSummaryId;


    @api
    get orderSummaryId() {
        return this._orderSummaryId;
    }
    set orderSummaryId(value) {
        this._orderSummaryId = value;
    }

    @api
    get address() {
        return this._address;
    }
    set address(value) {
        this._address = value;
    }

    @api
    get orderNumber() {
        return this._orderNumber;
    }
    set orderNumber(value) {
        this._orderNumber = value;
    }

    @api
    get orderedDate() {
        return this._orderedDate;
    }
    set orderedDate(value) {
        this._orderedDate = value;
    }
    
    @api
    get status() {
        return this._status;
    }
    set status(value) {
        this._status = value;
    }

    get displayAddressLine1(){
        let addressLine1 = '';
        if(this.address){
            addressLine1 = this.address.postalCode + ', ' + this.address.street;
        }
        return addressLine1;
    }
    get displayAddressLine2(){
        let addressLine2 = '';
        if(this.address){
            addressLine2 = this.address.city + ', ' + this.address.province;
        }
        return addressLine2;
    }

    get deliveryDate() {
        let deliveryDate;
        if(this.address){
            deliveryDate = this.address.deliveryDate;
        }
        return deliveryDate;
    }

    handleGoToOrderDetail(event){
        event.stopPropagation();
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                objectApiName: "OrderSummary",
                recordId: this.orderSummaryId,
                actionName: 'view'
            }
        });
    }

    handleGoToHomepage(event){
        event.stopPropagation();
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: '/'
            }
        });
    }
}