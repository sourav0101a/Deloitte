import { LightningElement, wire, api } from 'lwc';
import { OrderAdapter, OrderDeliveryGroupsAdapter } from 'commerce/orderApi';
import { getLanguage } from "c/ccepCommerceUtils";
import getOrderIdForOrderNumber from "@salesforce/apex/CCEP_OrderController.getOrderIdForOrderNumber";
import { refreshCartSummary } from 'commerce/cartApi';

const ORDER_FIELDS = ['CCEP_DeliveryDate__c'];
const ADDRESS_FIELDS = ['OrderDeliveryGroupSummary.DeliverToAddress', 'OrderDeliveryGroupSummary.DesiredDeliveryDate'];
const MAX_CALLS = 20;
const MAX_TIME = 3000;

export default class CcepBuilderOrderConfirmation extends LightningElement {

    static renderMode = 'light';

    effectiveAccountId = sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');
    
    orderData;
    orderAddressData;

    _orderNumber;
    currentOrderId;
    _isLoading = false;

    @api
    get orderNumber() {
        return this._orderNumber;
    }
    set orderNumber(value) {
        this._orderNumber = value;
    }

    get isLoading(){
        return this._isLoading;
    }
    set isLoading(value){
        this._isLoading = value;
    }

    async connectedCallback(){
      const urlParams = new URLSearchParams(window.location.search);
      let orderNumberParam = urlParams.get('orderNumber');
      console.log('*** connectedCallback -> orderNumberParam is -> ', orderNumberParam);
      this._orderNumber = await this.performGetOrderSummaryId(orderNumberParam);
    //   this.currentOrderId = this._orderNumber;
      console.log('*** connectedCallback -> orderNumber is -> ', this.orderNumber);
    }


    @wire(OrderAdapter, { effectiveAccountId: '$effectiveAccountId', orderSummaryId :  "$orderNumber", fields: ORDER_FIELDS})
    async onGetOrderAdapter({ data,error }) {
        if (data && !data.hasErrors) {
           console.log('*** OrderAdapter data is -> ',JSON.parse(JSON.stringify(data)));
           this.orderData = {
                orderNumber: data.orderNumber,
                orderSummaryId: data.orderSummaryId,
                orderedDate: this.formatDate(data.orderedDate),
                status: data.status
              };
              this.currentOrderId = data.orderSummaryId;
              console.log('*** this.orderData is -> ',JSON.parse(JSON.stringify(this.orderData)));
              //await refreshCartSummary();
        } else {
            console.log('error',error);
        }
    }

    @wire(OrderDeliveryGroupsAdapter, { effectiveAccountId: '$effectiveAccountId', orderSummaryId :  "$orderNumber", fields: ADDRESS_FIELDS})
    async onGetOrderDeliveryGroupsAdapter({ data,error }) {
        if (data && !data.hasErrors) {
           console.log('*** OrderDeliveryGroupsAdapter data is -> ',JSON.parse(JSON.stringify(data)));
           let addressResult = data.orderDeliveryGroups[0].fields["OrderDeliveryGroupSummary.DeliverToAddress"].text;
           let deliveryDate = data.orderDeliveryGroups[0].fields["OrderDeliveryGroupSummary.DesiredDeliveryDate"].text;
           if(addressResult && deliveryDate){
                addressResult = addressResult.substring(
                    addressResult.indexOf("[") + 1, 
                    addressResult.lastIndexOf("]")).split(',');
                
                console.log('*** el state es: ' + addressResult[2]);
                console.log('*** el state es true ? ' + addressResult[2] !== 'null');
                console.log('*** el state es true ? 2 ' + addressResult[2] != null);
                this.orderAddressData = {
                        street: addressResult[0] !== ' null' ? addressResult[0] : '',
                        city: addressResult[1] !== ' null' ? addressResult[1] : '',
                        province: addressResult[2] !== ' null' ? addressResult[2] : '',
                        postalCode: addressResult[3] !== ' null' ? addressResult[3] : '',
                        country: addressResult[4] !== ' null' ? addressResult[4] : '',
                        deliveryDate: this.formatDate(deliveryDate)
                };
                console.log('*** this.orderAddressData is -> ',JSON.parse(JSON.stringify(this.orderAddressData)));
                //await refreshCartSummary();
           }
           
        } else {
            console.log('error',error);
        }
    }

    /* eslint-disable no-await-in-loop */
    async performGetOrderSummaryId(orderNumberParam){
        this._isLoading = true;
        let orderId;
        let counter = 0;
        while(counter <= MAX_CALLS) {
            console.log('*** performGetOrderSummaryId -> orderId before if: ',orderId);
            if(orderId === undefined || orderId == null || orderId === '') {
                console.log('*** performGetOrderSummaryId -> counter: ',counter);
                await this.timeout(MAX_TIME);
                console.log('*** performGetOrderSummaryId -> after await -> orderNumberParam is : ',orderNumberParam);
                orderId = await getOrderIdForOrderNumber({orderNumber : orderNumberParam});
                console.log('*** performGetOrderSummaryId -> orderId: ',orderId);
                counter++;
            }
            else{
                break;
            }
        }
        console.log('*** performGetOrderSummaryId -> to return: ',orderId);
        if(orderId != null){
            this._isLoading = false;
        }
        return orderId;
    }

    // eslint-disable-next-line @lwc/lwc/no-async-operation
    timeout = (ms) => new Promise(resolve => setTimeout(resolve, ms));
    
    formatDate(date) {
        let formatedDate;
        let format =  {
            day: "2-digit",
            month: "long",
            year: "numeric"
        };
        if(date){
            formatedDate = new Intl.DateTimeFormat(getLanguage(), format).format(new Date(date));
        }
        return formatedDate;
    }
}