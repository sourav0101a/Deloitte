import { LightningElement, api,track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import noClaims from '@salesforce/label/c.CCEP_No_Claims_Message';
import claimHeader from '@salesforce/label/c.CCEP_Claim_Header';
import myClaims from '@salesforce/label/c.CCEP_My_Claims';
import newClaim from '@salesforce/label/c.CCEP_New_Claim_Button';
export default class CcepClaimResult extends NavigationMixin(LightningElement) {
    static renderMode="light";

    @api claimResults;
    
    //For Pagination
    @track manualPagination = true
    visibleClaims
    perPageRecordSize = 5

    noClaims = false;

    labels = {
        noClaims,
        claimHeader,
        myClaims,
        newClaim
    }

    connectedCallback(){
        if(this.claimResults.length == 0){
            this.noClaims = true;
        }
    }

    get totalItemCount() {
        return this.claimResults.length
    }

    //Pagination Toggle Change
    handleToggleChange(event){
        this.manualPagination = Boolean(event.detail.checked)
        console.log("manualPagination-- "+this.manualPagination)
        if(!this.manualPagination){
            this.visibleClaims =[...this.claimResults]
        }
    }

    updateClaimsHandler(event){
        this.visibleClaims=[...event.detail.records]
        //console.log('visible records--'+JSON.stringify(this.visibleClaims))
    }

    navigateToNewClaimPage(){
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
               url:'/add-new-claim'
          }
           });
    }
}