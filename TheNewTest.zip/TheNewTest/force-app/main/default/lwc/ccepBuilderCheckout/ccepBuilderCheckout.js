import { LightningElement,wire } from 'lwc';
import { loadCheckout,notifyCheckout,placeOrder,restartCheckout,waitForCheckout, CheckoutInformationAdapter, updateShippingAddress} from 'commerce/checkoutApi';
import { CartItemsAdapter, CartSummaryAdapter, refreshCartSummary } from 'commerce/cartApi';
import getOutletVisit from '@salesforce/apex/CCEP_DeliveryCalendarController.getOutletVisit';
import getHolidaysByDistributor from '@salesforce/apex/CCEP_DeliveryCalendarController.getHolidaysByDistributor';
import getDeliveryDelay from '@salesforce/apex/CCEP_DeliveryCalendarController.getDeliveryDelay';
import getAddress from '@salesforce/apex/CCEP_DeliveryCalendarController.getAddress';
import getCountryCodeForCountryName from '@salesforce/apex/CCEP_DeliveryCalendarController.getCountryCodeForCountryName';
import startCalculatePriceContinuationSAP from '@salesforce/apexContinuation/CCEP_CalculatePriceContinuationSAP.startRequest';
import calculatePricesMirakl from '@salesforce/apex/CCEP_CalloutPriceMirakl.calculatePricesMirakl';
import getCartItems from '@salesforce/apex/CCEP_CheckoutController.getCartItems';
import getCartTotals from '@salesforce/apex/CCEP_CheckoutController.getCartTotals';
import getPromotionsApplied from '@salesforce/apex/CCEP_CheckoutController.getPromotionsApplied';
import { getMonthsAndDisclaimerDate, getDeliveryDisclaimer, DAY_OF_WEEK, getSelectedDateText } from 'c/ccepDeliveryCalendarUtils';
import {NavigationMixin} from 'lightning/navigation';

// Labels
import CCEP_January from '@salesforce/label/c.CCEP_January';
import CCEP_February from '@salesforce/label/c.CCEP_February';
import CCEP_March from '@salesforce/label/c.CCEP_March';    
import CCEP_April from '@salesforce/label/c.CCEP_April';
import CCEP_May from '@salesforce/label/c.CCEP_May';
import CCEP_June from '@salesforce/label/c.CCEP_June';
import CCEP_July from '@salesforce/label/c.CCEP_July';
import CCEP_August from '@salesforce/label/c.CCEP_August';
import CCEP_September from '@salesforce/label/c.CCEP_September';
import CCEP_October from '@salesforce/label/c.CCEP_October';
import CCEP_November from '@salesforce/label/c.CCEP_November';
import CCEP_December from '@salesforce/label/c.CCEP_December';


export default class CcepBuilderCheckout extends NavigationMixin(LightningElement) {
    static renderMode = 'light';
    // URL for api calls
    checkoutsUri;
    cartUri;

    // Local vars
    effectiveAccountId = sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');
    months = [];
    monthSelected = 0;
    outletVisit;
    holidays;
    deliveryDelay;
    dateSelected;
    disclaimerDate;
    workingDays;
    nonWorkinDays;
    _isDateSelected = false;
    _shippingAddress;
    _cartSummary;
    _cart;
    _cartId;
    _showOrderSummary = false;
    _allowPlaceOrder = true;
    _isLoading = false;
    _cartQuery;
    _summaryCart;
    _promotionsApplied = [];


    monthsStrings = {
        0: CCEP_January,
        1: CCEP_February,
        2: CCEP_March,
        3: CCEP_April,
        4: CCEP_May,
        5: CCEP_June,
        6: CCEP_July,
        7: CCEP_August,
        8: CCEP_September,
        9: CCEP_October,
        10: CCEP_November,
        11: CCEP_December
    }


    @wire(CheckoutInformationAdapter)
    checkoutInformationAdapter({data,error}) {
        console.log('CheckoutInformationAdapter',data);
        if (error) {
            console.error('CheckoutInformationAdapter',error)
        } else if (data) {
            console.log('CheckoutInformationAdapter', data);
        }
    }

    @wire(getOutletVisit,{outletId: '$effectiveAccountId'})
    onOutletVisit({data,error}) {
        if (error) {
            console.log('error getting outletVisits',error)
        } else if (data) {
            this.outletVisit = data;
            this.generateAvailableDates();
        }
    }

    @wire(getDeliveryDelay,{effectiveAccountId:'$effectiveAccountId'})
    onDeliveryDate( {data,error}) {
        if (error) {
            console.log('error getting delivery dates',error)
        } else if (data) {
            this.deliveryDelay = data.CCEP_DeliveryDelay__c;
            let days = data.CCEP_DistributorWorkingDays__c.split(';');
            let workingDays = [];
            let nonWorkingDays = [];
            Object.entries(DAY_OF_WEEK).forEach( ([day,dayJs]) => {
                if (days.includes(day)) {
                    workingDays.push(dayJs)
                } else {
                    nonWorkingDays.push(dayJs);
                }
            });
            this.workingDays = workingDays;
            this.nonWorkinDays = nonWorkingDays;
            this.generateAvailableDates();
        }
    }
    
    @wire(getAddress,{effectiveAccountId:'$effectiveAccountId'})
    onShippingAddress( {data,error}) {
        if (error) {
            console.error('onShippingAddress',error)
        } else if (data) {
            this.shippingAddress = data;            
            console.log('shipping address',JSON.parse(JSON.stringify(this._shippingAddress)));
        }
    }

    @wire(getHolidaysByDistributor,{effectiveAccountId:'$effectiveAccountId'})
    onHolidays({data,error}) {
        if (error) {
            console.log('error getting holidays',error)
        } else if (data) {
            this.holidays = data.map(date => date.CCEP_Date__c);
            this.generateAvailableDates();          
        }
    }

    @wire(CartItemsAdapter, { effectiveAccountId: '$effectiveAccountId', CreatedDateDesc: 'CreatedDateDesc'})
    onGetCartItemsAdapter({ data,error }) {
        console.log('CartItemsAdapter', data);
        if (data && !data.hasErrors) {
            this._cart = data;
        } else {
            console.log('error',error);
        }
    }

    @wire(CartSummaryAdapter, { effectiveAccountId: '$effectiveAccountId'})
    onCartSummaryAdapter(result) {
        if(result && result.data){
            console.log('CartSummaryAdapter', result.data);
            this._cartId = result.data.cartId;
        }
    }

    generateAvailableDates () {
        let monthsAndDisclaimerDate = getMonthsAndDisclaimerDate(this.holidays, this.outletVisit, this.deliveryDelay, this.nonWorkinDays, this.workingDays);
        if(monthsAndDisclaimerDate){
            this.disclaimerDate = monthsAndDisclaimerDate.disclaimerDate;
            this.months = monthsAndDisclaimerDate.months;
        }
    }

    handleSelectedMonth (e) {
        this.monthSelected = e.detail.month;
    }

    handleSelectedDate (e) {
        this.dateSelected = e.detail.date;
        let selectedDate = e.detail.date.split('-').slice(-1)[0];
        this.disclaimerDate = new Date(this.dateSelected);
        this.months = this.months.map((month,i) => ({
                ...month, 
                dates: month.dates.map(date => ({
                    ...date,
                    class: (String(date.stringDate) === selectedDate && i === this.monthSelected) ? 'selected' : (date.class.includes('today') ? 'today' : '') 
                })
            )}
        ))
        this._isDateSelected = true;
    }


    async handle_placeOrder(){
        try{
            const res = await placeOrder();
            console.log('*** placeOrder',res);
            if(res && res.errors.length === 0){
                let params = '?orderNumber=' + res.orderReferenceNumber;
                this[NavigationMixin.GenerateUrl]({
                    type: 'standard__webPage',
                    attributes: {
                        url: '/order' + params
                    }
                }).then((orderResumeUrl) => {
                    window.location.href = orderResumeUrl;
                });
            }
        }catch(e){
            console.error('placeOrder',e)
        }
    }

    async composePatchBody(shippingAddress, disclaimerDate){
        let composedAddressBody = '';
        if(shippingAddress && disclaimerDate){
            let shippingAddressParsed = JSON.parse(JSON.stringify(shippingAddress));
            console.log('*** composeAddressBody -> shippingAddress is ',shippingAddressParsed);
            let countryObject = await getCountryCodeForCountryName({countryName: shippingAddressParsed.Country});
            console.log('*** composeAddressBody -> shippingcountryObjectAddress is ',JSON.parse(JSON.stringify(countryObject)));
            //let deliveryDate = disclaimerDate.getFullYear()  + '-' + (disclaimerDate.getMonth()+1) + '-' + disclaimerDate.getDate().length > 1 ? disclaimerDate.getDate() : '0' + disclaimerDate.getDate() + 'T00:00:00.000Z';
            composedAddressBody = {
                deliveryAddress: {
                    country: countryObject.CCEP_CountryCode__c,
                    city: shippingAddressParsed.City,
                    street: shippingAddressParsed.CCEP_Type_of_Road__c + ' ' + shippingAddressParsed.CCEP_Name_of_Road__c + ' ' + shippingAddressParsed.CCEP_Number__c,
                    postalCode: shippingAddressParsed.PostalCode,
                    region: shippingAddressParsed.State
                },
                desiredDeliveryDate: this.getFormattedDeliveryDate(disclaimerDate)
            }
        }
        console.log('*** composeAddressBody -> composedAddressBody is ', JSON.parse(JSON.stringify(composedAddressBody)));
        return composedAddressBody;
    }

    getFormattedDeliveryDate(disclaimerDate){
        const year = disclaimerDate.getFullYear().toString().length > 1 ? disclaimerDate.getFullYear() : '0' + disclaimerDate.getFullYear();
        const month = (disclaimerDate.getMonth()+1).toString().length > 1 ? (disclaimerDate.getMonth() + 1) : '0' + (disclaimerDate.getMonth() + 1);
        const day = disclaimerDate.getDate().toString().length > 1 ? disclaimerDate.getDate() : '0' + disclaimerDate.getDate();

        return year + '-' + month + '-' + day + 'T00:00:00.000Z';
    }

    
    async handleGoToOrderSummary(){
        try{
            this._isLoading = true;
            
            //await restartCheckout();

            let composedAddressBody = await this.composePatchBody(this.shippingAddress, this.disclaimerDate);
            const responsePatch = await updateShippingAddress(composedAddressBody);

            //const responsePatch = await setDeliveryDateAndAddressForCart(this.checkoutId, this.composePatchBody(this.shippingAddress, this.disclaimerDate));
            console.log('*** handleGoToOrderSummary -> response -> ',responsePatch);

            if(responsePatch.errors.length===0){
                let thereisSapProducts = this.cart.cartItems.some(cartItem => cartItem.cartItem.productDetails.sku !== '');
                if (thereisSapProducts) {
                    const response1 = await startCalculatePriceContinuationSAP({cartId: this._cartId, effectiveAccountId: this.effectiveAccountId});
                    console.log('startCalculatePriceContinuation',response1);
                    if (response1) {
                        this._promotionsApplied = await getPromotionsApplied({promoCodes: response1.PromotionsApplied.split(';')});
                    }

                }
                const response2 = await calculatePricesMirakl({cartId: this._cartId, effectiveAccountId: this.effectiveAccountId});
                console.log('calculatePricesMirakl',response2);

                let cart = JSON.parse(JSON.stringify(this._cart));
                cart.cartSummary = {...cart.cartSummary,... await getCartTotals({cartId: this._cartId})};
                let cartItemsExtraFields = await getCartItems({cartId: this._cartId});
                cart.cartItems = cart.cartItems.map(ci => ({...ci,cartItem: {...ci.cartItem,...cartItemsExtraFields[ci.cartItem.cartItemId]}}))
                this._summaryCart = cart;
                console.log('new Cart', JSON.parse(JSON.stringify(cart)));

                await refreshCartSummary();
                //await restartCheckout();
                this._showOrderSummary = true;
                this._isLoading = false;
            }
        }catch(e){
            console.error('handleGoToOrderSummary',e)
        }
    }

    get isDateSelected() {
        return this._isDateSelected;
    }

    get monthSelectedInfo () {
        return this.months[this.monthSelected];
    }

    get monthString () {
        return (this.monthSelectedInfo) ? this.monthsStrings[String(new Date(this.monthSelectedInfo.dates[0].stringDate).getMonth())] : '';
    }

    get fullYearSelected() {
        return (this.monthSelectedInfo) ? new Date(this.monthSelectedInfo.dates[0].stringDate).getFullYear() : '';
    }

    get disabledChevronsCalendar () {
        return this.months.length !== 2;
    }

    get deliveryDisclaimer(){
        return getDeliveryDisclaimer(this.disclaimerDate, this.deliveryDelay);    
    }

    get selectedDateText() {
        return getSelectedDateText(this.dateSelected);
    }

    get shippingAddress() {
        return this._shippingAddress;
    }
    set shippingAddress(value) {
        this._shippingAddress = value;
    }

    get isLoading(){
        return this._isLoading;
    }
    set isLoading(value){
        this._isLoading = value;
    }

    get cart() {
        return this._cart;
    }

    get showOrderSummary () {
        return this._showOrderSummary;
    }

    get allowPlaceOrder() {
        return this._allowPlaceOrder;
    }

    get summaryCart() {
        return this._summaryCart;
    }

    get promotionsApplied() {
        return this._promotionsApplied;
    }

    get disableGoToOrderSummaryButton(){
        return !(this.isDateSelected && this.cart);
    }
    


}