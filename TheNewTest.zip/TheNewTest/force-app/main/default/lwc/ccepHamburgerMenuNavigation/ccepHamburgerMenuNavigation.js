import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import back from '@salesforce/label/c.CCEP_Back';

export default class CcepHamburgerMenuNavigation extends NavigationMixin(LightningElement) {

    static renderMode = 'light';

    labels = {
        back
    }

    _navigation;
    _lastCategory = [];
    _selectedCategory;
    _navItemsToShow;

    @api
    get navigation() {
        return this._navigation;
    }
    set navigation(value) {
        if(value){
            this._navigation = JSON.parse(JSON.stringify(value));
            this.navItemsToShow = JSON.parse(JSON.stringify(value));
        }
    }

    get selectedCategory() {
        return this._selectedCategory;
    }

    set selectedCategory(value) {
        this._selectedCategory = value;
    }

    get navItemsToShow() {
        return this._navItemsToShow;
    }

    set navItemsToShow(value) {
        this._navItemsToShow = value;
    }

    get backOption(){
        return this.selectedCategory && true;
    }

    goToPreviousLevel(){
        let categoryHistory = [...this._lastCategory];
        this._selectedCategory = categoryHistory.pop();
        this._lastCategory = categoryHistory;
        if (this._selectedCategory) {
            this.navItemsToShow = this._selectedCategory.subMenu;
        } else {
            this.navItemsToShow = this.navigation;
        }
    }

    goToNextLevel(event){
        this._lastCategory.push(this.selectedCategory);
        this.selectedCategory = this.navItemsToShow.find(item => item.actionValue === event.currentTarget.dataset.id);
        this.navItemsToShow = this.selectedCategory.subMenu;
    }

    navigateToCategory(event){
        let categoryId = event.currentTarget.dataset.id.substr(event.currentTarget.dataset.id.length - 18);
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: categoryId,
                objectApiName: 'ProductCategory',
                actionName: 'view'
            }
        });
        this.dispatchEvent(new CustomEvent('navigated', {}));
    }

}