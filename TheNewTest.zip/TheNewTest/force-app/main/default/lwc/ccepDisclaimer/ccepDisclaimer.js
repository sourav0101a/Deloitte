import { LightningElement, api } from 'lwc';

export default class CcepDisclaimer extends LightningElement {

    static renderMode = 'light';

    @api
    text;

}