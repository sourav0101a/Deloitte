import { LightningElement, api } from "lwc";
import allergensIcons from "@salesforce/resourceUrl/ccep_allergen_icons";
import getProductAllergens from "@salesforce/apex/CCEP_ProductAllergenInfoController.getProductAllergens";

const ALLERGENS_PATH = "/allergens/";
const PNG_EXTENSION = ".png";

export default class CcepBuilderProductAllergenInformation extends LightningElement {
  _productDetail;
  _allergenInformation;

  @api
  get productDetail() {
    return this._productDetail;
  }
  set productDetail(value) {
    this._productDetail = value;
    this.getAllergensForProducts();
  }

  get allergenInformation() {
    return this._allergenInformation;
  }

  async getAllergensForProducts() {
    let picklistAllergens = await getProductAllergens({
      productIds: this.productDetail?.id
    });
    this._allergenInformation = picklistAllergens.map((allergen) => ({
      id: allergen.value,
      name: allergen.label,
      url: allergensIcons + ALLERGENS_PATH + allergen.value + PNG_EXTENSION
    }));
  }
}