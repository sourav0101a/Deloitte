import { LightningElement, api } from 'lwc';
import contactWithUs from '@salesforce/label/c.CCEP_Contact_With_Us';
import contact from '@salesforce/label/c.CCEP_Contact';
import email from '@salesforce/label/c.CCEP_Email';
import telephone from '@salesforce/label/c.CCEP_Telephone';
import contactDetailsInfo from '@salesforce/label/c.CCEP_Contact_Details_Info';

export default class CcepContactDetailModal extends LightningElement {

    static renderMode = "light";

    @api
    telephoneNumber;

    @api
    contactEmail;


    _showContactModal = false;  

    get showContactModal() {
        return this._showContactModal;
    }
    set showContactModal(value) {
        this._showContactModal = value;
    }

    labels = {
        contactWithUs,
        contact,
        email,
        telephone,
        contactDetailsInfo
    }

    openModal(){
        this.showContactModal = true;
    }

    closeModal(){
        this.showContactModal = false;
    }

    get emailTo(){
        return 'mailto:' + this.contactEmail;
    }

    get callTo(){
        return 'tel:' + this.telephoneNumber;
    }
}