import { LightningElement, wire, api } from 'lwc';
import getOrderItems from '@salesforce/apex/CCEP_OrderSummaryDetailController.getOrderItems';
import getPromotionsForOrderSummary from '@salesforce/apex/CCEP_OrderSummaryDetailController.getPromotionsForOrderSummary';
import { formatDate } from "c/ccepCommerceUtils";

const orderedFormat = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: "2-digit",
    minute: "2-digit"
};
const deliveryFormat = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
};
export default class CcepBuilderOrderSummaryDetail extends LightningElement {
    static renderMode = 'light';

    _order;

    @api
    recordId;

    @api
    get order() {
        return this._order;
    }
    set order(value) {
        this._order = value;
    }

    @wire(getOrderItems,{orderId:'$recordId'})
    async onGetOrderItems({data}) {
        if(data && data[0] && data[0].OrderSummary && data[0].OrderDeliveryGroupSummary && data[0].OrderSummary.CCEP_Distributor__r){
            let promotions = await getPromotionsForOrderSummary({orderSummaryId: data[0].OrderSummaryId});
            if(promotions){
                console.log('*** Promotions 1 for current order are: ', JSON.parse(JSON.stringify(promotions)));
                promotions = promotions.map((promotion) => ({
                    promoCode: promotion.CCEP_Promotion__r.CCEP_PromoCode__c,
                    description: promotion.CCEP_Promotion__r.CCEP_PromoDescription__c
                }));
                console.log('*** Promotions 2 for current order are: ', JSON.parse(JSON.stringify(promotions)));
            }
            this._order = {
                orderLines: data,
                orderNumber: data[0].OrderSummary.OrderNumber,
                orderedDate: formatDate(data[0].OrderSummary.OrderedDate, orderedFormat),
                status: data[0].OrderSummary.Status,
                totalProducts: data[0].OrderSummary.CCEP_TotalProducts__c,
                grandTotalAmount: data[0].OrderSummary.GrandTotalAmount,
                totalTaxAmount: data[0].OrderSummary.TotalTaxAmount,
                totalAdjDistAmount: data[0].OrderSummary.TotalAdjDistAmount,
                promotionsApplied:data[0].OrderSummary.CCEP_PromotionsApplied__c,
                promotionsInfo: promotions,
                desiredDeliveryDate:formatDate(data[0].OrderDeliveryGroupSummary.DesiredDeliveryDate, deliveryFormat),
                distributor: data[0].OrderSummary.CCEP_Distributor__r.Name,
                subtotal: data[0].OrderSummary.TotalAdjustedProductAmount
            };
        }
    }
}