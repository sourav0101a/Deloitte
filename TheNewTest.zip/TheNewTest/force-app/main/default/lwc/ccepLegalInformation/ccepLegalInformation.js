import { LightningElement } from 'lwc';
import legalInfoContent from '@salesforce/label/c.CCEP_LegalInfoContent';
import legalInfoHeader from '@salesforce/label/c.CCEP_LegalInfoHeader';


export default class CcepLegalInformation extends LightningElement {

    label = {
        legalInfoContent,
        legalInfoHeader
    }

}