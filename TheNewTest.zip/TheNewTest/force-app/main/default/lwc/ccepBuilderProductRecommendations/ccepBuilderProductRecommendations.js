import { LightningElement, api } from "lwc";
import getRecommendations from "@salesforce/apex/CCEP_ProductRecommendationController.getRecommendations";
import getRecommendationsPrices from "@salesforce/apex/CCEP_ProductRecommendationController.getRecommendationsPrices";
import communityId from "@salesforce/community/Id";

const MAX_CAROUSEL_ITEMS = 6;

export default class CcepBuilderProductRecommendations extends LightningElement {
  _productId;
  _recommendedProducts;

  @api
  get productId() {
    return this._productId;
  }
  set productId(value) {
    this._productId = value;
    this.getRecommendedProductsForProductId();
  }

  get recommendedProducts() {
    return this._recommendedProducts;
  }

  async getRecommendedProductsForProductId() {
    //API call to product recomendations
    let productRecommendationsList = await getRecommendations({
      productIds: this.productId,
      effectiveAccountId: sessionStorage.getItem("EFFECTIVE_ACCOUNT_ID"),
      communityId: communityId,
      maxNumberOfResults: MAX_CAROUSEL_ITEMS
    });
    if (productRecommendationsList) {
      //Get productIds and call prices API
      let ids = productRecommendationsList
        .map((product) => product.id);

      //API call to prices
      let productPricesList = await getRecommendationsPrices({
        productIds: ids,
        effectiveAccountId: sessionStorage.getItem("EFFECTIVE_ACCOUNT_ID"),
        communityId: communityId
      });

      //Merge product data with price data
      let recommendedProductsWithPrices = this.mergeAllData(
        productRecommendationsList,
        productPricesList
      );

      //Formatting data according Card LWC
      this._recommendedProducts = this.formatProductToCardComponent(
        recommendedProductsWithPrices
      );
    }
    else{
      this._recommendedProducts = null;
    }
  }

  mergeAllData(productRecommendationsList, productPricesList) {
    let productRecommendationFull = JSON.parse(
      JSON.stringify(productRecommendationsList)
    );
    productRecommendationFull.forEach((product) => {
      productPricesList.pricingLineItemResults.forEach((price) => {
        if (product.id === price.productId) {
          product.prices = price;
          product.currencyIsoCode = price.currencyIsoCode;
        }
      });
    });
    return productRecommendationFull;
  }

  formatProductToCardComponent(productsToFormat) {
    return productsToFormat.map((productToFormat) => ({
      id: productToFormat.id,
      productClass: "Simple",
      productSellingModelInformation: null,
      purchaseQuantityRule: null,
      urlName: null,
      variationAttributeSet: null,
      image: {
        alternateText: productToFormat.defaultImage.alternateText,
        url: productToFormat.defaultImage.url
      },
      name: productToFormat.fields.Name,
      fields: {
        Description: {
          value: productToFormat.fields.Description
        },
        Family: {
          value: productToFormat.fields.Family
        },
        Name: {
          value: productToFormat.fields.Name
        },
        ProductCode: {
          value: productToFormat.fields.ProductCode
        },
        StockKeepingUnit: {
          value: productToFormat.fields.StockKeepingUnit
        }
      },
      prices: {
        currencyIsoCode: productToFormat.currencyIsoCode,
        isLoading: false,
        listingPrice: productToFormat.prices.listPrice,
        negotiatedPrice: productToFormat.prices.unitPrice
      },
      pageReference:{
        attributes: {
          actionName:"view",
          objectApiName:"Product2",
          recordId: productToFormat.id,
          urlName: null
        },
        state: productToFormat.fields.Name,
        type: "standard__recordPage"
      }
    }));
  }
}