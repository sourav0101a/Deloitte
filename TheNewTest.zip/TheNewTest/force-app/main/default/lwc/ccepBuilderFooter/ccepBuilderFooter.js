import { LightningElement, api, wire } from 'lwc';
import siteId from '@salesforce/site/Id';
import { getNavigationMenu } from 'experience/navigationMenuApi';
import { getContent } from 'experience/cmsDeliveryApi';
import communityId from "@salesforce/community/Id";

export default class CcepBuilderFooter extends LightningElement {
    static renderMode = 'light';

    @api 
    linksOfInterestNavigationMenu;

    @api 
    followUsNavigationMenu;

    @api 
    contentPageLinksNavigationMenu;

    @api 
    logoMobile;

    @api 
    logoDesktop;

    @api
    telephoneNumber;

    @api
    contactEmail;

    _imgLogoMobile;
    _imgLogoDesktop;
    _linksOfInterestMenu;
    _followUsMenu;
    _contentPageLinksMenu;

    get imgLogoMobile() {
        return this._imgLogoMobile;
    }
    set imgLogoMobile(value) {
        this._imgLogoMobile = value;
    }
    get imgLogoDesktop() {
        return this._imgLogoDesktop;
    }
    set imgLogoDesktop(value) {
        this._imgLogoDesktop = value;
    }
    get linksOfInterestMenu() {
        return this._linksOfInterestMenu;
    }
    set linksOfInterestMenu(value) {
        this._linksOfInterestMenu = value;
    }
    get followUsMenu() {
        return this._followUsMenu;
    }
    set followUsMenu(value) {
        this._followUsMenu = value;
    }
    get contentPageLinksMenu() {
        return this._contentPageLinksMenu;
    }
    set contentPageLinksMenu(value) {
        this._contentPageLinksMenu = value;
    }


    @wire(getContent, {channelOrSiteId: siteId, contentKeyOrId: '$logoMobile'})
    onGetLogoMobile(result) {
        if (result.data) {
            this.imgLogoMobile = result.data.contentBody["sfdc_cms:media"].url;
        }
    }

    @wire(getContent, {channelOrSiteId: siteId, contentKeyOrId: '$logoDesktop'})
    onGetLogoDesktop(result) {
        if (result.data) {
            this.imgLogoDesktop = result.data.contentBody["sfdc_cms:media"].url;
        }
    }

    @wire(getNavigationMenu, { communityId: communityId, navigationLinkSetDeveloperName: '$linksOfInterestNavigationMenu'})
    onGetLinksOfInterestNavigationMenu({ data }) {
        if (data) {
            this.linksOfInterestMenu = data.menuItems;
        }
    }

    @wire(getNavigationMenu, { communityId: communityId, navigationLinkSetDeveloperName: '$followUsNavigationMenu', includeImageUrl: true})
    onGetFollowUsNavigationMenu({ data }) {
        if (data) {
            this.followUsMenu = data.menuItems;
        }
    }

    @wire(getNavigationMenu, { communityId: communityId, navigationLinkSetDeveloperName: '$contentPageLinksNavigationMenu'})
    onGetContentPageLinksNavigationMenu({ data }) {
        if (data) {
            this.contentPageLinksMenu = data.menuItems;
        }
    }
}