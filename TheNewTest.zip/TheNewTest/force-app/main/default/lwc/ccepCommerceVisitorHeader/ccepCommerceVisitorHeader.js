import { LightningElement } from 'lwc';

/**
 * @slot burgermenu
 * @slot logo
 * @slot login
 */
export default class CcepCommerceVisitorHeader extends LightningElement {}