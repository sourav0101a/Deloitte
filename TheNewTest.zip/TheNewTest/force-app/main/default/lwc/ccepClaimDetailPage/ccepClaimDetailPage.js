import { LightningElement, api, track } from 'lwc';
import getClaimImages from '@salesforce/apex/CCEP_ClaimController.getClaimAttachments';
//importing custom labels for spanish literals - User Detail Section
import claimId from '@salesforce/label/c.CCEP_Claim_ID';
import claimTitle from '@salesforce/label/c.CCEP_Claim_Title';
import claimDesc from '@salesforce/label/c.CCEP_Description';
import status from '@salesforce/label/c.CCEP_Status';
import startDate from '@salesforce/label/c.CCEP_Date_of_claim_submission';
import response from '@salesforce/label/c.CCEP_Response';
import backToMyClaims from '@salesforce/label/c.CCEP_Back_to_My_Claims';
import images from '@salesforce/label/c.CCEP_Attached_images';
import claimDetails from '@salesforce/label/c.CCEP_Claim_Details';
import issueReason from '@salesforce/label/c.CCEP_Type_of_Reason';
import claimReason from '@salesforce/label/c.CCEP_Claim_Reason';
import orderNo from '@salesforce/label/c.CCEP_Order_No';

export default class CcepClaimDetailPage extends LightningElement {
    @api claim;

    claimDetail;
    claimImages;
    claimAttachmentList;
    imgSrc;
    imgTitle;
    imgSize;
    imgType;
    imgCreatedDate;
    noImagesFound = true;

    static renderMode="light";

    labels = {
        backToMyClaims,
        claimDetails,
        claimId,
        claimTitle,
        claimDesc,
        status,
        startDate,
        response,
        claimReason,
        issueReason,
        orderNo,
        images
    };

    backToClaims(){
        this.dispatchEvent(new CustomEvent('backbuttonclicked'));
    }

    connectedCallback(){

        getClaimImages({
            claimId: this.claim[0].Id
        })
        .then(images => {
            if(images.length > 0){
                this.noImagesFound = false;
                this.claimAttachmentList = images;
            }
        })
        .catch(error => {
            this.error = error;
            console.log('ERROR while image query ', JSON.stringify(this.error));
        });
        
    }

  

}