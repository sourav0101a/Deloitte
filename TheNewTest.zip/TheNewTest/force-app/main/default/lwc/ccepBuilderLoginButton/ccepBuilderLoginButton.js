import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import login from '@salesforce/label/c.CCEP_Login';

export default class CcepBuilderLoginButton extends NavigationMixin(LightningElement) {

    static renderMode = 'light';

    labels = {
        login
    }

    goToLogin(){
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'Login',
            },
        });
    }

}