import { LightningElement, api, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { getNavigationMenu } from 'experience/navigationMenuApi';
import activeLanguages from '@salesforce/site/activeLanguages';
import communityId from "@salesforce/community/Id";
import { getLanguage, setLanguage, getNavigationMenuItems } from 'c/ccepCommerceUtils';

// Labels for languages
import english from '@salesforce/label/c.CCEP_English';
import spanish from '@salesforce/label/c.CCEP_Spanish';

import { getRecord } from 'lightning/uiRecordApi';
const FIELDS = ['Account.Name'];

export default class CcepBuilderHamburgerMenuHeader extends NavigationMixin(LightningElement) {

    static renderMode = 'light';

    languageLabels = {
        // Code => label
        // Purpose: match languages with their translated labels
        'en-US': english,
        'es': spanish
    }

    effectiveAccountId = sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');
    
    _storeInfo;
    _navigation = [];
    _userMenu;
    _selectedLanguage;

    @api
    navigationLinkSetDevName;

    get storeInfo() {
        return this._storeInfo;
    }
    set storeInfo(value) {
        this._storeInfo = value;
    }
    
    get navigation() {
        return this._navigation;
    }
    set navigation(value) {
        this._navigation = value;
    }

    get userMenu() {
        return this._userMenu;
    }
    set userMenu(value) {
        this._userMenu = value;
    }

    get selectedLanguage() {
        return this._selectedLanguage;
    }
    set selectedLanguage(value) {
        this._selectedLanguage = value;
    }

    get storeLogoUrl(){
        const root = document.querySelector('html');
        return getComputedStyle(root).getPropertyValue('--dxp-s-site-logo-path');
    }

    connectedCallback(){
        this.selectedLanguage = getLanguage();
        this.getCategories();
    }

    async getCategories(){
        const navItemResponse = await getNavigationMenuItems();
        if(navItemResponse.success){
            this.navigation = navItemResponse.data.menuItems;
        }
    }

    // Store name
    @wire(getRecord, { recordId: '$effectiveAccountId', fields: FIELDS})
    wiredRecord({ data }) {
        if (data) {
            this.storeInfo = data;
        }
    }

    // Navigation menu
    @wire(getNavigationMenu, { communityId: communityId, navigationLinkSetDeveloperName: '$navigationLinkSetDevName'})
    onGetNavigationMenu({ data }) {
        if (data) {
            this.userMenu = data.menuItems;
        }
    }

    // Languages
    get languages(){
        let cookieLang = getLanguage();
        let langList = activeLanguages.map(lang => ({label: this.languageLabels[lang.code], code: lang.code, selected: lang.code === cookieLang}));
        return langList;
    }

    // Language selected
    handleSelectedLanguage(event){
        this.selectedLanguage = event.detail.language;
        // Change selected language
        setLanguage('');
        setLanguage(this.selectedLanguage);

        this._menuIsOpen = false;
        window.location.href = '/store/';
    }

}