import { LightningElement, api } from 'lwc';
import {NavigationMixin} from 'lightning/navigation';

export default class CcepCategoryCarousel extends NavigationMixin(LightningElement) {

    static renderMode = 'light';

    @api
    categories;

    navigateToCategory(event){
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.currentTarget.dataset.id,
                objectApiName: 'ProductCategory',
                actionName: 'view'
            }
        });
    }

}