import { LightningElement, api } from 'lwc';

export default class CcepIcon extends LightningElement {

    @api
    icon; // For example: chevronright

    @api
    color; // For example: white

    @api
    size; // For example: medium

    @api
    alternativeText; // For example: Next

    // Icon name - e.g. chevronright
    get iconName(){
        return `utility:${this.icon}`;
    }

    // Icon class styles for applying color
    get iconStyles(){
        if(this.color){
            return `icon-${this.color}`;
        }
    }

}