import { LightningElement } from 'lwc';

/**
 * @slot burgermenu
 * @slot logo
 * @slot search
 * @slot cart
 */
export default class CcepCommerceHeader extends LightningElement {}