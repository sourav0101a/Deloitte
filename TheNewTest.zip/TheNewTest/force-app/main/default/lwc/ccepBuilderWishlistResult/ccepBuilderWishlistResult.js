import { LightningElement,wire,api } from 'lwc';
import wishlistItemsData from '@salesforce/apex/CCEP_WishlistController.getWishlistItems';
import communityId from '@salesforce/community/Id';
import Id from '@salesforce/user/Id';
import { getRecord } from 'lightning/uiRecordApi';
import userAccountField from '@salesforce/schema/User.AccountId';
import { getContent } from 'experience/cmsDeliveryApi';
import siteId from '@salesforce/site/Id';
import wishlistTitle from '@salesforce/label/c.CCEP_Wishlist_Title';

export default class CcepBuilderWishlistResult extends LightningElement {
    showResults = false;
    displayNoResults = false;
    wishlistResult;
    totalItemCount;
    noResultsImage;
    outletId;
    effectiveAccountId = sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');
    @api contentKey;

    labels = {
        wishlistTitle
    }

    @wire(getContent, {channelOrSiteId: siteId, contentKeyOrId: '$contentKey'})
    onGetContent(result) {
        if (result.data) {
            this.noResultsImage = result.data.contentBody["sfdc_cms:media"].url;
        }
    }

    @wire(getRecord, { recordId: Id, fields: [userAccountField ]}) 
    currentUserInfo({error, data}) {
        if (data) {
            //let outletId;
            if(this.effectiveAccountId == null || this.effectiveAccountId == undefined){
                this.outletId = data.fields.AccountId.value;
            }else{
                this.outletId = this.effectiveAccountId;
            }
            if(this.outletId){
                this.getWishlistItemsData(this.outletId);
            }

        } else if (error) {
            this.error = error ;
        }
    }

    getWishlistItemsData(outletId){
        wishlistItemsData({
            communityId: communityId,
            outletId: outletId
        })
        .then((result) => {
            if(result != undefined){  
                let itemsLength;
                this.showResults = true;
                
                if(this.showResults == true){
                    this.wishlistResult = result;
                    itemsLength = result.items.length;
                    this.totalItemCount = itemsLength;
                }
                
            }else{
                this.showResults = false;
                this.displayNoResults = true;
            }
        })
        .catch((error) => {
            console.error('error ', error);
            this.showResults = false;
        });
    }
    refreshCountAndList(event){
        this.totalItemCount = event.detail.totalItemCount;
        this.wishlistResult = event.detail.wishlistResults;
    }

}