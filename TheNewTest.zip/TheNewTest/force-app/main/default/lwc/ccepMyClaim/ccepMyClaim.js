import { LightningElement, api } from 'lwc';
import claimTitle from '@salesforce/label/c.CCEP_Claim_Title';
import issueType from '@salesforce/label/c.CCEP_Issue_Type';
import status from '@salesforce/label/c.CCEP_Status';
import startDate from '@salesforce/label/c.CCEP_Date_of_claim_submission';
export default class CcepMyClaim extends LightningElement {
    static renderMode="light";

    @api claimItem;

    labels = {
        claimTitle,
        issueType,
        status,
        startDate
    };
}