import { LightningElement, api } from "lwc";

export default class CcepBuilderProductBreadcrumbs extends LightningElement {
  static renderMode = "light";

  _productDetail;
  _previousCategory;

  @api
  get productDetail() {
    return this._productDetail;
  }
  set productDetail(value) {
    this._productDetail = value;
    if (value) {
      this.getCategory(value.primaryProductCategoryPath?.path);
    }
  }

  get previousCategory() {
    return this._previousCategory;
  }
  set previousCategory(value) {
    this._previousCategory = value;
  }

  getCategory(categories) {
    if (categories) {
      this.previousCategory = categories[categories.length - 1];
    }
  }
}