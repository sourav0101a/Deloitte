import { LightningElement } from 'lwc';
import { NavigationMixin } from "lightning/navigation";

export default class CcepBuilderBackToCart extends NavigationMixin(LightningElement) {
    static renderMode = 'light';

    handleGoToCart () {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
               url:'/cart'
          }
        });
    }

}