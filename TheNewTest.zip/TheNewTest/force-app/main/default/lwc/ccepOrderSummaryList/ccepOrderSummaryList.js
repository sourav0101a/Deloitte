import { LightningElement,api } from 'lwc';
import CCEP_Pagination from '@salesforce/label/c.CCEP_Pagination';
import CCEP_See_More from '@salesforce/label/c.CCEP_See_More';
import CCEP_OrderHistory from '@salesforce/label/c.CCEP_OrderHistory';
import CCEP_OrdersDateLimitTitle from '@salesforce/label/c.CCEP_OrdersDateLimitTitle';
import CCEP_OrdersDateLimitHelp from '@salesforce/label/c.CCEP_OrdersDateLimitHelp';
import CCEP_OrdersSearch from '@salesforce/label/c.CCEP_OrdersSearch';
import CCEP_OrderNotFound from '@salesforce/label/c.CCEP_OrderNotFound';

export default class CcepOrderSummaryList extends LightningElement {
    
    static renderMode = 'light';
    _currentPage;
    _numbersOfPages;
    _numberOfItems;
    _orders;
    _orderNumber;
    _manualPagination;
    _availablePages;

    labels = {
        CCEP_Pagination,
        CCEP_See_More,
        CCEP_OrderHistory,
        CCEP_OrdersDateLimitTitle,
        CCEP_OrdersDateLimitHelp,
        CCEP_OrdersSearch,
        CCEP_OrderNotFound
    }

    @api
    get orderNumber() {
        return this._orderNumber;
    }
    set orderNumber(value) {
        this._orderNumber = value;
    }

    @api
    get currentPage() {
        return this._currentPage;
    }
    set currentPage(value) {
        this._currentPage = value;
    }

    @api
    get numbersOfPages() {
        return this._numbersOfPages;
    }
    set numbersOfPages(value) {
        this._numbersOfPages = value;
    }

    @api
    get numberOfItems() {
        return this._numberOfItems;
    }
    set numberOfItems(value) {
        this._numberOfItems = value;
    }

    @api
    get orders() {
        return this._orders;
    }
    set orders(value) {
        this._orders = value;
    }

    @api
    get manualPagination() {
        return this._manualPagination;
    }
    set manualPagination(value) {
        this._manualPagination = value;
    }

    @api
    get availablePages() {
        return this._availablePages;
    }
    set availablePages(value) {
        this._availablePages = value;
    }

    get disablePaginationPrevious() {
        return this._currentPage === 1;
    }

    get disablePaginationNext() {
        return this._currentPage === this._numbersOfPages;
    }

    handleSearch (e) {
        this.dispatchEvent(
            new CustomEvent('search', {
                detail: {orderNumber: e.currentTarget.value }
            })
        )
    }

    handleclick(e) {
        this.dispatchEvent(new CustomEvent('gotoorder', e));
    }

    handleSelectorChange (e) {
        this.dispatchEvent(
            new CustomEvent('paginationtogglechanged',{
                detail: {
                    checked: e.detail.checked
                }
            })
        );
    }

    handleChangePage(e) {
        let {action,page} = e.currentTarget.dataset;
        let actions = {
            'prev': this._currentPage - 1,
            'next': this._currentPage + 1,
            'page': Number(page)
        }
        this.dispatchEvent(
            new CustomEvent('changepage', {
                detail: { 
                    newPage : actions[action]
                }
            })
        )

    }


}