import { LightningElement } from 'lwc';
import CCEP_BackToCart from '@salesforce/label/c.CCEP_BackToCart';
export default class CcepBackToCart extends LightningElement {
    static renderMode = 'Light';

    labels = {
        CCEP_BackToCart
    }

    goToCart() {
        this.dispatchEvent(new CustomEvent('gotocart'));
    }
}