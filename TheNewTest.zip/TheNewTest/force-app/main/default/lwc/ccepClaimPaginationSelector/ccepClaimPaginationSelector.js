import { LightningElement } from 'lwc';
import pagination from '@salesforce/label/c.CCEP_Pagination';

export default class CcepClaimPaginationSelector extends LightningElement {

    static renderMode = 'light';

    labels = {
        pagination
    }

    handleSelectorChange(event){
        this.dispatchEvent(
            new CustomEvent('togglechange',{
                detail: {
                    checked: event.detail.checked
                }
            })
        );
    }

}