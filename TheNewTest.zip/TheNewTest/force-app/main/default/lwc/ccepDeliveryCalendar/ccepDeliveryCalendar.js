import { LightningElement,api } from 'lwc';
import CCEP_Monday from '@salesforce/label/c.CCEP_Monday';
import CCEP_Tuesday from '@salesforce/label/c.CCEP_Tuesday';
import CCEP_Wednesday from '@salesforce/label/c.CCEP_Wednesday';
import CCEP_Thursday from '@salesforce/label/c.CCEP_Thursday';
import CCEP_Friday from '@salesforce/label/c.CCEP_Friday';
import CCEP_Saturday from '@salesforce/label/c.CCEP_Saturday';
import CCEP_Sunday from '@salesforce/label/c.CCEP_Sunday';
import CCEP_SelectedDate from '@salesforce/label/c.CCEP_SelectedDate';
import CCEP_DeliveryAddress from '@salesforce/label/c.CCEP_DeliveryAddress';
import CCEP_DeliveryDate from '@salesforce/label/c.CCEP_DeliveryDate';
import CCEP_DeliveryDateHelp from '@salesforce/label/c.CCEP_DeliveryDateHelp';
import CCEP_PriceDisclaimer from '@salesforce/label/c.CCEP_PriceDisclaimer';

export default class CcepDeliveryCalendar extends LightningElement {
    static renderMode = 'light';

    _month;
    _disableChevrons;
    _monthString;
    _fullYear;
    _deliveryDisclaimer;
    _selectedDate;
    _shippingAddress;

    labels = {
        CCEP_Monday,
        CCEP_Tuesday,
        CCEP_Wednesday,
        CCEP_Thursday,
        CCEP_Friday,
        CCEP_Saturday,
        CCEP_Sunday,
        CCEP_DeliveryAddress,
        CCEP_SelectedDate,
        CCEP_DeliveryDate,
        CCEP_DeliveryDateHelp,
        CCEP_PriceDisclaimer
    }


    @api
    get month() {
        return this._month;
    }
    set month(value) {
        this._month = value;
    }

    @api
    get disableChevrons() {
        return this._disableChevrons;
    }
    set disableChevrons(value) {
        this._disableChevrons = value;
    }

    @api
    get monthString() {
        return this._monthString;
    }
    set monthString(value) {
        if(value){
            this._monthString = value;
        }
    }

    @api
    get fullYear() {
        return this._fullYear;
    }
    set fullYear(value) {
        if(value){
            this._fullYear = value;
        }
    }

    @api
    get deliveryDisclaimer() {
        return this._deliveryDisclaimer;
    }
    set deliveryDisclaimer(value) {
        this._deliveryDisclaimer = value;
    }

    @api
    get selectedDate() {
        return this._selectedDate;
    }
    set selectedDate(value) {
        this._selectedDate = value;
    }

    @api
    get shippingAddress() {
        return this._shippingAddress;
    }
    set shippingAddress(value) {
        this._shippingAddress = value;
    }

    handleSelectDate(e) {
        this.dispatchEvent(new CustomEvent('selectdate', {detail: {date: e.currentTarget.dataset.date}}));
    }

    handleChangeMonth (e) {
        this.dispatchEvent(new CustomEvent('selectedmonth', {detail: {month: Number(e.currentTarget.dataset.monthid)}}))
    }

 
}