import { LightningElement, api } from 'lwc';

export default class CcepModal extends LightningElement {

    static renderMode = 'light';

    @api
    title;

    @api
    content;

    @api
    firstButton;

    @api
    secondButton;

    cancelProcess(){
        this.dispatchEvent(new CustomEvent('modalcancelled', {}));
    }

    confirmProcess(){
        this.dispatchEvent(new CustomEvent('modalconfirmed', {}));
    }

    modalClosed(){
        this.dispatchEvent(new CustomEvent('modalclosed', {}));
    }

}