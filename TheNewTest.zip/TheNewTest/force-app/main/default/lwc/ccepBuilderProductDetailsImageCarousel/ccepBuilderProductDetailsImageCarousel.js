import { LightningElement,api } from 'lwc';
import isProductAvailable from '@salesforce/apex/CCEP_ProductDetailsController.isProductAvailable';

export default class CcepBuilderProductDetailsImageCarousel extends LightningElement {

    static renderMode = 'light';
    
    _productDetailMediaGroups;
    _images = [];
    _selectedImageIndex = 0;
    _productDetail;
    _outOfStock = false;

    @api
    get productDetail() {
        return this._productDetail;
    }
    set productDetail(value) {
        if(value){
            this.composeProductStock(value);
            this._productDetail = value;
        }
    }

    @api
    get productDetailMediaGroups() {
        return this._productDetailMediaGroups;
    }
    set productDetailMediaGroups(value) {
        if(value){
            this._productDetailMediaGroups = value;
            this._images = (value[1]) ? value[1].mediaItems : [];
        }
    }

    get outOfStock(){
        return this._outOfStock;
    }

    get images() {
        return this._images;
    }

    get selectedImageIndex() {
        return this._selectedImageIndex;
    }

    async isProductAvailable(productId){
        const productAvailable = await isProductAvailable({effectiveAccountId: sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID'), productId: productId});
        return productAvailable;
    }

    async composeProductStock(value){
        let productAvailability = await this.isProductAvailable(value.id);
        this._outOfStock = !productAvailability;       
    }

    handleChangeIndex(e) {
        this._selectedImageIndex = e.detail.index;
    }
}