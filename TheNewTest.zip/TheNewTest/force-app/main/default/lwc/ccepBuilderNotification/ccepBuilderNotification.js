import { LightningElement } from 'lwc';
import getNotifications from '@salesforce/apex/CCEP_NotificationController.getNotificationsForEffectiveAccount';
export default class CcepBuilderNotification extends LightningElement {
    static renderMode = "light";

    notifications;

    connectedCallback() {
    this.getNotificationsForEffectiveAccount();
    }
    
    async getNotificationsForEffectiveAccount() {
        let notifications = await getNotifications({
            effectiveAccountId: sessionStorage.getItem("EFFECTIVE_ACCOUNT_ID")
        });
        if (notifications) {
            console.log("*** Current notifications: ", JSON.parse(JSON.stringify(notifications)));
            this.notifications = notifications;
        }
    }
}