import { LightningElement } from 'lwc';
import {NavigationMixin} from 'lightning/navigation';
import basePath from '@salesforce/community/basePath';

export default class CcepBuilderStoreLogoHeader extends NavigationMixin(LightningElement) {

    homeURL = basePath;

    // Logo -> Site logo
    get storeLogoUrl(){
        const root = document.querySelector('html');
        return getComputedStyle(root).getPropertyValue('--dxp-s-site-logo-path');
    }

    goHome(event){
        event.preventDefault();
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'Home',
            },
        });
    }
    
}