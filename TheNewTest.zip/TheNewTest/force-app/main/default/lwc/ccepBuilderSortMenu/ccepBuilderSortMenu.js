import { LightningElement, api } from 'lwc';
import { createSearchSortUpdateAction, dispatchAction } from 'commerce/actionApi';

export default class CcepBuilderSortMenu extends LightningElement {

    static renderMode = 'light';

    _startIndex;
    _totalPages;
    _total;

    @api
    sortRules;

    @api
    sortRuleId;

    @api
    get startIndex(){
        return this._startIndex;
    }
    set startIndex(value){
        this._startIndex = value;
    }

    @api
    get totalPages() {
        return this._totalPages;
    }
    set totalPages(value) {
        this._totalPages = value;
    }

    @api
    get total() {
        return this._total;
    }
    set total(value) {
        this._total = value;
    }

    get showSortMenu(){
        console.log('@@@ this.startIndex',this.startIndex);
        console.log('@@@ this.total',this.total);
        console.log('@@@ this.totalPages',this.totalPages);
        if((this.startIndex >0 && this.total>0 && this.totalPages >0) || (this.startIndex <0 && this.total>0 && this.totalPages >0)){
            return true;
        }
        return false;
    }


    handleSelectedSortRule({ detail }) {
        dispatchAction(this, createSearchSortUpdateAction(detail));
    }
   
}