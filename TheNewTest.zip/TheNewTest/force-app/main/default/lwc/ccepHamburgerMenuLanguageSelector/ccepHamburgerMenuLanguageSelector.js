import { LightningElement, api } from 'lwc';

import cancel from '@salesforce/label/c.CCEP_Cancel';
import accept from '@salesforce/label/c.CCEP_Accept';
import language from '@salesforce/label/c.CCEP_Language';

export default class CcepHamburgerMenuLanguageSelector extends LightningElement {

    static renderMode = 'light';

    labels = {
        language,
        cancel,
        accept
    }

    _selectedLanguage;
    _showLanguagesModal;

    @api
    languages;

    get selectedLanguage(){
        this._selectedLanguage = this.languages.find(lang => lang.selected === true).code;
        return this.languages.find(lang => lang.selected === true).label;
    }

    get showLanguagesModal(){
        return this._showLanguagesModal;
    }

    set showLanguagesModal(value){
        this._showLanguagesModal = value;
    }

    cancelModal(){
        this.showLanguagesModal = false;
    }

    openLanguagesModal(){
        this.showLanguagesModal = true;
    }

    handleRadioButtonChange(event){
        this._selectedLanguage = event.currentTarget.dataset.id;
    }

    handleConfirmChange(){
        this.dispatchEvent(
            new CustomEvent('selectedlanguage', {
                detail: {
                    language: this._selectedLanguage
                }
            })
        );
        this.showLanguagesModal = false;
    }

}