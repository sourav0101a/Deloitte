import { LightningElement, api } from 'lwc';
import perUnit from '@salesforce/label/c.CCEP_Per_Unit';
import deleteProduct from '@salesforce/label/c.CCEP_Delete_Product';
import modalDeleteProduct from '@salesforce/label/c.CCEP_Modal_Delete_Product';
import yes from '@salesforce/label/c.CCEP_Yes_CTA';
import no from '@salesforce/label/c.CCEP_No_CTA';

export default class CcepCartItem extends LightningElement {

    static renderMode = 'light';

    labels = {
        perUnit,
        deleteProduct,
        modalDeleteProduct,
        yes,
        no
    }

    buttonDisabled = false;
    _cartItem;
    _itemId;
    _units;
    _showDeleteModal = false;

    @api
    get cartItem() {
        return this._cartItem;
    }
    set cartItem(value) {
        this._cartItem = value;
        this.itemId = value.id;
        this.units = value.quantity;
    }

    @api
    currencyIsoCode;

    get itemId() {
        return this._itemId;
    }
    set itemId(value) {
        this._itemId = value;
    }

    get units() {
        return this._units;
    }
    set units(value) {
        this._units = Number(value);
    }

    get showDeleteModal() {
        return this._showDeleteModal;
    }
    set showDeleteModal(value) {
        this._showDeleteModal = value;
    }

    cancelModal(){
        this.showDeleteModal = false;
    }

    deleteIconClick(){
        this.showDeleteModal = true;
    }

    changeUnits(event){
        this.units = Number(event.detail.units);
        this.dispatchEvent(
            new CustomEvent('updatecartitem', {
                detail: {
                    itemId: this.itemId,
                    units: this.units
                }
            })
        );
    }

    handleConfirmChange(){
        this.dispatchEvent(
            new CustomEvent('deletecartitem', {
                detail: {
                    itemId: this.itemId
                }
            })
        );
    }

}