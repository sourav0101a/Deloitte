import { LightningElement,api } from 'lwc';
import Id from '@salesforce/user/Id';
import updateUserDetails from '@salesforce/apex/CCEP_OutletController.updateUserDetails';
import cancelButton from '@salesforce/label/c.CCEP_Cancel';
import saveButton from '@salesforce/label/c.CCEP_Save_Button';
import firstName from '@salesforce/label/c.CCEP_First_name';
import lastName from '@salesforce/label/c.CCEP_Surname';
import mobileNumber from '@salesforce/label/c.CCEP_Mobile_number';
import editDetails from '@salesforce/label/c.CCEP_Edit_Details';

export default class CcepEditUserDetails extends LightningElement {
    @api userData;
    userFirstName;
    userLastName;
    userMobileNo;
    userId = Id;
    buttonDisabled = false;

    updateUserDetails = {
        updateUserFirstName : '',
        updateUserSurname : '',
        updateUserMobileNo : ''
    }

    label = {
        cancelButton,
        saveButton,
        firstName,
        lastName,
        mobileNumber,
        editDetails
    };

    connectedCallback(){
        if(this.userData){
            this.userFirstName = this.userData.fields.FirstName.value;
            this.userLastName = this.userData.fields.LastName.value;
            this.userMobileNo = this.userData.fields.Contact.value.fields.Phone.value.replace('+34', '');
        }
        
    }

    handleSubmit(){
        this.updateUserDetails.updateUserFirstName = this.template.querySelector("[data-name='firstName']").value;
        this.updateUserDetails.updateUserSurname = this.template.querySelector("[data-name='lastName']").value;
        this.updateUserDetails.updateUserMobileNo = '+34' + this.template.querySelector("[data-name='mobileNo']").value;

        console.log('phone length ' , this.template.querySelector("[data-name='mobileNo']").value.length);

        //call apex here
        updateUserDetails({
            updatedUserDetails : JSON.stringify(this.updateUserDetails),
            userId : this.userId
        })
        .then((result) => {
            if(result){
                if(this.template.querySelector("[data-name='mobileNo']").value.length === 9 || this.template.querySelector("[data-name='mobileNo']").value.length === 0){
                    this.dispatchEvent(new CustomEvent('closemodal'));
                    window.location.reload();
                }
                
            }
        })
        .catch((error) => {
            console.error(error);
        });
        window.location.reload();

    }

    handleCancel(){
        this.dispatchEvent(new CustomEvent('modalcancel'));
    }

    handleMobileNumberChange(event){
        this.buttonDisabled = true;
        const inputValue = event.target.value;
        const isValidPhoneNumber = /^\d{10,13}$/.test(inputValue);
        if (isValidPhoneNumber || (inputValue === "")) {
            this.buttonDisabled = false;
            this.userMobileNo = inputValue;
        } else {
            this.userMobileNo = '';
            this.buttonDisabled = true;
        }
    }

}