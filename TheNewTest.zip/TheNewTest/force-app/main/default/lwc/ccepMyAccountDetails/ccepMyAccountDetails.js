import { LightningElement,track,wire } from 'lwc';
import Id from '@salesforce/user/Id';
import { getRecord } from 'lightning/uiRecordApi';
import userFirstNameField from '@salesforce/schema/User.FirstName';
import userLastNameField from '@salesforce/schema/User.LastName';
import userRoleField from '@salesforce/schema/User.Contact.EmployeeType__c';
import userEmailField from '@salesforce/schema/User.Email';
import userMobileNoField from '@salesforce/schema/User.Contact.Phone';
import myUserAccountHeading from '@salesforce/label/c.CCEP_My_User_Account';
import myUserData from '@salesforce/label/c.CCEP_My_Data';
import firstName from '@salesforce/label/c.CCEP_First_name';
import surname from '@salesforce/label/c.CCEP_Surname';
import email from '@salesforce/label/c.CCEP_Email';
import role from '@salesforce/label/c.CCEP_Role';
import mobileNo from '@salesforce/label/c.CCEP_Mobile_number';
import edit from '@salesforce/label/c.CCEP_Edit';
import changePassword from '@salesforce/label/c.CCEP_Change_Password';
import password from '@salesforce/label/c.CCEP_Password';
import changePasswordModalContent from '@salesforce/label/c.CCEP_ChangePasswordModalContent';
import continueButton from '@salesforce/label/c.CCEP_Continue_Button';
import sendEmail from '@salesforce/apex/CCEP_OutletController.sendEmail'; 

export default class CcepMyAccountDetails extends LightningElement {
    
    userFirstName;
    userLastName;
    userRole;
    userEmail;
    userMobileNo;
    showConfirmationModal = false;
    
    label = {
        myUserAccountHeading,
        myUserData,
        firstName,
        surname,
        email,
        role,
        mobileNo,
        edit,
        changePassword,
        password,
        changePasswordModalContent,
        continueButton
    };

    isShowModal = false;
    userDetails;

    @wire(getRecord, { recordId: Id, fields: [userFirstNameField, userLastNameField, userRoleField, userEmailField, userMobileNoField ]}) 
    currentUserInfo({error, data}) {
        if (data) {
            this.userFirstName = data.fields.FirstName.value;
            this.userLastName = data.fields.LastName.value;
            this.userRole = data.fields.Contact.value.fields.EmployeeType__c.value;
            this.userEmail = data.fields.Email.value;
            this.userMobileNo = data.fields.Contact.value.fields.Phone.value;
            this.userDetails = data;

        } else if (error) {
            this.error = error ;
        }
    }

    showModalBox() {  
        console.log('enter in show model bos');
        this.isShowModal = true;
    }

    handleCancel(){
        this.isShowModal = false;
    }

    closeModalBox(){
        
        this.dispatchEvent(new RefreshEvent());  
      
        refreshApex(this.outletInformation);
        this.isShowModal = false;  
    }

    handleModalClose(){
        this.showConfirmationModal = false;
    }

    triggerEmail(){
        console.log('Click',Id );
        this.showConfirmationModal = true;
        sendEmail({userId: Id})
        .then((result) => {
            console.log('result', result);
        })
        .catch((error) => {
            console.error(error);
        });
    }

}