import { LightningElement } from 'lwc';
import termsAndConditions from '@salesforce/label/c.CCEP_Terms_and_Conditions';
import termsAndConditionssecond from '@salesforce/label/c.CCEP_Terms_and_Conditions2';
import termsAndConditions3 from '@salesforce/label/c.CCEP_Terms_and_Conditions3';
import termsAndConditions4 from '@salesforce/label/c.CCEP_Terms_and_Conditions4';
import legalAgeConfirmation from '@salesforce/label/c.CCEP_Legal_Age_Confirmation';
import acceptMarketing from '@salesforce/label/c.CCEP_Accept_Marketing';
import marketingCommunications from '@salesforce/label/c.CCEP_Accept_Marketing2';

export default class CcepAcceptLegalTerms extends LightningElement {

    tnc = false;
    isAdult = false;
    marketingChecked = false;

    label ={
        termsAndConditions,
        termsAndConditionssecond,
        termsAndConditions3,
        termsAndConditions4,
        legalAgeConfirmation,
        acceptMarketing,
        marketingCommunications
    }

    handleChangeLegal(){
        if(event.target.checked == true){
            if(event.target.name=='tnc'){
                console.log('tnc');
            }
            else{
                console.log('isAdult');
            }
        }
    }
    handleMarketing(){
        if(event.target.checked == true){
            console.log('marketing');
        }
    }
    navigateToLegal() {
        // this[NavigationMixin.Navigate]({
        //     type: 'standard__webPage',
        //     attributes: {
        //         url: '/legal-information'
        //     }
        //     });
        window.open('/store/legal-information','_blank');

    }

    navigateToMarketingCommunications() {
        // this[NavigationMixin.Navigate]({
        //     type: 'standard__webPage',
        //     attributes: {
        //         url: '/marketing-communications'
        //     }
        //     });
        window.open('/store/marketing-communications','_blank')

    }
}