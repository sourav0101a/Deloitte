import { LightningElement } from 'lwc';

/**
 * @slot sort
 * @slot filters
 */
export default class CcepLayoutSearchResults extends LightningElement {}