import { LightningElement, api } from 'lwc';

export default class CcepBuilderCartSummary extends LightningElement {

    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

    @api
    subtotal;

    @api
    total;

    @api
    currencyIsoCode;

}