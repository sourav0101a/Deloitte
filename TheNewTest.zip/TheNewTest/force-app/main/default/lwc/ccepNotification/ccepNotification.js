import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

export default class CcepNotification extends NavigationMixin(LightningElement) {
    @api notificationItem;

    handleNavigation(){
        if(notificationItem.CCEP_Type__c == 'Claim'){
            //navigate to /my-claims page
        }
        else if(notificationItem.CCEP_Type__c == 'Outlet Approved'){
            //navigate to choose-an-outlet page
        }
        else if(notificationItem.CCEP_Type__c == 'Product'){
            //
        }
    }
}