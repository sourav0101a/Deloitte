import { LightningElement, api, wire } from 'lwc';
import { createCartItemAddAction, createSearchFiltersUpdateAction, dispatchAction } from 'commerce/actionApi';
import { getContent } from 'experience/cmsDeliveryApi';
import { getFormFactor } from 'experience/clientApi';
import CCEP_Products_Added_Title from '@salesforce/label/c.CCEP_Products_Added_Title';
import CCEP_Products_Added_To_Cart_Successfully from '@salesforce/label/c.CCEP_Products_Added_To_Cart_Successfully';
import getProductAvailability from '@salesforce/apex/CCEP_SearchResultsController.getProductAvailability';
import getNextPageInAutomaticPagination from '@salesforce/apex/CCEP_SearchResultsController.getNextPageInAutomaticPagination';
import { CurrentPageReference } from 'lightning/navigation';
import communityId from "@salesforce/community/Id";
import siteId from '@salesforce/site/Id';

const sessionStorage_MANUAL_PAGINATION = 'CcepSearchResults_ManualPagination';
const DELAY = 2000;

export default class CcepBuilderSearchResults extends LightningElement {

    static renderMode = 'light';

    labels = {
        CCEP_Products_Added_Title,
        CCEP_Products_Added_To_Cart_Successfully
    }

    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

    _manualPagination = (sessionStorage.getItem(sessionStorage_MANUAL_PAGINATION) != null) ? sessionStorage.getItem(sessionStorage_MANUAL_PAGINATION) === 'true' : null;
    _searchResults;
    _searchTerm;
    _recordId;
    _currentPage = 1;
    _refinements = null;
    _showModal = false;
    _startIndex = 0;
    _totalPages = 0;
    _total = 0;

    productIdAddedToCart;
    productNameAddedToCart;
    unitsAddedToCart;
    pricesAddedToCart;

    displayNoResults = false;
   
    noResultsImage;

    @wire(getFormFactor)
    formFactor;

    @wire(getContent, {channelOrSiteId: siteId, contentKeyOrId: '$contentKey'})
    onGetContent(result) {
        if (result.data) {
            this.noResultsImage = result.data.contentBody["sfdc_cms:media"].url;
        }
    }

    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        if (currentPageReference && currentPageReference.state && currentPageReference.state.refinements) {
            let refinements = decodeURIComponent(decodeURI(currentPageReference.state.refinements));
            if(refinements){
                this.refinements = JSON.parse(refinements);
            }
        }
    }

    @api
    get recordId(){
        return this._recordId;
    }
    set recordId(value){
        if(this.recordId!==value){
            this.displayNoResults=false;
            this._searchResults=undefined;
            this.refinements = null;
        }
        this._recordId = value;
    }

    @api 
    get searchResults() {
        return this._searchResults;
    }
    set searchResults(value){
        if(value && value.cardCollection){
            this.composeSearchResult(value);
        }
    }

    @api
    get currentPage() {
        return this._currentPage;
    }
    set currentPage(value) {
        this._currentPage = value;
    }

    @api sortRuleId;
    @api contentKey;
    @api 
    get searchTerm() {
        return this._searchTerm;
    }
    set searchTerm(value) {
        if(this.searchTerm!==value){
            this.displayNoResults=false;
            this._searchResults=undefined;
            this.refinements = null;
        }
        this._searchTerm = value;
    }

    @api
    get startIndex(){
        return this._startIndex;
    }
    set startIndex(value){
        this._startIndex = value;
    }

    @api
    get totalPages() {
        return this._totalPages;
    }
    set totalPages(value) {
        this._totalPages = value;
    }

    @api
    get total() {
        return this._total;
    }
    set total(value) {
        this._total = value;
    }

    get showResults(){
        console.log('@@@ CcepBuilderSearchResults showResults this.startIndex',this.startIndex);
        console.log('@@@ CcepBuilderSearchResults showResults this.total',this.total);
        console.log('@@@ CcepBuilderSearchResults showResults this.totalPages',this.totalPages);
        console.log('@@@ CcepBuilderSearchResults showResults this.searchResults',this.searchResults?this.searchResults.total:this.searchResults);
        console.log('@@@ CcepBuilderSearchResults showResults this.searchResults' , this.searchResults);
        
        let res=true;
        if(!this.searchResults || this.searchResults.total ===0 ){
            res = false;
            clearTimeout(this.timeoutId);
            // eslint-disable-next-line @lwc/lwc/no-async-operation
            this.timeoutId = setTimeout(() => {
                console.log('@@@ CcepBuilderSearchResults showResults delayShowNoResults');
                this.displayNoResults = true;
            }, DELAY); // Adjust as necessary            
        }
        console.log('@@@ CcepBuilderSearchResults showResults RES',res);
        return res;
    }

    get showModal() {
        return this._showModal;
    }
    set showModal(value) {
        this._showModal = value;
    }

    get actionButtons() {
        return true;
    }

    get refinements(){
        return this._refinements;
    }
    set refinements(value){
        this._refinements = value;
    }    

    get pageSize(){
        return this.searchResults?.pageSize;
    }
    get noMoreResultsToDisplay(){
        return this.currentPage >= this.totalPages;
    }    

    get manualPagination(){
        if(this._manualPagination != null){
            return this._manualPagination;
        }
        return this.formFactor === 'Large';
    }

    set manualPagination(value){
        this._manualPagination = value;
    }

    // Selector changes automatic pagination
    handleSelectorChange(event){
        this.manualPagination = event.detail.checked;
        if(!this.manualPagination){
            this.cleanAllResults();
        }
        sessionStorage.setItem(sessionStorage_MANUAL_PAGINATION, event.detail.checked);
    }

    // Clean results for changing automatic to manual pagination
    cleanAllResults(){
        this.searchResults = {...this.searchResults, cardCollection: this.searchResults.cardCollection.slice(0, this.pageSize)};
    }

    handleAddToCart(event) {
        event.stopPropagation();
        this.productIdAddedToCart = event.detail.productId;
        this.productNameAddedToCart = event.detail.name;
        this.unitsAddedToCart = event.detail.units;
        this.pricesAddedToCart = event.detail.price;
        
        const { productId, units } = event.detail;
        dispatchAction(this, createCartItemAddAction(productId, units), {
            onSuccess: () => {
               this.showModal = true;
            },
        });
    }

    // Update current page
    handleUpdateCurrentPage(event) {
        if(event.detail.cleanResults && Number(event.detail.newPageNumber) === 1){
            this.cleanAllResults();
        }
        event.stopPropagation();
        dispatchAction(this, createSearchFiltersUpdateAction({ page: Number(event.detail.newPageNumber) }));
        this.currentPage = 1;
    }

    modalClosed(){
        this.showModal = false;
    }

    async getProductAvailabilities(productIds){
        const listOfProducts = await getProductAvailability({effectiveAccountId: this.effectiveAccountId, productIds: productIds});
        return listOfProducts;
    }

    async composeSearchResult(value){
        let mapOfProducts = await this.getProductAvailabilities(value.cardCollection.map(product => product.id))
        let cardCollection = JSON.parse(JSON.stringify(value)).cardCollection;

        Object.entries(mapOfProducts).forEach(([id,outOfStock]) => {
            let productIndex = cardCollection.findIndex(prod => prod.id === id);
            cardCollection[productIndex].outOfStock = outOfStock;
        });
        this._searchResults = {...value,cardCollection};
    }

    async getNextItemsInAutomaticPagination(searchQuery){
        let newItems = await getNextPageInAutomaticPagination({communityId, effectiveAccountId: this.effectiveAccountId, searchQuery});
        return newItems;
    }

    async handleSeeMoreItems(){
        let currentItems = this.searchResults;
        
        const searchQuery = {
            categoryId: this.recordId,
            includePrices: true,
            searchTerm: this.searchTerm,
            refinements: this.refinements,
            page: this.currentPage,
            sortRuleId: this.sortRuleId
        };
        
        let newItems = await this.getNextItemsInAutomaticPagination(JSON.stringify(searchQuery));
        this.searchResults = {...this.searchResults, cardCollection: currentItems.cardCollection.concat(newItems.productsPage.products.map(prod => ({...prod, image: prod.defaultImage})))};
        this.currentPage++;
    }

}