import { LightningElement, wire, api, track } from 'lwc';
import {getObjectInfo} from 'lightning/uiObjectInfoApi';
import {getPicklistValues} from 'lightning/uiObjectInfoApi';
import { CloseActionScreenEvent } from 'lightning/actions';
//importing the Outlet Type picklist from the Account object
import contactObject from '@salesforce/schema/Contact';
import employeeTypeField from '@salesforce/schema/Contact.EmployeeType__c';
//importing custom labels for spanish literals - User Detail Section
import email from '@salesforce/label/c.CCEP_Email';
import firstName from '@salesforce/label/c.CCEP_First_name';
import lastName from '@salesforce/label/c.CCEP_Surname';
import duplicateEmailError from '@salesforce/label/c.CCEP_Duplicate_Email_Error';
import landlineNumber from '@salesforce/label/c.CCEP_Landline_number';
import mobileNumber from '@salesforce/label/c.CCEP_Mobile_number';
import contactInformationFieldRequired from '@salesforce/label/c.CCEP_Contact_Information_Field_Required';
import createUserHeader from '@salesforce/label/c.CCEP_Create_employee_header';
import associatedOutletsHeader from '@salesforce/label/c.CCEP_Associated_Outlets';
import addOutlet from '@salesforce/label/c.CCEP_Add_Outlet';
import invalidEmailError from '@salesforce/label/c.CCEP_Email_Validation';
import role from '@salesforce/label/c.CCEP_Role';
import cancelButton from '@salesforce/label/c.CCEP_Cancel';
import createButton from '@salesforce/label/c.CCEP_Create_Button';
import acceptButton from '@salesforce/label/c.CCEP_Accept';
import chooseOutlets from '@salesforce/label/c.CCEP_Choose_Outlets';
import continueButton from '@salesforce/label/c.CCEP_Continue_Button';
import removeButton from '@salesforce/label/c.CCEP_Remove_Button';
import userSuccess from '@salesforce/label/c.CCEP_User_Creation_Success';
//import apex functionality
import getEmailValidity from '@salesforce/apex/CCEP_OutletEmployeeController.getEmailValidity';
import createOutletEmployee from '@salesforce/apex/CCEP_OutletEmployeeController.createEmployeeContact';

export default class CcepOperatorCreatesEmployeeForm extends LightningElement {

    label = {
        firstName,
        email,
        duplicateEmailError,
        lastName,
        role,
        landlineNumber,
        mobileNumber,
        contactInformationFieldRequired,
        associatedOutletsHeader,
        addOutlet,
        chooseOutlets,
        invalidEmailError,
        createUserHeader,
        cancelButton,
        createButton,
        acceptButton,
        continueButton,
        removeButton,
        userSuccess
    };

    @api recordId; //account id from record detail page
    employeeTypes;
    showSpinner = false;
    isSubmitted = false;

    invalidEmail = false;
    duplicateEmail = false;
    role ='';
    requiredFieldError = false;

    @track outletEmployeeDetail = {
        firstName : '',
        lastName : '',
        employeeType : '',
        email : '',
        phone : ''
    };

    @track selectedOutletIds = new Set();

    @wire(getObjectInfo, {objectApiName: contactObject })
    contactInfo;

    //getting the outlet type picklist values
    @wire(getPicklistValues, {recordTypeId: '$contactInfo.data.defaultRecordTypeId', fieldApiName: employeeTypeField })
    employeeTypePicklistValues({data, error}){
        if(data){
            this.employeeTypes = data.values;
        }
    }

    connectedCallback(){
        console.log('record id is ',this.recordId);
    }

    renderedCallback() {
        console.log('rendered------------');
        console.log(this.recordId + ' is provided');
    }

    handleEmailChange(event){
        const emailRegex = /^[a-zA-Z0-9._-]+(\+[a-z0-9-]+)?@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        this.email = event.detail.value;
        if(!emailRegex.test(this.email)){
            this.invalidEmail = true;
            this.duplicateEmail = false;
        }
        else
            this.invalidEmail = false;
            this.requiredFieldError = false;
    }

    handleRoleSelection(event){
        var val = event.target.value;
        this.employeeType = val;  
    }

    handleMobileNumberChange(event){
        this.phone = event.target.value;
    }

    handleEmpFirstName(event){
        this.firstName = event.target.value;
    }

    handleEmpLastName(event){
        this.lastName = event.target.value;
    }

    validateEmail(){
        console.log('inside validate Emmai : ' + this.email);
        if(!this.invalidEmail){
            getEmailValidity({
                email : this.email
            })
            .then((result) =>{
                if(result == false){
                    console.log('invalid email id : ' +result);
                    this.duplicateEmail = true;
                }
                else{
                    this.handleModalContinue();
                }
            })
            .catch((error) =>{
                console.log('Error is', error);
            })
        }  
    }

    //submit handler
    handleModalContinue(){
        
        if(!this.firstName || !this.lastName || !this.employeeType || !this.email){
            this.requiredFieldError = true;
        }
        else{
            this.requiredFieldError = false;
             this.showSpinner = true;
            this.outletEmployeeDetail.firstName = this.firstName;
            this.outletEmployeeDetail.lastName = this.lastName;
            this.outletEmployeeDetail.email = this.email;
            this.outletEmployeeDetail.employeeType = this.employeeType;
            var countryCode = '+34';
            if(this.phone){
                this.outletEmployeeDetail.phone = countryCode + this.phone;
            }
            else{
                this.outletEmployeeDetail.phone = '';
            }
            
            this.selectedOutletIds.add(this.recordId);

            const outletIdSetAsArray = Array.from(this.selectedOutletIds);

            createOutletEmployee({
                employeeDetail : JSON.stringify(this.outletEmployeeDetail),
                outletIdList : JSON.stringify(outletIdSetAsArray),
                isPortalUser : false
            })
            .then(() => {
                this.isSubmitted = true;
                this.showSpinner = false;

            })
            .catch((error) => {
                console.error(error);
            })
        }   
    }

    handleModalCancel(){
        //reset the form
        this.firstName = '';
        this.lastName = '';
        this.email = '';
        this.phone = '';
        this.employeeType = '';
        this.selectedOutletIds.clear();

        this.dispatchEvent(new CloseActionScreenEvent());
    }

    handleFinalContinue(){
        this.dispatchEvent(new CloseActionScreenEvent());
    }

}