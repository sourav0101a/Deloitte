import { LightningElement,wire } from 'lwc';
import {NavigationMixin} from 'lightning/navigation';
import getOrders from '@salesforce/apex/CCEP_OrderSummaryListController.getOrders';

export default class CcepBuilderOrderSummaryList extends NavigationMixin(LightningElement) {

    static renderMode = 'light';

    effectiveAccountId = sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

    _orders = [];
    _resultsByPage = 10;
    _offset = 0;
    _sort = 'DESC';
    _orderNumber = '';
    _currentPage = 1;
    _numberOfResults = 0;
    _maxPages;
    _manualPagination = false;

    @wire(getOrders, {effectiveAccountId: '$effectiveAccountId', resultsByPage: '$_resultsByPage', offset: '$_offset', order: '$_sort',orderNumber: '$_orderNumber'})
    onGetOrders({data,error}) {
        if (error) {
            console.log('error getting orders', error);
        } else if (data) {
            if (!this._manualPagination) {
                this._orders = this._orders.concat(data.orders);
            } else {
                this._orders = data.orders;
            }
            console.log('Orders', data);
            this._maxPages = Math.ceil(data.total/this._resultsByPage);
            this._numberOfResults = data.total;

        }
    }

    get currentPage () {
        return this._currentPage;
    }

    get numbersOfPages () {
        return this._maxPages;
    }

    get numberOfItems () {
        return this._numberOfResults;
    }

    get orders() {
        return this._orders;
    }

    get orderNumber() {
        return this._orderNumber;
    }

    get manualPagination() {
        return this._manualPagination;
    }

    get availablePages() {
        let pages = [];
        if (this._maxPages) {
            let pagesToGenerate = 5;
            let initPage = (this._currentPage - 2 > 0) ? this.currentPage - 2 : 1;
            pages = Array.from({length: pagesToGenerate}).map( (_,i) => ({page: initPage + i, selected: this._currentPage === (initPage + i)})).filter(page => page.page <= this._maxPages);
        }
       
        return pages;
    }

    handleGoToOrder(e) {
        console.log('Event go',e);
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                objectApiName: "OrderSummary",
                recordId: e.detail.id,
                actionName: 'view'
            }
        });
    }

    handleChangePaginationToggle (e) {
        this._manualPagination = e.detail.checked;
        this._offset = 0;
        this._currentPage = 1;
    }

    handleChangePage (e) {
        let {newPage} = e.detail;
        if (newPage > 0 && newPage <= this._maxPages) {
            this._currentPage = newPage;
            this._offset = (newPage - 1) * this._resultsByPage;
        }
    }

    handleSearchOrderSummary (e) {
        this._orderNumber = e.detail.orderNumber;
        this._offset = 0;
        this._currentPage = 1;
    }


    
}