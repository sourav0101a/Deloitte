import { LightningElement, api } from 'lwc';
import units from '@salesforce/label/c.CCEP_Units';
import price from '@salesforce/label/c.CCEP_Price';

export default class CcepAppNotification extends LightningElement {

    static renderMode = 'light';

    labels = {
        units,
        price
    }

    iconMap = {
        "success": "check",
        "warning": "warning",
        "error": "close"
    }

    @api
    title;

    @api
    message;

    @api
    units;

    @api
    prices;

    @api
    type;

    connectedCallback(){
        window.clearTimeout(this.delayTimeout);
        this.delayTimeout = setTimeout(() => {
            this.handleClose();
        }, 3000);
    }

    get getIcon(){
        return this.iconMap[this.type];
    }

    handleClose(){
        this.dispatchEvent(new CustomEvent('appmodalclosed', {}));
    }

}