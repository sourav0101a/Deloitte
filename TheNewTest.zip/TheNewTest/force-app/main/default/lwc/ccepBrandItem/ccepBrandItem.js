import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

export default class CcepBrandItem extends NavigationMixin(LightningElement) {
    static renderMode = 'light';

    _title;
    _image;
    _id;

    promotionUrlDetail = '';

    @api
    get id() {
        return this._id;
    }
    set id(value) {
        this._id = value;
    }
    @api
    get image() {
        return this._image;
    }
    set image(value) {
        this._image = value;
    }
    @api
    get title() {
        return this._title;
    }
    set title(value) {
        this._title = value;
    }

    goToDetailPage(event){
        event.preventDefault();
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                objectApiName: "CCEP_Brand__c",
                recordId: this.id,
                actionName: 'view'
            }
        });
    }
}