import { LightningElement,api } from 'lwc';

export default class CcepCarouselBannerItem extends LightningElement {
    static renderMode = 'light';

    _displayedItem;

    @api
    get displayedItem() {
        return this._displayedItem;
    }
    set displayedItem(value) {
        this._displayedItem = value;
    }

    get imageUrl () {
        return window.location.origin + this.displayedItem.url;
    }

    

}