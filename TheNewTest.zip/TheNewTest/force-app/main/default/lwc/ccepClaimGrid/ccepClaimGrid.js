import { LightningElement, api, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
//importing custom labels for spanish literals - User Detail Section
import myClaims from '@salesforce/label/c.CCEP_My_Claims';
import newClaim from '@salesforce/label/c.CCEP_New_Claim_Button';
import claimDetails from '@salesforce/label/c.CCEP_View_Claim';
import claimHeader from '@salesforce/label/c.CCEP_Claim_Header';
export default class CcepClaimGrid extends NavigationMixin(LightningElement) {
    @api claimResultsList;

    static renderMode="light";

    tempClaimId;
    @track tempClaim = [];
    showViewMoreComponent = false;

    labels = {
        myClaims,
        newClaim,
        claimDetails,
        claimHeader
    };

    //For Pagination
    @track manualPagination = true;
    visibleClaims;
    perPageRecordSize = 5;

    get totalItemCount() {
        return this.claimResultsList.length;
    }

    navigateToNewClaimPage(){
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
               url:'/add-new-claim'
          }
           });
    }

    //Pagination Toggle Change
    handleToggleChange(event){
        this.manualPagination = Boolean(event.detail.checked)
        console.log("manualPagination-- "+this.manualPagination)
        if(!this.manualPagination){
            this.visibleClaims =[...this.claimResultsList]
        }
    }

    updateClaimsHandler(event){
        this.visibleClaims=[...event.detail.records]
        //console.log('visible records--'+JSON.stringify(this.visibleClaims))
    }

    viewClaimDetails(event){
        this.tempClaimId = event.target.dataset.claimId;
        const clickedClaim = this.claimResultsList.find(claim => claim.Id === this.tempClaimId);
        this.tempClaim.push(clickedClaim);
        this.showViewMoreComponent = true;
    }

    handleBackButtonClicked(){
        this.showViewMoreComponent = false;
        this.tempClaimId = undefined;
        this.tempClaim = [];
    }
}