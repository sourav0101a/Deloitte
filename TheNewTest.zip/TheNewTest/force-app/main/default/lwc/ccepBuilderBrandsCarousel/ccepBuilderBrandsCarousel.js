import { LightningElement } from "lwc";
import getBrands from "@salesforce/apex/CCEP_BrandsController.getBrands";
import { getCMSContent } from "c/ccepCommerceUtils";

export default class CcepBuilderBrandsCarousel extends LightningElement {
  static renderMode = "light";

  _brands;

  get brands() {
    return this._brands;
  }
  set brands(value) {
    this._brands = value;
  }

  connectedCallback() {
    this.getBrandsForEffectiveAccount();
  }
  
  async getBrandsForEffectiveAccount() {
    let brands = await getBrands({
      effectiveAccountId: sessionStorage.getItem("EFFECTIVE_ACCOUNT_ID")
    });
    if (brands) {
      console.log("*** Current brands: ", JSON.parse(JSON.stringify(brands)));
      let cmsContentForBrands = await getCMSContent(
        brands.map(
          (brand) => brand.CCEP_CMSContentKey__c
        )
      );
      if (cmsContentForBrands.success && cmsContentForBrands.data.contents) {
        console.log("*** Current cms for brands: ", JSON.parse(JSON.stringify(cmsContentForBrands.data.contents)));
        let brandsWithAllInfo = [];
        brands.forEach((brand) => {
            let cmsContent = cmsContentForBrands.data.contents.find(
              (content) =>
                content.contentKey ===
                brand.CCEP_CMSContentKey__c
            );
            let brandWithCms = JSON.parse(JSON.stringify(brand));
            brandWithCms.cmsContent = cmsContent;
            brandsWithAllInfo.push(brandWithCms);
        });
        this._brands = brandsWithAllInfo.map((brand) => ({
            id: brand.Id,
            title: brand.cmsContent.contentBody.title,
            image: {
              alternateText: brand.cmsContent.urlName,
              url: brand.cmsContent.contentBody.image.url
            }
        }));
      }
    }
  }
}