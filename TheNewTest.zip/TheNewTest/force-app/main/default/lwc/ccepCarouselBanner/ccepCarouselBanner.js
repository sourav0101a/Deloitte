import { LightningElement,api,wire } from 'lwc';
import { getFormFactor } from 'experience/clientApi';

export default class CcepCarouselBanner extends LightningElement {
    static renderMode = 'light';

    _displayedItem;
    _displayedDots;

    @wire(getFormFactor)
    formFactor;

    @api
    get displayedItem() {
        return this._displayedItem;
    }
    set displayedItem(value) {
        this._displayedItem = value;
    }

    @api
    get displayedDots() {
        return this._displayedDots;
    }
    set displayedDots(value) {
        this._displayedDots = value;
    }

    handleChange(evt) {
        this.dispatchEvent(new CustomEvent('slidechange', {detail: {action: evt.currentTarget.dataset.action}}));
    }

    get showChevrons() {
        return this.formFactor !== 'Small';
    }

    handleDotChange(evt) {
        let itemIndex = evt.currentTarget.dataset.index;
        this.dispatchEvent(new CustomEvent('changedisplayeditem', {detail: {itemIndex}}));
    }


}