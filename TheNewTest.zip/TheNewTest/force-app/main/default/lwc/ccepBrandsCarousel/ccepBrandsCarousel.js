import { LightningElement, api } from "lwc";
import { NavigationMixin } from "lightning/navigation";
import ourBrands from "@salesforce/label/c.CCEP_Our_Brands";
import viewAll from "@salesforce/label/c.CCEP_View_All_Offers";

export default class CcepBrandsCarousel extends NavigationMixin(
  LightningElement
) {
  static renderMode = "light";

  labels = {
    ourBrands,
    viewAll
  };

  _brands;

  @api
  get brands() {
    return this._brands;
  }
  set brands(value) {
    this._brands = value;
  }

  // Go to Promotions page
  goToBrandsPage(event) {
    event.preventDefault();
    this[NavigationMixin.Navigate]({
      type: "standard__objectPage",
      attributes: {
        objectApiName: "CCEP_Brand__c",
        actionName: "list"
      }
    });
  }
}