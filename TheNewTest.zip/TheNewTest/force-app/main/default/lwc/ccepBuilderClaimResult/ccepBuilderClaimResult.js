import { LightningElement } from 'lwc';
import getClaims from '@salesforce/apex/CCEP_ClaimController.getAllClaims';
export default class CcepBuilderClaimResult extends LightningElement {
    static renderMode = "light";

    claims;

    connectedCallback() {
    this.getClaimsForEffectiveAccount();
    }
    async getClaimsForEffectiveAccount() {
        let claims = await getClaims({
            effectiveAccountId: sessionStorage.getItem("EFFECTIVE_ACCOUNT_ID")
        });
        if (claims) {
            console.log("*** Current claims: ", JSON.parse(JSON.stringify(claims)));
            this.claims = claims;
        }
    }
}