import { LightningElement } from 'lwc';

/**
 * @slot header
 * @slot full-width-section
 * @slot footer
 */
export default class CcepHomeThemeLayout extends LightningElement {}