import { LightningElement,api } from 'lwc';
import { getCMSCollection } from 'c/ccepCommerceUtils';


export default class CcepBuilderCarouselBanner extends LightningElement {
    static renderMode = 'light';

    _mediaData = [];
    
    expandReferences = true;
    referenceDepth = 3;
    _displayedItemindex = 0;
    _autoSlide;
    _slideTime = 5000;
    _minSwipe = 80;
    _swipeStartX;


    @api 
    cmsCollection;

    connectedCallback() {
        this.getImagesData();
        this.enableAutoSlide();
    }

    async getImagesData () {
        if (this.cmsCollection) {
            let res = await getCMSCollection(this.cmsCollection);
            if (res.success) {
                this._mediaData = res.data.items.map(resource => ({
                    bannerTitle: resource.name,
                    imageTitle: resource.body.contentBody.title,
                    url: resource.body.contentBody.source.url
                }));
            }
        }
       
    }

    get index() {
        let modResult = this._displayedItemindex % this._mediaData.length;
        return (modResult < 0) ? modResult + this._mediaData.length : modResult;
    }

    get displayedItem() {
        return this._mediaData[this.index];
    }

    get displayedDots() {
        let res = [];
        if (this._mediaData) {
            res = Array.from({length: this._mediaData.length}).map((_,value) => ({value, selected: this.index === value}));
        }
        return res;
    }

    enableAutoSlide () {
        this._autoSlide = setInterval( () => {
            this._displayedItemindex += 1
        },this._slideTime);
    }

    disableAutoSlide () {
        clearInterval(this._autoSlide);
    }

    modifyDisplayedItem (evt) {
        let increment = (evt.detail.action === 'prev') ? -1 : 1;
        this._displayedItemindex += increment; 
    }

    handleTouchStart(evt) {
        this._swipeStartX = evt.changedTouches[0].clientX;
        this.disableAutoSlide();

    }

    handleTouchEnd(evt) {
        let res = evt.changedTouches[0].clientX - this._swipeStartX;
        if (res < -this._minSwipe) {
            this._displayedItemindex -= 1; 
        } else if (res > this._minSwipe) {
            this._displayedItemindex += 1;
        }
        this.enableAutoSlide();
    }

    handleChangeDisplayedItem (evt) {
        this._displayedItemindex = evt.detail.itemIndex;
    }


}