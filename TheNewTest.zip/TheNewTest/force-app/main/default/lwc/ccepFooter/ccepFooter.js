import { LightningElement, api, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { getFormFactor } from 'experience/clientApi';
import cookiesAdjustment from '@salesforce/label/c.CCEP_Cookies_Adjustment';
import linksOfInterest from '@salesforce/label/c.CCEP_Links_Of_Interest';
import followUs from '@salesforce/label/c.CCEP_Follow_Us';
import capricorn from '@salesforce/label/c.CCEP_Capricorn';

export default class CcepFooter extends NavigationMixin(LightningElement) {

    static renderMode = "light";

    labels = {
        cookiesAdjustment,
        linksOfInterest,
        followUs,
        capricorn
    }

    @api
    imgLogoMobile;
    @api
    imgLogoDesktop;
    @api
    linksOfInterestMenu;
    @api
    followUsMenu;
    @api
    contentPageLinksMenu;
    @api
    telephoneNumber;
    @api
    contactEmail;

    _isDesktop;

    get isDesktop() {
        return this._isDesktop;
    }
    set isDesktop(value) {
        this._isDesktop = value;
    }

    @wire(getFormFactor)
    onFormFactor(result) {
        this.isDesktop = result === 'Large';
      }

    openCookiesModal(){
        //TODO:: Pending for implementation
    }

    goToTarget(event){
        this._menuIsOpen = false;
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
               url: event.currentTarget.dataset.id
          }
        });
    }
}