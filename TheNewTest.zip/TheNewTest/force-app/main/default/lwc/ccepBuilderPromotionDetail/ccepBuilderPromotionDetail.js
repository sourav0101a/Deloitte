import { LightningElement, api, wire } from 'lwc';
import { addItemToCart } from 'commerce/cartApi';
import { getContent } from 'experience/cmsDeliveryApi';
import getPromotionInfo from "@salesforce/apex/CCEP_PromotionsController.getPromotionInfo";
import getProductIdsInPromotion from "@salesforce/apex/CCEP_PromotionsController.getProductIdsInPromotion";
import getProductAvailability from '@salesforce/apex/CCEP_SearchResultsController.getProductAvailability';
import { getProductsInPromotion, getPricingProductsInPromotion } from 'c/ccepCommerceUtils';
import siteId from '@salesforce/site/Id';
import CCEP_Products_Added_Title from '@salesforce/label/c.CCEP_Products_Added_Title';
import CCEP_Products_Added_To_Cart_Successfully from '@salesforce/label/c.CCEP_Products_Added_To_Cart_Successfully';

export default class CcepBuilderPromotionDetail extends LightningElement {

    static renderMode = 'light';

    labels = {
        CCEP_Products_Added_Title,
        CCEP_Products_Added_To_Cart_Successfully
    }

    _promotionData;
    _bannerData;
    promotionCMSContentKey;
    _products = [];
    _validDatesForPromo = false;
    _showModal = false;

    productIdAddedToCart;
    productNameAddedToCart;
    unitsAddedToCart;
    pricesAddedToCart;

    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

    @api
    recordId;

    get promotionData() {
        return this._promotionData;
    }
    set promotionData(value) {
        this._promotionData = value;
    }

    get bannerData() {
        return this._bannerData;
    }
    set bannerData(value) {
        this._bannerData = value;
    }

    get products() {
        return this._products;
    }
    set products(value) {
        this._products = value;
    }

    get validDatesForPromo(){
        return this._validDatesForPromo;
    }
    set validDatesForPromo(value){
        this._validDatesForPromo = value;
    }

    get showModal() {
        return this._showModal;
    }
    set showModal(value) {
        this._showModal = value;
    }

    @wire(getPromotionInfo, {promotionId: "$recordId"})
    onGetPromotionInfo(result) {
        if(result != null && result.data){
            this.promotionData = result.data;
            this.promotionCMSContentKey = result.data.CCEP_CMSContentKey__c;
            this.validDatesForPromo = true;
        }
    }

    @wire(getContent, {channelOrSiteId: siteId, contentKeyOrId: '$promotionCMSContentKey'})
    onGetContent(result) {
        if (result.data) {
            this.bannerData = result.data;
        }
    }

    @wire(getProductIdsInPromotion, {promotionId: "$recordId"})
    onGetProductIds(result) {
        if (result.data) {
            this.productIds = result.data.map((product) => product.CCEP_Product__c);
            this.getProductsData();
        }
    }

    async getProductsData(){
        let productsInfo = await getProductsInPromotion(this.productIds);
        let prices = await getPricingProductsInPromotion(this.productIds);
        let currencyCode = prices.data.currencyIsoCode;
        if(productsInfo.success && prices.success){
            if(prices.data.pricingLineItemResults){
                let pricesMap = prices.data.pricingLineItemResults.reduce((accumulator, priceItem) => ({
                    ...accumulator,
                    [priceItem.productId]: priceItem
                }),{});
                let products = productsInfo.data.products.map(productInfo => ({
                    ...productInfo,
                    name: productInfo.fields.Name,
                    prices: {
                        listingPrice: pricesMap[productInfo.id].listPrice,
                        negotiatedPrice: pricesMap[productInfo.id].unitPrice,
                        currencyIsoCode: currencyCode
                    },
                    image: productInfo.defaultImage,
                }));
                this.composeResults(products);
            }
        }
    }

    async getProductAvailabilities(productIds){
        let listOfProducts = [];
        try{
            listOfProducts = await getProductAvailability({effectiveAccountId: this.effectiveAccountId, productIds: productIds});
        }
        catch(error){
            console.log('getProductAvailability error', error);
        }
        return listOfProducts;
    }

    async composeResults(value){
        let productIds = value.map(product => product.id);
        let mapOfProducts = await this.getProductAvailabilities(productIds);
        let cardCollection = JSON.parse(JSON.stringify(value));
        Object.entries(mapOfProducts).forEach(([id,outOfStock]) => {
            let productIndex = cardCollection.findIndex(prod => prod.id === id);
            cardCollection[productIndex].outOfStock = outOfStock;
        });
        this.products = cardCollection;
    }

    modalClosed(){
        this.showModal = false;
    }

    handleAddToCart(event) {
        event.stopPropagation();
        this.productIdAddedToCart = event.detail.productId;
        this.productNameAddedToCart = event.detail.name;
        this.unitsAddedToCart = event.detail.units;
        this.pricesAddedToCart = event.detail.price;
        
        const { productId, units } = event.detail;
        let res = this.addToCartFunctionality(productId, units);
        if(res){
            this.showModal = true;
        }
    }

    async addToCartFunctionality(productId, units){
        const res = await addItemToCart(productId, units);
        return res.messagesSummary.hasErrors != null;
    }

}