import { LightningElement, wire } from 'lwc';
import { ProductCategoryHierarchyAdapter } from 'commerce/productApi';

export default class CcepBuilderCategoryCarousel extends LightningElement {

    static renderMode = 'light';

    _categories = [];

    get categories(){
        return this._categories;
    }

    set categories(value){
        this._categories = value;
    }

    @wire(ProductCategoryHierarchyAdapter, {effectiveAccountId: sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID')})
    onProductCategoryHierarchyAdapter(result) {
        if (result.data) {
            this.categories = result.data.productCategories;
        }
    }

}