import { LightningElement,api } from 'lwc';

export default class CcepAccountCreationForm extends LightningElement {
    @api accountName;
    @api industry;
    @api accountId;

    // Open the modal
    @api openModal() {
        // You can set default field values here if needed
        // this.accountName = 'Default Name';
        // this.industry = 'Default Industry';
        this.dispatchEvent(new CustomEvent('openmodal'));
        console.log('TEST ')
    }

    // Handle the Save button click
    handleSave() {
        // Perform your update logic here using accountId, accountName, industry, etc.
        // You can make an Apex call to update the Account object.

        // After updating, close the modal
        console.log('SAVE TEST ')
         const updatedAccountName = this.template.querySelector();
         const updatedIndustry = this.industry;

    // Console log the values for testing
         console.log('Updated Account Name:', updatedAccountName);
         console.log('Updated Industry:', updatedIndustry);
         this.closeModal();
         
    }
    
    // Close the modal
    closeModal() {
        this.dispatchEvent(new CustomEvent('closemodal'));
    }
}