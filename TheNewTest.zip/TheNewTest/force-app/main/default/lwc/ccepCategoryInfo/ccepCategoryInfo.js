import { LightningElement,api,wire } from 'lwc';
import getCategoryInfo from '@salesforce/apex/CCEP_CategoryBannerController.getCategoryInfo';
import communityId from "@salesforce/community/Id";

export default class CcepCategoryInfo extends LightningElement {
    static renderMode = 'light';

    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

    _categoryId;
    @api
    get categoryId() {
        return this._categoryId;
    }
    set categoryId(value) {
        this._categoryId = value;
    }

    _category;
    get category() {
        return this._category;
    }
    set category(value) {
        this._category = value;
    }    
    
    @wire(getCategoryInfo, {communityId: communityId,effectiveAccountId: "$effectiveAccountId",productCategoryId: "$categoryId"})
    onGetCategoryInfo(result) {
        if (result.data) {
            this.category = result.data;
        }
    }

}