import { LightningElement, api } from 'lwc';
// import addToCart from '@salesforce/label/c.CCEP_Add_To_Cart';
import add from '@salesforce/label/c.CCEP_Add';
// import cancel from '@salesforce/label/c.CCEP_Cancel';
// import selectProductQuantity from '@salesforce/label/c.CCEP_Select_Product_Quantity';

export default class CcepAddToCartButton extends LightningElement {

    static renderMode = 'light';

    labels = {
        add
    }

    _units;

    @api
    productId;

    @api
    get units() {
        return this._units;
    }
    set units(value) {
        this._units = value;
    }

    @api
    disabled;

    handleAddToCart(){
        this.dispatchEvent(
            new CustomEvent('addtocartbuttonclicked', {
                detail: {
                    productId: this.productId,
                    units: this.units
                }
            })
        );
    }
}