import { LightningElement, api } from 'lwc';
import { CartItemsAdapter, deleteItemFromCart, updateItemInCart } from 'commerce/cartApi';
import productDeleted from '@salesforce/label/c.CCEP_Product_Deleted';
import productDeletedSuccessfully from '@salesforce/label/c.CCEP_Product_Deleted_Successfully';

export default class CcepBuilderCartDetail extends LightningElement {

    static renderMode = 'light';

    labels = {
        productDeleted,
        productDeletedSuccessfully
    }

    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

    _isLoading = false;
    _deletedItemNotification = false;
    _validCart = false;
    _cartItems;

    @api
    get cartItems() {
        return this._cartItems;
    }
    set cartItems(value) {
        if(value){
            console.log('@@## Cart Items', JSON.parse(JSON.stringify(value)));
            this._cartItems = value;
            this.validCart = true;
        }
    }

    @api
    currencyIsoCode;

    get isLoading(){
        return this._isLoading;
    }
    set isLoading(value){
        this._isLoading = value;
    }

    get validCart() {
        return this._validCart;
    }
    set validCart(value) {
        this._validCart = value;
    }

    get deletedItemNotification() {
        return this._deletedItemNotification;
    }
    set deletedItemNotification(value) {
        this._deletedItemNotification = value;
    }

    async handleDeleteCartItem(event){
        this.isLoading = true;
        const { itemId } = event.detail;
        let result = await deleteItemFromCart(itemId);
        console.log('@@## Product Deleted', result);
        setTimeout(() => {
            this.deletedItemNotification = true;
            this.isLoading = false;
        }, 1000);
    }

    async handleUpdateCartItem(event){
        this.isLoading = true;
        const { itemId, units } = event.detail;
        let result = await updateItemInCart(itemId, units);
        console.log('@@## Product Updated', result);
        if(result){
            setTimeout(() => {
                this.isLoading = false;
            }, 1000);
        }
    }

    modalClosed(){
        this.deletedItemNotification = false;
    }

}