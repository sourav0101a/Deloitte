import { LightningElement, api } from 'lwc';

import CCEP_Search_Facets_checkbox_true from '@salesforce/label/c.CCEP_Search_Facets_checkbox_true';
import CCEP_Search_Facets_checkbox_false from '@salesforce/label/c.CCEP_Search_Facets_checkbox_false';


const FacetUiTypeEnum = {
    CHECKBOX: 'checkbox'
};

const CHECKBOX = {
    TRUE: 'true ',
    FALSE: 'false ',
};

export default class CcepCheckbox extends LightningElement {

    static renderMode = 'light';

    @api
    value;

    @api
    type = FacetUiTypeEnum.CHECKBOX;

    @api
    focusOnInit = false;


    handleFacetValueToggle(event) {
        const element = event.currentTarget;
        this.dispatchEvent(
            new CustomEvent('facetvaluetoggle', {
                bubbles: true,
                composed: true,
                cancelable: true,
                detail: {
                    id: element.dataset.id,
                    checked: element.checked,
                }
            })
        );
    }

    get labelValueName(){
        let labelName =  this.value.name;
        if (this.type === FacetUiTypeEnum.CHECKBOX) {
            if(labelName.includes(CHECKBOX.TRUE)){
            labelName = labelName.replace(CHECKBOX.TRUE, CCEP_Search_Facets_checkbox_true);
            }
            else if(labelName.includes(CHECKBOX.FALSE)){
                labelName = labelName.replace(CHECKBOX.FALSE, CCEP_Search_Facets_checkbox_false);
            }
        }
        return labelName;
    }
}