import { LightningElement,wire,track } from 'lwc';
import Id from '@salesforce/user/Id';
import { getRecord } from 'lightning/uiRecordApi';
import userAccountIdField from '@salesforce/schema/User.AccountId';
import userContactIdField from '@salesforce/schema/User.ContactId';
import userContactRoleField from '@salesforce/schema/User.Contact.EmployeeType__c';
import associatedUserDetails from '@salesforce/apex/CCEP_OutletController.getAssociatedUserListForOutlet';
import removeEmployee from '@salesforce/apex/CCEP_RemoveEmployeeAssociationController.removeEmployeeAssociation';
import detailTab from '@salesforce/label/c.CCEP_Detail_Tab';
import associatedAccountTab from '@salesforce/label/c.CCEP_Associated_Accounts_Tab';
import cancelButton from '@salesforce/label/c.CCEP_Cancel';
import deleteButton from '@salesforce/label/c.CCEP_Delete_Button';
import deleteUserHeader from '@salesforce/label/c.CCEP_Delete_User_Header';
import deleteUserBody from '@salesforce/label/c.CCEP_Delete_User_Body';

export default class CcepDisplayOutletAssociatedUser extends LightningElement {

    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');
    @track associatedUserResult;
    @track showeditModalTag = true;
    showDeleteModal = false;
    showEditModal = false;
    tempUserIdToDelete;
    tempUserIdToEdit;
    selectedContactId;
    isLoading = false;
    showEditDeleteButton = false;
    loggedInUserAccountId;
    loggedInUserContactId;
    loggedInUserRole;
    userId = Id;

    label = {
        detailTab,
        associatedAccountTab,
        cancelButton,
        deleteButton,
        deleteUserHeader,
        deleteUserBody
    };
    @track isModalOpen = false;

    @wire(getRecord, { recordId: Id, fields: [userAccountIdField ,userContactIdField,userContactRoleField]}) 
    currentUserInfo({error, data}) {
        if (data) {
            this.loggedInUserAccountId = data.fields.AccountId.value;
            this.loggedInUserContactId = data.fields.ContactId.value;
            this.loggedInUserRole = data.fields.Contact.value.fields.EmployeeType__c.value;
            if(this.loggedInUserAccountId){
                this.getAssociatedUserDetails();
            }

        } else if (error) {
            this.error = error ;
        }
    }
    
    openModal(event) {
        // Open the modal
        this.showEditModal = true;
        this.selectedContactId = event.target.dataset.contactId;
        const userId = event.target.dataset.userId;
        this.tempUserIdToEdit = userId;
    }

    handleEditModalClose(event) {
        // Close the modal
        this.showEditModal = false;
        const detailValue = event.detail;
        const checkContact = detailValue.contactIdvalue;
        for(let user in this.associatedUserResult){
                if(this.associatedUserResult[user].ManagedBy.ContactId === checkContact){
                    this.associatedUserResult[user].ManagedBy.Contact.Name= `${detailValue.firstName}${detailValue.lastName}`;
                    this.associatedUserResult[user].ManagedBy.Contact.Email=detailValue.email;
                    this.associatedUserResult[user].ManagedBy.Contact.EmployeeType__c=detailValue.employeeType;
                    this.associatedUserResult[user].ManagedBy.Contact.Phone=detailValue.phone;
                }
           
        }
      }
    handleEditModalCancel(){
        this.showEditModal = false;
    }
    openRemoveModal(event){
        this.showDeleteModal = true;
        this.tempUserIdToDelete = event.target.dataset.userId;
    }

    handleModalClose(){
        this.showDeleteModal = false;
        this.tempUserIdToDelete = '';
    }
    
    handleRemove(){
        
        this.isLoading = true;
        removeEmployee({
            userId : this.tempUserIdToDelete,
            targetAccountId : this.effectiveAccountId
        })
        .then((result) =>{
            if(result == true){
                this.isLoading = false;
                this.showDeleteModal = false;
                this.tempUserIdToDelete = '';
                location.href = location.href;
            }
        })
        .catch((error) =>{
            this.error = error;
        })
    }
    
    connectedCallback() {
        //code
        console.log('Inside connected call of outlet detail');
        this.getAssociatedUserDetails();
        console.log('Outside connected call of outlet detail');
    }
    getAssociatedUserDetails(){
        associatedUserDetails({targetId: this.effectiveAccountId, parentId: this.loggedInUserAccountId})
        .then((data) => {    
            if(data){
                let resultData = JSON.parse(JSON.stringify(data));
                
                for(let user in resultData){

                    //if logged in user is outlet owner
                    if(this.loggedInUserRole == null || this.loggedInUserRole == '' || this.loggedInUserRole == undefined){
                        if(resultData[user].ManagedById === this.userId && resultData[user].ManagedBy.Contact.EmployeeType__c === undefined){
                            resultData[user]['showEditDeleteButton'] = false;
                        }else{
                            resultData[user]['showEditDeleteButton'] = true;
                        }
                    }
                    //if logged in user is Outlet Manager
                    if(this.loggedInUserRole === 'Outlet Manager'){
                        if(resultData[user].ManagedBy.Contact.EmployeeType__c === 'Outlet Manager' || resultData[user].ManagedBy.Contact.EmployeeType__c === undefined){
                            resultData[user]['showEditDeleteButton'] = false;
                        }else{
                            resultData[user]['showEditDeleteButton'] = true;
                        }

                    }

                    //if logged in user is Staff
                    if(this.loggedInUserRole === 'Outlet Staff'){
                        resultData[user]['showEditDeleteButton'] = false;
                    }

                }
                
                this.associatedUserResult = resultData;
            }
        })
        .catch((error) => {
            this.error = error;
        });
    }
}