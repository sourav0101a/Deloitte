import { LightningElement,api } from 'lwc';
import isProductAvailable from '@salesforce/apex/CCEP_ProductDetailsController.isProductAvailable';

export default class CcepBuilderProductDetails extends LightningElement {
    static renderMode = 'light';
    _productDetail;

    @api
    get productDetail() {
        return this._productDetail;
    }
    set productDetail(value) {
        if(value){
            this.composeProductStock(value);
        }
    }

    async isProductAvailable(productId){
        const productAvailable = await isProductAvailable({effectiveAccountId: sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID'), productId: productId});
        return productAvailable;
    }

    async composeProductStock(value){
        let productAvailability = await this.isProductAvailable(value.id);
        let productInfo = JSON.parse(JSON.stringify(value));
        productInfo.outOfStock = !productAvailability;
        this._productDetail = productInfo;
    }

}