import { LightningElement,api } from 'lwc';
import CCEP_Per_Unit from '@salesforce/label/c.CCEP_Per_Unit';
import CCEP_Quantity from '@salesforce/label/c.CCEP_Quantity';
import CCEP_TotalPrice from '@salesforce/label/c.CCEP_TotalPrice';

export default class CcepCheckoutSummaryItem extends LightningElement {
    static renderMode = 'light';

    labels = {
        CCEP_Per_Unit,
        CCEP_Quantity,
        CCEP_TotalPrice
    }

    _cartItem;
    _units;

    @api
    get cartItem() {
        return this._cartItem;
    }
    set cartItem(value) {
        if (value) {
            console.log('cartItem',JSON.parse(JSON.stringify(value)));
        }
        this._cartItem = value;
    }

    get unitPrice () {
        return Number(this._cartItem.CCEP_Total__c / this._cartItem.Quantity).toFixed(2);
    }


}