import { LightningElement, api } from 'lwc';
import subtotal from '@salesforce/label/c.CCEP_Subtotal';
import cartDisclaimer1 from '@salesforce/label/c.CCEP_Cart_Disclaimer';
import cartDisclaimer2 from '@salesforce/label/c.CCEP_Cart_Disclaimer_2';
import total from '@salesforce/label/c.CCEP_Total';

export default class CcepCartSummary extends LightningElement {

    static renderMode = 'light';

    labels = {
        subtotal,
        cartDisclaimer1,
        cartDisclaimer2,
        total
    }

    @api
    subtotal;

    @api
    total;

    @api
    currencyIsoCode;

}