import { LightningElement, api } from 'lwc';
import notificationHeader from '@salesforce/label/c.CCEP_Notification_Header';
export default class CcepNotificationGrid extends LightningElement {

    @api notificationList;

    labels = {
        notificationHeader
    }
}