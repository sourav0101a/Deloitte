import { LightningElement,track,wire } from 'lwc';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import{ getPicklistValues } from 'lightning/uiObjectInfoApi';
import CLAIM from '@salesforce/schema/CCEP_Claim__c';
//Apex Actions
import validateOrder from '@salesforce/apex/CCEP_ClaimController.validateOrder';
import submitClaim from '@salesforce/apex/CCEP_ClaimController.submitClaim';
// import getValues from '@salesforce/apex/CCEP_ClaimController.getValues';
//import createContentVersion from '@salesforce/apex/CCEP_ClaimController.createContentVersion';
import {NavigationMixin} from 'lightning/navigation';
import addNewClaim from '@salesforce/label/c.CCEP_Add_New_Claim';
import claimHeader from '@salesforce/label/c.CCEP_Claim_Heading';
import claimTitle from '@salesforce/label/c.CCEP_Claim_Title';
import issueType from '@salesforce/label/c.CCEP_Issue_Type';
import typeOfReason from '@salesforce/label/c.CCEP_Type_of_Reason';
import reason from '@salesforce/label/c.CCEP_Claim_Reason';
import description from '@salesforce/label/c.CCEP_Claim_Description';
import addImage from '@salesforce/label/c.CCEP_Add_Image';
import submit from '@salesforce/label/c.CCEP_Claim_Submit';
import cancel from '@salesforce/label/c.CCEP_Claim_Cancel';
import mandFieldError from '@salesforce/label/c.CCEP_Mandatory_Fields_Error';
import successmsg from '@salesforce/label/c.CCEP_Success_Message';
import back from '@salesforce/label/c.CCEP_Back_to_My_Claims';
import home from '@salesforce/label/c.CCEP_Go_to_Home_Page';
import orderNo from '@salesforce/label/c.CCEP_Order_No';
import orderHelpText from '@salesforce/label/c.CCEP_Order_Help_Text';
import imageError from '@salesforce/label/c.CCEP_Claim_Image_Error';
import claimSuccess from '@salesforce/label/c.CCEP_Claim_success';
import invalidOrderNo from '@salesforce/label/c.CCEP_Invalid_Order_No';
import image from '@salesforce/label/c.CCEP_Image';
import supportEmail from '@salesforce/label/c.CCEP_Platform_Contact_Email';
import supportPhone from '@salesforce/label/c.CCEP_Platform_Contact_Phone';
import or from '@salesforce/label/c.CCEP_Or';

export default class CcepAddNewClaim extends NavigationMixin(LightningElement) {


    effectiveAccountId = sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

    label = {
        addNewClaim,
        claimHeader,
        claimTitle,
        issueType,
        typeOfReason,
        reason,
        description,
        addImage,
        submit,
        cancel,
        mandFieldError,
        successmsg,
        back,
        home,
        orderNo,
        orderHelpText,
        imageError,
        invalidOrderNo,
        claimSuccess,
        image,
        supportEmail,
        supportPhone,
        or

    };
    @track IssueTypes=[];
    @track IssueReason=[];
    claimReasonData
    
    @track selectedIssuetype='';
    @track selectedIssueReason='';
    @track selectedReason='';
    @track showInputField = false;
    @track showSuccessPage = false;
    @track Responses=[];
    orderNo;
    requiredFieldError=false;
    showResponses=false;
    contentVid=[];
    @track contentVersionList = []
    @track uploadedFilesUrl = []
    @track newFileWasUploaded = false;
    @track optimalFileSize = true;
    @track imageData =[]
    fileData
    fileDataArray =[]
    MAX_FILE_SIZE = 1000000

    @track orderID='';
    @track showError=false;
    //claim Detail Information
    @track claimDetails = {
        title : '',
        effectiveAccountId : '',
        description : '',
        orderNo : '',
        IssueType : '',
        IssueReason : '',
        Reason: ''
    };

    handleTitle(event){
        this.title = event.detail.value;
        
    }

    handleDescription(event){
        console.log('event is', event);
        this.description = event.detail.value;
       
    }

    @wire(getObjectInfo, { objectApiName: CLAIM})
    claimObjectInfo;

    @wire(getPicklistValues, { recordTypeId: '$claimObjectInfo.data.defaultRecordTypeId', fieldApiName: 'CCEP_Claim__c.CCEP_Issue_Type__c'})
    wiredIssueTypePicklist({data, error}){
        console.log('wire data1',data);
        if(data){
            this.IssueTypes = data.values.map(option => ({label:option.label, value: option.value}));
            console.log('IssueTypes',this.IssueTypes);
        }else if(error){
            console.error(error);
        }
    }

    handleIssueTypeChange(event){
        this.selectedIssuetype = event.detail.value;
        this.showInputField = this.selectedIssuetype === 'Related With Order';
        this.showError = false;
    }
    
    @wire(getPicklistValues, { recordTypeId: '$claimObjectInfo.data.defaultRecordTypeId', fieldApiName: 'CCEP_Claim__c.CCEP_Issue_Reason__c'})
    wiredIssueReasonPicklist({data, error}){
        console.log('wire dataE is',data);
        if(data){
            this.IssueReason = data.values.map(option => ({label:option.label, value: option.value}));
            console.log('IssueReason',this.IssueReason);
        }else if(error){
            console.error(error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$claimObjectInfo.data.defaultRecordTypeId', fieldApiName: 'CCEP_Claim__c.CCEP_Claim_Reason__c'})
    wiredClaimReasonPicklist({data, error}){
        if(data){
            this.claimReasonData = data;
        }else if(error){
            console.error(error);
        }
    }

    handleIssueReasonChange(event){
        this.selectedIssueReason = event.detail.value;
        this.showResponses=true;

        let key = this.claimReasonData.controllerValues[event.detail.value];
        let filteredValues = this.claimReasonData.values.filter((opt) => opt.validFor.includes(key));
        this.Responses = filteredValues.map(option => ({label:option.label, value: option.value}));
        //this.updateReasonField();
    }

    // updateReasonField(){
    //     getValues({
    //         selectedIssueReason:this.selectedIssueReason
    //     })
        
    //     .then(result=> {
    //         //handle result from apex
    //         console.log('result picklist',result);
    //         let fieldValues=[];
    //         if(this.Responses)
    //         {this.Responses=[];
    //         for(let temp in result){
    //             console.log('tempvalue',temp);
    //             this.Responses.push({label:result[temp].ClaimReasonValue__c, 
    //                 value:result[temp].ClaimReasonValue__c});
                    
    //         }
    //     }
    //         this.showResponses=true;
    //         console.log('result picklist',this.Responses);
    //     })
    
    //     .catch(error=>{
    //         console.error('error in apex:',error);
            
    //     });
    //    }
    

    handleReasonChange(event){
        this.selectedReason = event.detail.value;
    }

   handleOrderIDChange(event){
    this.orderID = event.target.value;
    this.validateOrderOnServer();
    //client-side validation: only allow numeric characters
    
   }

   validateOrderOnServer(){
    console.log('orderId and accountId',this.orderID,this.effectiveAccountId);
    /*if(!/^\d+$/.test(this.orderID)){
        console.log('test1',this.showError);
        this.showError = true;
    }else{
        this.showError=false;
        console.log('test2',this.showError);
        //Server-side validation: check if orderID is present in past 30 days orders*/
    validateOrder({
        orderId:this.orderID,
        effectiveAccountId:this.effectiveAccountId
    })
    .then(result=> {
        //handle result from apex
        if(result!=null){
            console.log('test3',this.showError);
            console.log('result',result);
            this.orderNo=result;
            console.log('result',this.orderNo);
            this.showError=false;
        }
        else{
            console.log('test4',this.showError);
            this.showError=true;
        }
    })
    .catch(error=>{
        console.error('error validating order in apex:',error);
        this.showError=true;
    });
   //}
}

   handleSubmit(event){
    if(this.title && this.selectedIssuetype && this.selectedIssueReason && this.selectedReason
        && this.description){
        this.requiredFieldError = false;
        this.claimDetails.title = this.title;
        this.claimDetails.effectiveAccountId = this.effectiveAccountId;
        this.claimDetails.description = this.description;
        this.claimDetails.orderNo = this.orderNo;
        this.claimDetails.IssueType = this.selectedIssuetype;
        this.claimDetails.IssueReason = this.selectedIssueReason;
        this.claimDetails.Reason = this.selectedReason;
        console.log('Claim Detail JSON-'+JSON.stringify(this.claimDetails));
        console.log('Claim Detail JSON-',JSON.stringify(this.fileDataArray));
        
    submitClaim({
        claimDetails: JSON.stringify(this.claimDetails),
        claimAttachmentJSON: JSON.stringify(this.fileDataArray)
    })
    .then((result) => {
        console.log('result', result);
        this.showSuccessPage = true;
    })
    .catch((error) => {
        console.error(error);
        this.showSuccessPage = false;

    });
    }else {this.requiredFieldError= true;
    }      
   }

    navigateToHome(){
        //Navigate to Home Page
            this[NavigationMixin.Navigate]({
                type: 'standard__webPage',
                attributes: {
                   url:'/'
              }
               });
            }


    navigateToClaimPage(){
        //Navigate to claim Page
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
               url:'/my-claims'
          }
           });
        
    }

    handleCancel(){
        //Navigate to claim Page
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
               url:'/my-claims'
          }
           });
        
    }

    openfileUpload(event) {
        this.optimalFileSize = true
        const file = event.target.files[0]

        if(file.size > this.MAX_FILE_SIZE || this.fileDataArray.length >2){
            this.optimalFileSize = false
        }
        console.log("optimalFileSize "+this.optimalFileSize)
        var reader = new FileReader()
        reader.onload = () => {
            var base64 = reader.result.split(',')[1]
            let imageId = `${Date.now().toString(36) + Math.random().toString(36).substring(2)}`
            this.fileData = {
                'id': imageId,
                'filename': file.name,
                'base64': base64,
            }

            if(this.optimalFileSize){
                this.newFileWasUploaded = true
                this.fileDataArray.push(this.fileData)
                const date = new Date();
                let day = date.getDate();
                const month = date.toLocaleString('default', { month: 'short' });
                this.imageData.push({
                    'id': imageId,
                    'hash': reader.result,
                    'name': file.name,
                    'size': `${Math.round(file.size/1000 * 100) / 100} Kb`,
                    'ext' : file.type,
                    'date' : `${day} ${month}`
                })
            }
            else{
                console.error("FILE Not OPTIMAL!!")
            }
        }
        reader.readAsDataURL(file)
    }
    handleDelete(event){

        var id = event.target.dataset.id
        console.log("Id-delete-"+id)
        if(id){
            //Splice from Image Array
            let imageKeysArray = this.imageData.map(e => e.id)
            const index = imageKeysArray.indexOf(id)
            this.imageData.splice(index,1)
            //Splice From Data Array
            let fileDataKeysArray = this.fileDataArray.map(e => e.id)
            const fileIndex = fileDataKeysArray.indexOf(id)
            this.fileDataArray.splice(fileIndex,1)
            console.log("ImageArray" + this.imageData)
            console.log("fileDataArray" + this.fileDataArray)
        }


    }


}