import { LightningElement, api, track, wire } from 'lwc';
import {getObjectInfo} from 'lightning/uiObjectInfoApi';
import {getPicklistValues} from 'lightning/uiObjectInfoApi';
import getPostalCodeDetails from '@salesforce/apex/CCEP_OutletRegistrationController.getPostalCodeMappingDetailsByPostalCode';
import updateOutlet from '@salesforce/apex/CCEP_OutletController.updateOutletDetails';
//importing the Type of Road picklist from the ContactPointAddress object
import contactPointAddressObject from '@salesforce/schema/ContactPointAddress';
import typeOfRoadField from '@salesforce/schema/ContactPointAddress.CCEP_Type_of_Road__c';
import establishmentName from '@salesforce/label/c.CCEP_Establishment_Name';
import establishmentBillingAddress from '@salesforce/label/c.CCEP_Establishment_Billing_Address';
import establishmentDeliveryAddress from '@salesforce/label/c.CCEP_Establishment_Delivery_Address';
import postalCode from '@salesforce/label/c.CCEP_Postal_Code';
import postalCodePlaceholder from '@salesforce/label/c.CCEP_Postal_Code_Placeholder';
import postalCodeErrorMsg from '@salesforce/label/c.CCEP_Invalid_Postal_Code';
import postalCodeRange from '@salesforce/label/c.CCEP_Postal_Code_Range';
import typeOfRoad from '@salesforce/label/c.CCEP_Type_of_Street';
import nameOfRoad from '@salesforce/label/c.CCEP_Name_of_Road';
import addressName from '@salesforce/label/c.CCEP_Address_name';
import number from '@salesforce/label/c.CCEP_Number';
import province from '@salesforce/label/c.CCEP_Province';
import city from '@salesforce/label/c.CCEP_City';
import cancelButton from '@salesforce/label/c.CCEP_Cancel';
import saveButton from '@salesforce/label/c.CCEP_Save_Button';
import ediEstablishmentDetailHeader from '@salesforce/label/c.CCEP_Edit_Establishment_Detail';

export default class CcepEditOutletForm extends LightningElement{
    @api outletData;
    roadOptions;
    invalidPostalCode = false;

    //edit form properties
    outletName;
    shippingRoadType;
    shippingPostalCode;
    shippingRoadNumber;
    shippingRoadName;
    shippingCity;
    shippingProvince;

    billingRoadType;
    billingPostalCode;
    billingRoadNumber;
    billingRoadName;
    billingCity;
    billingProvince;

    label = {
        establishmentName,
        establishmentBillingAddress,
        establishmentDeliveryAddress,
        postalCode,
        postalCodePlaceholder,
        postalCodeErrorMsg,
        postalCodeRange,
        typeOfRoad,
        nameOfRoad,
        addressName,
        number,
        province,
        city,
        cancelButton,
        saveButton,
        ediEstablishmentDetailHeader
    };

    updatedDetails = {
        outletId : '',
        updatedName : '',
        updatedBillRoadName : '',
        updatedBillRoadType : '',
        updatedBillPostalCode : '',
        updatedBillRoadNumber : '',
        updatedBillCity : '',
        updatedBillProvince : '',
        updatedShipRoadName : '',
        updatedShipRoadType : '',
        updatedShipPostalCode : '',
        updatedShipRoadNumber : '',
        updatedShipCity : '',
        updatedShipProvince : '',
    }

    //getting the type of road picklist values
    @wire(getObjectInfo, {objectApiName: contactPointAddressObject })
    ContactPointAddressInfo;

    @wire(getPicklistValues, {recordTypeId: '$ContactPointAddressInfo.data.defaultRecordTypeId', fieldApiName: typeOfRoadField })
    roadTypePicklistValues({data, error}){
        if(data){
            this.roadOptions = data.values;
        }
    }

    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

    connectedCallback(){
        if(this.outletData){
            this.outletName = this.outletData.Name;
            var data = this.outletData;
            for(let addresses in data.ContactPointAddresses){

                if(data.ContactPointAddresses[addresses].AddressType === 'Billing'){
                    this.billingPostalCode = data.ContactPointAddresses[addresses].PostalCode;
                    this.billingRoadNumber = data.ContactPointAddresses[addresses].CCEP_Number__c;
                    this.billingRoadType = data.ContactPointAddresses[addresses].CCEP_Type_of_Road__c;
                    this.billingProvince = data.ContactPointAddresses[addresses].State;
                    this.billingCity = data.ContactPointAddresses[addresses].City;
                    this.billingRoadName = data.ContactPointAddresses[addresses].CCEP_Name_of_Road__c;
                }
                if(data.ContactPointAddresses[addresses].AddressType === 'Shipping'){
                    this.shippingPostalCode = data.ContactPointAddresses[addresses].PostalCode;
                    this.shippingRoadNumber = data.ContactPointAddresses[addresses].CCEP_Number__c;
                    this.shippingRoadType = data.ContactPointAddresses[addresses].CCEP_Type_of_Road__c;
                    this.shippingProvince = data.ContactPointAddresses[addresses].State;
                    this.shippingCity = data.ContactPointAddresses[addresses].City;
                    this.shippingRoadName = data.ContactPointAddresses[addresses].CCEP_Name_of_Road__c;
                }
            }
        }
    }

    //validate postal code input and populate city and province
    handleBillingPostalCode(){
        var rangeList = this.label.postalCodeRange.split(',');
        var postCode = this.template.querySelector("[data-name='billingPostalCode']").value;
        this.billingPostalCode = postCode;
        console.log('enter in handle postal code');
        var pattern = /\b\d{5}\b/g;
        var postalCode = parseInt(postCode);
        console.log('postalCode ', postalCode);
        if(!postCode.match(pattern)){
            this.invalidPostalCode = true;
        }
        else if(!(postalCode >= parseInt(rangeList[0]) && postalCode <= parseInt(rangeList[1]))){
            this.invalidPostalCode = true;
        }
        else
        {
            this.invalidPostalCode = false;
            
            //call apex
            getPostalCodeDetails({
                postalCode:postCode.trim()
            })
            .then((result) => {
                console.log('result', result);

                this.billingProvince = result.Province__c;
                this.billingCity = result.City__c;
            })
            .catch((error) => {
                console.error(error);
            });
        }
    }

     //validate postal code input and populate city and province
     handleShippingPostalCode(){
        var rangeList = this.label.postalCodeRange.split(',');
        var postCode = this.template.querySelector("[data-name='shippingPostalCode']").value;
        this.shippingPostalCode = this.template.querySelector("[data-name='shippingPostalCode']").value;
        console.log('enter in handle postal code');
        var pattern = /\b\d{5}\b/g;
        var postalCode = parseInt(postCode);
        console.log('postalCode ', postalCode);
        if(!postCode.match(pattern)){
            this.invalidPostalCode = true;
        }
        else if(!(postalCode >= parseInt(rangeList[0]) && postalCode <= parseInt(rangeList[1]))){
            this.invalidPostalCode = true;
        }
        else
        {
            this.invalidPostalCode = false;
            
            //call apex
            getPostalCodeDetails({
                postalCode:postCode.trim()
            })
            .then((result) => {
                console.log('result', result);

                this.shippingProvince = result.Province__c;
                this.shippingCity = result.City__c;
            })
            .catch((error) => {
                console.error(error);
            });
        }
    }

    handleCancel(){
        this.dispatchEvent(new CustomEvent('modalcancel'));
    }

    handleUpdate(){
            //outlet details
            this.updatedDetails.outletId = this.effectiveAccountId;
            this.updatedDetails.updatedName = this.template.querySelector("[data-name='outletName']").value;
            //billing
            this.updatedDetails.updatedBillRoadType = this.template.querySelector("[data-name='billingRoadType']").value;
            this.updatedDetails.updatedBillRoadName = this.template.querySelector("[data-name='billingRoadName']").value;
            this.updatedDetails.updatedBillRoadNumber = this.template.querySelector("[data-name='billingRoadNumber']").value;
            this.updatedDetails.updatedBillPostalCode = this.template.querySelector("[data-name='billingPostalCode']").value;
            this.updatedDetails.updatedBillProvince = this.template.querySelector("[data-name='billingProvince']").value;
            this.updatedDetails.updatedBillCity = this.template.querySelector("[data-name='billingCity']").value;
            //shipping
            this.updatedDetails.updatedShipRoadType = this.template.querySelector("[data-name='shippingRoadType']").value;
            this.updatedDetails.updatedShipRoadName = this.template.querySelector("[data-name='shippingRoadName']").value;
            this.updatedDetails.updatedShipRoadNumber = this.template.querySelector("[data-name='shippingRoadNumber']").value;
            this.updatedDetails.updatedShipPostalCode = this.template.querySelector("[data-name='shippingPostalCode']").value;
            this.updatedDetails.updatedShipProvince = this.template.querySelector("[data-name='shippingProvince']").value;
            this.updatedDetails.updatedShipCity = this.template.querySelector("[data-name='shippingCity']").value;
    
            console.log('Data to APEX'+JSON.stringify(this.updatedDetails));

        //call apex here
        updateOutlet({
            updatedDetails : JSON.stringify(this.updatedDetails)
        })
        .then((result) => {
            console.log('result', result);
            if(result)
                this.dispatchEvent(new CustomEvent('closemodal'));
        })
        .catch((error) => {
            console.log('Error in Catch ', error);
            console.error(error);
        });
        console.log('EDIT FORM RELOAD', window.location.href);
        window.location.reload();
        
    }
}