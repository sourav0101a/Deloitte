import { LightningElement, api } from 'lwc';
import { NavigationMixin } from "lightning/navigation";
import { labelWithParams } from 'c/ccepCommerceUtils';

/* Templates */
import templateCreated from "./ccepOrderSummaryDetailCreated.html";

/* Labels */
import backToOrderHistory from "@salesforce/label/c.CCEP_Back_To_Order_History";
import orderDetails from "@salesforce/label/c.CCEP_Order_Details";
import orderInformation from "@salesforce/label/c.CCEP_Order_Information";
import orderNumber from "@salesforce/label/c.CCEP_Order_Number";
import distributor from "@salesforce/label/c.CCEP_Distributor";
import orderedDate from "@salesforce/label/c.CCEP_Ordered_Date";
import desiredDeliveryDate from "@salesforce/label/c.CCEP_Desired_Delivery_Date";
import productsAndCost from "@salesforce/label/c.CCEP_Products_Cost";
import totalOfNumber from "@salesforce/label/c.CCEP_Total_Of";
import subtotal from "@salesforce/label/c.CCEP_Subtotal";
import offers from "@salesforce/label/c.CCEP_Offers";
import taxesAndRates from "@salesforce/label/c.CCEP_Taxes_Rates";
import total from "@salesforce/label/c.CCEP_Total";

export default class CcepOrderSummaryDetail extends NavigationMixin(LightningElement) {
    static renderMode = 'light';

    labels = {
        backToOrderHistory,
        orderDetails,
        orderInformation,
        orderNumber,
        distributor,
        orderedDate,
        desiredDeliveryDate,
        productsAndCost,
        subtotal,
        offers,
        taxesAndRates,
        total
      }

    _order;

    @api
    get order() {   
        return this._order;
    }
    set order(value) {
        this._order = value;
        if(value){
            console.log('*** Order data is: ', JSON.parse(JSON.stringify(value)));
        }
    }

    render(){
        return templateCreated;
    }

    navigateToOrderHistory(event) {
        event.preventDefault();
        this[NavigationMixin.Navigate]({
            type: "standard__objectPage",
            attributes: {
              objectApiName: "OrderSummary",
              actionName: "list"
            }
        });
    }

    get totalOf(){
        return labelWithParams(totalOfNumber, this.order.totalProducts);
    }
}