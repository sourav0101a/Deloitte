import { LightningElement } from "lwc";
import getPromotions from "@salesforce/apex/CCEP_PromotionsController.getPromotions";
import { getCMSContent } from "c/ccepCommerceUtils";
import { getLanguage } from "c/ccepCommerceUtils";

export default class CcepBuilderPromotionsCarousel extends LightningElement {
  static renderMode = "light";

  _promotions;

  get promotions() {
    return this._promotions;
  }

  connectedCallback() {
    this.getCurrentPromotions();
  }

  async getCurrentPromotions() {
    let promotions = await getPromotions({
      effectiveAccountId: sessionStorage.getItem("EFFECTIVE_ACCOUNT_ID")
    });
    if (promotions) {
      let res = await getCMSContent(
        promotions.map(
          (promotion) => promotion.CCEP_Promotion__r.CCEP_CMSContentKey__c
        )
      );
      if (res.success && res.data.contents) {
        let promotionWithAllInfo = [];
        promotions.forEach((promotion) => {
          let cmsContent = res.data.contents.find(
            (content) =>
              content.contentKey ===
              promotion.CCEP_Promotion__r.CCEP_CMSContentKey__c
          );
          let promotionWithCms = JSON.parse(JSON.stringify(promotion));
          promotionWithCms.cmsContent = cmsContent;
          promotionWithCms.endDate = new Intl.DateTimeFormat(
            getLanguage()
          ).format(new Date(promotion.CCEP_Promotion__r.CCEP_EndDate__c));
          promotionWithAllInfo.push(promotionWithCms);
        });
        this._promotions = promotionWithAllInfo.map((promotion) => ({
          id: promotion.CCEP_Promotion__r.Id,
          title: promotion.cmsContent.contentBody.title,
          description: promotion.cmsContent.contentBody.description,
          image: {
            alternateText: promotion.cmsContent.urlName,
            url: promotion.cmsContent.contentBody.image.url
          },
          endDate: promotion.endDate,
          discount: promotion.cmsContent.contentBody.discount
        }));
      }
    }
  }
}