import { LightningElement, api  } from 'lwc';
import { createSearchFiltersUpdateAction, dispatchAction } from 'commerce/actionApi';
import getSearchResultsFilters from '@salesforce/apex/CCEP_SearchFiltersController.getSearchResultsFilters';
import communityId from "@salesforce/community/Id";

const DEFAULT_SEARCH_FILTER_PAGE = 1;

export default class CcepBuilderSearchFilters extends LightningElement {

    static renderMode = 'light';

    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

    _searchResults;
    _startIndex;
    _totalPages;
    _total;
    _categoryId;
    _searchTerm;
    _facets;
    _originalFacets;

    @api sortRuleId;
    @api searchTerm;
    @api currentPage;


    @api
    get startIndex(){
        return this._startIndex;
    }
    set startIndex(value){
        this._startIndex = value;
    }

    @api
    get totalPages() {
        return this._totalPages;
    }
    set totalPages(value) {
        this._totalPages = value;
    }

    @api
    get total() {
        return this._total;
    }
    set total(value) {
        this._total = value;
    }

    @api
    get searchResults() {
        return this._searchResults;
    }
    set searchResults(value) {
        if (value) {
            if(value.cardCollection){
                this._categoryId = value.filtersPanel.categories.selectedCategory.id;
            }
            let valueCopy = JSON.parse(JSON.stringify(value));
            let sortedFacets = valueCopy.filtersPanel.facets.sort( (faceta,facetb) => faceta.displayRank - facetb.displayRank);
            this._searchResults = {...valueCopy,filtersPanel: {...valueCopy.filtersPanel,facets: sortedFacets}};
            //Once sorted we save actual facets
            if(this._searchResults.filtersPanel.facets){
                this._facets = JSON.parse(JSON.stringify(this._searchResults.filtersPanel.facets));
                if(!this._originalFacets){
                    this._originalFacets = JSON.parse(JSON.stringify(this._searchResults.filtersPanel.facets));
                }
            }
        }
    }

    get showFiltersMenu(){
        console.log('@@@ this.startIndex',this.startIndex);
        console.log('@@@ this.total',this.total);
        console.log('@@@ this.totalPages',this.totalPages);
        if((this.startIndex >0 && this.total>0 && this.totalPages >0) || (this.startIndex <0 && this.total>0 && this.totalPages >0)){
            return true;
        }
        return false;
    }

    handleFacetValueAcceptEvent(event) {
        event.stopPropagation();

        const searchFiltersPayload = {
            page: DEFAULT_SEARCH_FILTER_PAGE, 
            refinements: this.generateRefinementsArray(),
            mruFacet: this._searchResults.filtersPanel.facets,
        };

        dispatchAction(this, createSearchFiltersUpdateAction(searchFiltersPayload));
    }

     handleClearAllFiltersEvent() {
        this._searchResults = {... this._searchResults, filtersPanel: {... this._searchResults.filtersPanel, facets: this._originalFacets}};
        this._facets = JSON.parse(JSON.stringify(this._searchResults.filtersPanel.facets));
    }   

    handleFacetValueUpdateFacetListEvent(event){
        let facets = [...this._facets];
        let facetModified = facets.findIndex(facet => facet.displayName === event.detail.facetName);
        let valueModified = facets[facetModified].values.findIndex(value => value.id === event.detail.id);
        facets[facetModified].values[valueModified].checked = event.detail.checked;
        this._facets = facets;
        this.refreshFacetsAvailables();
    }

    async refreshFacetsAvailables() {
        const searchQuery = {
            categoryId: this._categoryId==='ROOT_CATEGORY_ID'?null:this._categoryId,
            includePrices: true,
            searchTerm: this.searchTerm,
            refinements: this.generateRefinementsArray(),
            page: DEFAULT_SEARCH_FILTER_PAGE,
            sortRuleId: this.sortRuleId
        };
        try {
            let newItems = await getSearchResultsFilters({communityId, effectiveAccountId: this.effectiveAccountId,searchQuery: JSON.stringify(searchQuery)});
            this._searchResults = {... this._searchResults, filtersPanel: {... this._searchResults.filtersPanel, facets: this.generateNewFacetsToShow(newItems.facets)}};
            this._facets = JSON.parse(JSON.stringify(this._searchResults.filtersPanel.facets));
          } catch (error) {
            console.error(error);
          }
    }

    generateNewFacetsToShow(facetsFromSearchAPI) {
        let newFacets = [];
        facetsFromSearchAPI.forEach(facetFromSearchAPI => {
            if (facetFromSearchAPI.values.length > 0) {
                let newFacet = this._facets.find(facet => facet.nameOrId === facetFromSearchAPI.nameOrId);
                let newOriginalFacet = this._originalFacets.find(facet => facet.nameOrId === facetFromSearchAPI.nameOrId);
                if(newFacet){
                    newFacets.push({
                        ... facetFromSearchAPI,
                        displayType: newFacet.displayType,
                        id: newFacet.id,
                        values: this.generateNewFacetsValuesToShow(facetFromSearchAPI.values, newFacet.values, newOriginalFacet.values)
                        });
                }
            }
        })
        return newFacets;
    }

    generateNewFacetsValuesToShow(oldValues, newValues, newOriginalValues) {
        let values = [];
        oldValues.forEach(oldValue => { 
            let newValue = newValues.find(value => value.id === oldValue.nameOrId);
            if(newValue){
                values.push({
                    ... newValue,
                    name: oldValue.displayName.concat(' (', oldValue.productCount,')')
                });
            }
            else{
                let newOriginalValue = newOriginalValues.find(value => value.id === oldValue.nameOrId);
            if(newOriginalValue){
                values.push({
                    ... newOriginalValue,
                    name: oldValue.displayName.concat(' (', oldValue.productCount,')')
                });
            }
            }
        })
        return values;
    }

    generateRefinementsArray() {
        let refinements = [];
        this._facets.forEach(facet => {
            let valuesTrue = facet.values.filter(value => value.checked === true);
            if (valuesTrue.length > 0) {
                refinements.push({nameOrId: facet.nameOrId,
                        type: facet.facetType,
                        attributeType: facet.attributeType,
                        values: valuesTrue.map(value => value.id)
                    });
            }
        })
        return refinements;
    }
}