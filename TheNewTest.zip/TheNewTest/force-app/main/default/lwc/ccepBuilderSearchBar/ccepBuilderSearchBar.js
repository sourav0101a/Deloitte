import { LightningElement, api } from 'lwc';
import {NavigationMixin} from 'lightning/navigation';

export default class CcepBuilderSearchBar extends NavigationMixin(LightningElement) {

    static renderMode = "light";

    _searchTerm;

    @api
    get searchTerm() {
        return this._searchTerm;
    }
    set searchTerm(value) {
        this._searchTerm = value;
    }


    handleUpdateCurrentPage(event) {
        const searchTerm = event.detail.searchTerm;
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
               url: '/global-search/' + searchTerm
          }
        });
    }
}