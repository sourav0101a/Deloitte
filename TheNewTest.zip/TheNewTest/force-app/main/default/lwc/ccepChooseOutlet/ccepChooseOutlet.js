import { LightningElement,wire,track,api } from 'lwc';
import {NavigationMixin} from 'lightning/navigation';
import communityId from '@salesforce/community/Id';
import getListOfOutlets from '@salesforce/apex/CCEP_OutletRegistrationController.getListOfOutlets';
import communityPath from '@salesforce/community/basePath';
import cancelButton from '@salesforce/label/c.CCEP_Cancel';
import chooseAnOutlet from '@salesforce/label/c.CCEP_Choose_An_Outlet';
import acceptButton from '@salesforce/label/c.CCEP_Accept';
import search from '@salesforce/label/c.CCEP_Search';

export default class CcepChooseOutlet extends NavigationMixin(LightningElement) {
    @track listOfOutletsResult;
    @track selectOutletId;

    outletNotChosen = true;

    myList;
    finalListOfOutletResult;
    searchOutletList;

    effectiveAccountId =  sessionStorage.getItem('EFFECTIVE_ACCOUNT_ID');

    label = {
        chooseAnOutlet,
        acceptButton,
        cancelButton,
        search
    };

    //get list of outlets details with address
    connectedCallback() {      
        getListOfOutlets({communityId: communityId})
        // console.log('result sales'+result)
        .then((result) => {
            if(result){
                if(result.externalManagedAccounts.length == 1){
                    sessionStorage.setItem('EFFECTIVE_ACCOUNT_ID',result.externalManagedAccounts[0].accountId );
                    //Navigate to Home
                    window.location.href = communityPath;
    
                }
                this.searchOutletList = result.externalManagedAccounts;
                this.listOfOutletsResult = result.externalManagedAccounts;

                for(let acc in this.listOfOutletsResult){
                    if(this.listOfOutletsResult[acc].isMyAccount){
                        this.selectOutletId = this.listOfOutletsResult[acc].accountId;
                    }
                    if(this.listOfOutletsResult[acc].accountId === this.effectiveAccountId){
                        this.listOfOutletsResult[acc]['isSelectedOutletId'] = true;
                        this.listOfOutletsResult[acc]['selectedOutletClass'] = 'selectedOutlet';
                        this.outletNotChosen = false;
                        this.selectOutletId = this.effectiveAccountId;
                    }
                }
                console.log('@@##listOfOutletsResult ' , JSON.stringify(this.listOfOutletsResult));

                

            }
           
        })
        .catch((error) => {
            console.log('In connected call back error....');
            this.error = error;
            // This way you are not to going to see [object Object]
            console.log('Error is', this.error); 
        });
    }

    //handle Account search
    handleAccountSearch(event){
        const searchKey = event.target.value.toLowerCase();
        if (searchKey) {
            this.searchOutletList = this.listOfOutletsResult;
            if (this.searchOutletList) {
                let recs = [];
                for (let rec of this.searchOutletList) {
                    let valuesArray = Object.values(rec);
                    for (let val of valuesArray) {
                        let strVal = String(val);
                        if (strVal) {
                            if (strVal.toLowerCase().includes(searchKey)) {
                                recs.push(rec);
                                break;
                            }
                        }
                    }
                }
                this.searchOutletList = recs;
            }
        }  
        else
            this.searchOutletList = this.listOfOutletsResult;
    }

    handleAccountClick(event){
        let outletId = event.currentTarget.dataset.id;
        this.selectOutletId = outletId;
        //this.template.querySelector(`[data-id="${targetId}"]`).className="class1"; 
        this.outletNotChosen = false; 
    }

    //handle Accept and Cancel navigation
    handleNavigation(event){
        sessionStorage.setItem('EFFECTIVE_ACCOUNT_ID',this.selectOutletId);
        //Navigating to login page => using window.location instead of NavigationMixing to force page refresh
        window.location.href = communityPath;
    }

    
}