import { LightningElement,api } from 'lwc';

export default class CcepImage extends LightningElement {

    static renderMode = 'light';
    @api 
    srcUrl;

    @api
    width;

    @api
    height;

    @api
    type;

    @api
    noFit;

    get imgStyle () {
        let style = '';
        if(!this.noFit){
            style = 'object-fit: contain;';
        }
        style += (this.width) ? `width:${this.width};` : '';
        style += (this.height) ? `height:${this.height};` : '';
        return style;
    }

    get styles(){
        return (this.type)? this.type : "";
    }


}