import { LightningElement, api } from 'lwc';
import add from '@salesforce/label/c.CCEP_Add';
import cancel from '@salesforce/label/c.CCEP_Cancel';

export default class CcepAddForWishlist extends LightningElement {

    labels = {
        add,
        cancel
    }

    @api showAddToCartModal;
    @api productId;

    @api
    get units() {
        return this._units;
    }
    set units(value) {
        this._units = value;
    }

    get buttonDisabled(){
        console.log('inside button disabled');
        //console.log('check sales price show',this.salesPriceShow);
        return false ;
    }
    // Add To Cart event
    handleAddToCart(event) {
        console.log('product id ****',this.productId);
        console.log('units ****',this.units);
        event.stopPropagation();
        this.dispatchEvent(
            new CustomEvent('addtocartbuttonclicked', {
                detail: {
                    productId: this.productId,
                    units: this.units
                }
            })
        );
    }

    cancelModal(){
        this.showAddToCartModal = false;
    }
}