import { LightningElement, api } from 'lwc';
import calculateFinalPrice from '@salesforce/label/c.CCEP_Calculate_Final_Price';

export default class CcepGoToOrderSummary extends LightningElement {

    static renderMode = 'light';

    labels = {
        calculateFinalPrice
    }

    _disable = true;    

    @api
    get disable() {
        return this._disable;
    }
    set disable(value) {
        this._disable = value;
    }

    handleCalculateFinalPrice(event){
        event.stopPropagation();
        this.dispatchEvent(new CustomEvent('gotoordersummary'));
    }
}